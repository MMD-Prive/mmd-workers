# Roadmap

## Done

- [x] Canonical base path locked to `/my-mmd` (was `/member/my-mmd`); React/TanStack app is the canonical presentation runtime
- [x] Ownership boundary documented: Lovable = presentation only; MMD Workers = identity/session/data/entitlement via `/api/member/app/*`
- [x] Ad-day lifecycle UI (active / expired / new / checking-legacy)
- [x] Backend `/api/member/app/*` (mmd-workers PR #580) is merged and live; README corrected
- [x] Defensive data normalisation for every live endpoint (`src/lib/mmd/normalize.ts`) — malformed / partial / envelope / HTML / 404 / 500 / `ok:false` payloads can no longer crash a route
- [x] Route-level error fallback keeps the MMD bar + bottom nav; root not-found/error surfaces branded TH/EN/ZH
- [x] 401 gate parity with the Worker's signed-out reply (bare string `error` ≠ error code)
- [x] Hydration-safe asset URLs (`useAssetUrl`) so the HYPE owl loads behind `/my-mmd`
- [x] `rise-in` is motion opt-in; SSR content never starts hidden
- [x] Reference shell (`public/my-mmd-shell.html`) resolves `/my-mmd/*` and `/member/my-mmd/*` sub-routes natively
- [x] Bounded unresolved-state UX: a 2xx `state:"checking"` reply no longer renders "กำลังตรวจสอบ" forever — one resolving block, re-read ≤10 s, then one Per-voice resolution panel (LINE + ลองใหม่); unresolved `0` points withheld; Vitest suite (`bun run test`, 22 tests)

## Verification (local gateway simulation, no deploy)

React bundle at `dist/` behind a Worker-like gateway (`/my-mmd` mount, `/my-mmd-assets/` rewrite, LINE Android UA, 390px):
root + membership / points / coupons / history / profile × {good, partial, weird-enum, empty, envelope, html, 404, 500, okfalse, 401}
→ 60/60 render header + nav + main, no page errors, no horizontal overflow; 401 opens the LINE gate; failures show "โหลดข้อมูลไม่สำเร็จ / ลองใหม่".
Forced render crash → branded route fallback with nav intact (prefixed and root-hosted). Unknown path → branded not-found.
Shell mode: all six `/my-mmd/*` routes map to the right tab.

## Production state (Worker-owned, not this repo)

- `www.mmdbkk.com/my-mmd/` currently serves the static incident-rollback shell (mmd-workers PR #646).
- React restoration gates: real-device route visibility, authenticated LINE return, JS-failure recovery, authenticated payload/shape match.

## Ready

- [ ] Worker front-gate setup guide for `/my-mmd` (routes, prefix stripping, `/my-mmd-assets/` rewrite, legacy 308, API ownership, go-live checklist) written up in `docs/worker-my-mmd-gateway.md` — hand to the mmd-workers team
- [ ] Ask the Worker to send an explicit `resolved: true|false` on every `/api/member/app/*` 2xx reply so the UI never has to fall back to content classifiers — request written up in `docs/worker-resolved-flag-request.md`, waiting on the Worker team


- [ ] Shared-session endpoints (`/api/member/app/session/*`) are still 404 upstream — Current Job card stays hidden until the Worker ships them (contract in `docs/shared-session-contract.md`)
- [ ] Once the Worker restores the React front gate, re-run the gateway simulation against the published origin and capture real-device screenshots for the PR #646 exit gates
- [ ] Remove the `?demo=1` scenario switcher path from production bundles if the Lovable host ever becomes customer-reachable (today it is preview-only)
