# MY MMS — Member Dashboard

Customer-facing **Male Massage (MMS)** workspace / LINE Mini App.
Mobile-first React + TypeScript + Tailwind on TanStack Start.

This app owns **pixels and interaction only**. It contains no auth system, no
database, and no business authority. Identity, booking truth, payment truth,
therapist matching and lifecycle state all live in the existing Cloudflare
Workers / Airtable backend. Missing or unverified data fails closed as
`กำลังตรวจสอบ` (Checking) — never as an invented status.

MY MMS is a **separate product from MY MMD**. No tier, points, coupons,
entitlement, Kenji, SIGIL, Black Card, or MMD payment data appears here.

## Screens

| Route            | Content |
| ---------------- | ------- |
| `/`              | Greeting + identity state, current/next booking first, action alert only when the backend says action is needed, `จอง Therapist` CTA, swipeable shortcuts |
| `/bookings`      | Thai-first status chips (รอดำเนินการ / ยืนยันแล้ว / กำลังให้บริการ / เสร็จสิ้น / ยกเลิก) and booking cards |
| `/bookings/$id`  | Booking detail with safe timeline, payment state, next action |
| `/therapists`    | `เคยใช้บริการ` and `รายการโปรด`, public-safe cards, favorite callback |
| `/payment`       | Backend-provided deposit / balance / policy labels and states |
| `/after-service` | Rating, feedback, tip intent, report an issue — all via adapter callbacks |
| `/profile`       | Display name, LINE summary, safe contact fields, language, preferences |
| `/support`       | LINE OA `@malemassage` handoff + issue categories with booking context |

## Data layer

- `src/lib/mms/config.ts` — all route + endpoint constants, booking route
  (`/member/mms-booking` by default, override with `VITE_MMS_BOOKING_ROUTE`).
- `src/lib/mms/types.ts` — typed models: `CustomerSummary`, `ProfileSummary`,
  `BookingSummary`, `BookingDetail`, `TherapistPublicSummary`, `PaymentSummary`,
  `AfterServicePayload`, `SupportPayload`.
- `src/lib/mms/mock-provider.ts` — visual preview only. Scenarios via
  `?mms_demo=upcoming|deposit|empty|checking|error`. **Never production truth.**
- `src/lib/mms/live-provider.ts` — same-origin `fetch` with
  `credentials: "same-origin"`, bounded timeout + single retry, fail-closed
  shape validation.

No Supabase, no localStorage authority, no browser-side role or entitlement logic.

## Backend contract required before production

Every path below is a **proposed placeholder**. None is confirmed by the Worker
team. The live adapter will not work until these are implemented (or the
constants in `src/lib/mms/config.ts` are repointed at the real ones).

Reads — same-origin, session cookie, JSON, optional `{ data: … }` wrapper:

| Proposed endpoint | Must return |
| ----------------- | ----------- |
| `GET /api/mms/app/customer` | `CustomerSummary` + `ProfileSummary` fields: display name, identity state (`verified`/`checking`/`unverified`), LINE account summary, contact fields flagged `safeToDisplay`, preferred services/areas |
| `GET /api/mms/app/bookings/current` | Current or next `BookingSummary`, or `null` when none |
| `GET /api/mms/app/bookings` | All `BookingSummary` records with backend-decided status |
| `GET /api/mms/app/bookings/:id` | `BookingDetail` incl. display-safe ref, service, schedule label, area, permitted therapist public name/photo, amount summary, payment state, next action, timeline entries |
| `GET /api/mms/app/therapists` | `{ recent: TherapistPublicSummary[], favorites: TherapistPublicSummary[] }` — public fields only, no internal review status, notes, matching score, real identity, contact, or payout data |
| `GET /api/mms/app/payments` | `PaymentSummary[]` with **pre-formatted** total/deposit/balance/policy/instruction labels and state (`required`/`submitted`/`verified`/`completed`/`unavailable`) plus optional safe proof/receipt URLs |

Writes — the browser only submits intent; the backend decides outcome:

| Proposed endpoint | Payload |
| ----------------- | ------- |
| `POST /api/mms/app/therapists/:id/favorite` | `{ favorite: boolean }` |
| `POST /api/mms/app/after-service` | `AfterServicePayload` — booking id, rating, feedback, tip intent, issue category/note |
| `POST /api/mms/app/support` | `SupportPayload` — category, message, booking ref |

Backend rules the UI depends on:

- Amounts and the 50% deposit / 50% remaining policy arrive as **strings from
  the backend**. The browser never calculates authoritative money.
- Status vocabulary is fixed by the backend; unknown values render as Checking.
- Therapist photos/names appear only when the backend marks them shareable.
- After-service submission must never be treated as completion by the client.

## Development

```bash
bun install
bun run dev     # http://localhost:8080
```

Preview only. Do not deploy or publish without an explicit request.

## Therapist auth — REAL, implemented in mms-worker (GitHub/main)

These endpoints exist today and are authoritative. Same-origin, cookie
`__Secure-mms_therapist_session` (HttpOnly/Secure/SameSite=Lax,
`Path=/male-massage/therapists`). The browser never reads the cookie, never
stores an ID token, and never infers the therapist role.

| Endpoint | Use |
| --- | --- |
| `POST /male-massage/therapists/api/auth/line` | LINE login (Worker-owned page) |
| `GET /male-massage/therapists/api/auth/me` | Session bootstrap used by `getTherapistContext()` |
| `POST /male-massage/therapists/api/auth/logout` | Logout, then back to `/male-massage/therapists/login` |

Profile mapping (`src/lib/mms/therapist-auth.ts`):
`role === 'mms_therapist'` → `audience: 'therapist'`; `display_name` →
`therapistPublicName`; `therapist_id` → `therapistRefDisplay`;
`availability_status` → `availabilityLabel`; `incomingOfferCount` stays `null`
until an offers endpoint provides it. 401 / missing session → session required;
403 → access unavailable; network/timeout → Checking; anything else → Error.

Canonical entry route: **`/male-massage/therapists/me`**
(`src/routes/male-massage.therapists.me.tsx`) — the `next_route` returned after
LINE login. It re-reads `auth/me` and renders the Jobs home immediately for a
valid session; it never shows a second login screen and never opens a new window.

Mock preview (never a production fallback):
`?mms_auth=ok | session | forbidden | error`.

## Therapist dispatch — confirmed Worker contract

Canonical flow: **MMS AI → Matching → Therapist → Accept → Service**.
Everything below is a **CONFIRMED** contract (`src/lib/mms/config.ts` →
`MMS_DISPATCH_ENDPOINTS`, base `/male-massage/therapists/api/app` — inside the
therapist session cookie path boundary). Same-origin, `credentials: "same-origin"`, no tokens in the browser.

| Adapter method | Endpoint | Must return |
| --- | --- | --- |
| `getTherapistContext()` | `GET /male-massage/therapists/api/auth/me` | therapist profile; mapped to `audience`, public name, ref, availability label |
| `getIncomingJobOffers()` | `GET /offers` | array of pre-accept-safe offers |
| `getJobOffer(jobId)` | `GET /offers/:id` | canonical offer (state, expiry, payout label) |
| `acceptJob(jobId, requestKey)` | `POST /offers/:id/accept` | `{ jobId, state, message }`; idempotent on `requestKey`; `TAKEN` on conflict, `EXPIRED` past expiry |
| `declineJob(jobId, reason)` | `POST /offers/:id/decline` | `{ jobId, state: "DECLINED" }` |
| `getJobDetail(jobId)` | `GET /jobs/:id` | accepted job + `disclosure` block + timeline |
| `getJobs()` | `GET /jobs` | current, upcoming and completed jobs |
| `startJob(jobId, requestKey)` | `POST /jobs/:id/start` | `{ jobId, state: "IN_PROGRESS", message }` |
| `completeJob(jobId, requestKey)` | `POST /jobs/:id/complete` | `{ jobId, state: "COMPLETED", message }` |

Business-terminal action results (`TAKEN`, `EXPIRED`, `CANCELLED`, …) may arrive
as **HTTP 409/410** carrying `data.state`. The app parses and displays that
canonical state; only network, malformed or stateless failures fail closed to
Checking.


Backend-owned, never computed in the browser:

- **Audience/role.** The therapist surfaces open only when the backend says
  `audience === "therapist"`. Otherwise the UI fails closed to Checking.
- **Job state.** `OFFERED · ACCEPTING · ACCEPTED · DECLINED · EXPIRED · TAKEN ·
  CANCELLED · IN_PROGRESS · COMPLETED · CHECKING · ERROR`. The app never marks a
  job accepted, completed or paid locally.
- **Payout.** Pre-formatted `payoutLabel` / `payoutSummaryLabel` strings only.
- **Expiry.** `expiresAt` ISO timestamp. The countdown is visual only.
- **Disclosure.** Customer display label, address, map URL and contact are sent
  only after the backend confirms ACCEPTED and marks them disclose-safe. Before
  accept the payload must contain no customer name, phone, exact address, LINE
  identity, private notes or payment internals.

Refresh strategy (no websocket endpoint is invented): route load, visibility /
focus return, after every accept or decline, plus a bounded 15s poll while an
offer is on screen. `subscribeToJobUpdates(cb)` is an optional adapter hook the
Worker can back with a real push channel later.

Deep link: `/accept/job?id=MMS-J-...` (also `?job=`). Only the identifier is
read from the URL — service, payout, expiry and state always come from the
adapter. After a confirmed accept the app routes to `/jobs/$jobId`.
