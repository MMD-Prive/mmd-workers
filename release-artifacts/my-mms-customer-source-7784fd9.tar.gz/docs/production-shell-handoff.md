# MY MMS · Therapist work app — production shell handoff

Artifact: `public/my-mms-work-shell.html`
Pattern: same as `public/my-mmd-shell.html` — a self-contained single-file
HTML/CSS/vanilla-JS rendering of the existing work/jobs interface. No React, no
hydration, no external JS chunks, no mock data, no tokens, no storage.

## Mount

Serve the file same-origin from the Cloudflare Worker at:

```
/male-massage/therapists/app
```

`/male-massage/therapists/me` stays the existing external onboarding/profile
landing. The shell never renders or redirects it — it only links back to it in
locked/revoked states.

All backend calls are relative and use `credentials: "same-origin"`, so they
stay inside the `__Secure-mms_therapist_session` cookie path
(`Path=/male-massage/therapists`).

## Endpoints the shell expects

| Call | Purpose |
| --- | --- |
| `GET /male-massage/therapists/api/auth/me` | Session/role only. Requires `role: "mms_therapist"`. |
| `GET /male-massage/therapists/api/app/access` | Canonical MY MMS access gate. |
| `GET /male-massage/therapists/api/app/jobs` | Job list (current + history). |
| `GET /male-massage/therapists/api/app/jobs/:id` | Job detail incl. `disclosure` and `timeline`. |
| `GET /male-massage/therapists/api/app/offers` | Live offers; only `state: "OFFERED"` opens the sheet. |
| `GET /male-massage/therapists/api/app/offers/:id` | Canonical single offer for the sheet. |
| `POST /male-massage/therapists/api/app/offers/:id/accept` | Body `{ jobId, requestKey }`. |
| `POST /male-massage/therapists/api/app/offers/:id/decline` | Body `{ jobId, reason }`. |
| `POST /male-massage/therapists/api/app/jobs/:id/start` | Body `{ jobId, requestKey }` — ACCEPTED → IN_PROGRESS. |
| `POST /male-massage/therapists/api/app/jobs/:id/complete` | Body `{ jobId, requestKey }` — IN_PROGRESS → COMPLETED. |
| `POST /male-massage/therapists/api/auth/logout` | Clears the session, then returns to login. |

Responses may be raw or wrapped as `{ ok, data }`; the shell unwraps `data` and
treats `ok: false` as a failure. Business-terminal action results (`TAKEN`,
`EXPIRED`, `CANCELLED`, …) may arrive as HTTP 409/410 with `data.state`; the
shell preserves that canonical state instead of degrading it to CHECKING. Only
network, malformed or stateless failures fail closed.

## Access contract (fail closed)

```json
{ "ok": true, "data": { "therapist_id": "…", "access": "locked|approved|revoked",
  "can_open": true, "app_route": "/male-massage/therapists/app", "approved_at": null } }
```

- Work/job requests are issued **only** when `access === "approved"` and
  `can_open === true`.
- Authenticated `mms_therapist` alone is not sufficient.
- `locked` / `revoked` → no work data; access-unavailable screen with a link to
  `/male-massage/therapists/me`.
- `401` → session-required screen linking to `/male-massage/therapists/login`.
- Missing, unknown, malformed, timeout, network, `5xx` → Checking/Retry, no work
  data. Access is never inferred from profile completion, status, availability,
  matching, or any frontend state.

## Job / offer behaviour preserved from the React app

- Pre-accept offer sheet shows only safe fields: service, duration, schedule,
  zone, travel/ETA, backend-formatted payout, backend `expires_at` countdown
  (visual only). Customer identity, exact address, contact and payment internals
  are never rendered before accept.
- Accept is disabled while in flight, sends an idempotency `requestKey`, and
  never marks `ACCEPTED` locally — only a backend `state` does. Conflict returns
  `TAKEN` ("งานนี้มี Therapist รับแล้ว"), expiry returns `EXPIRED`, network or
  unknown falls back to `CHECKING`.
- Job detail unlocks address / map / customer label only when
  `disclosure.locationUnlocked` and the backend supplies the field.
- Refresh strategy: boot, visibility/focus return, and after every write. No
  websocket endpoint is invented.

## Notes

- Mobile-first, max width 28rem, safe-area padding, 44–52px tap targets,
  `prefers-reduced-motion` honoured.
- Colors, labels and states mirror `src/lib/mms/*` and `src/components/mms/*`.
- Route/endpoint constants mirror `src/lib/mms/config.ts`
  (`MMS_ROUTES.therapistApp`, `THERAPIST_APP_ACCESS`, `MMS_DISPATCH_ENDPOINTS`).
