# คำขอถึงทีม MMD Worker — เพิ่ม `resolved` flag ทุก `/api/member/app/*`

สถานะ: คำขอ (frontend-side ยังไม่แก้ authority ใด ๆ)
วันที่: 2026-09-06

## ปัญหาที่พบจริงบน production (LINE Android)

`/api/member/app/*` ตอบ `200` พร้อม payload ที่ยังไม่ resolve (`state: "checking"`,
`level: "unknown"`, `confirmedBalance: 0`) โดยไม่มีสัญญาณชัดเจนว่า "ยังไม่พร้อม" หรือ
"นี่คือคำตอบสุดท้าย" ฝั่ง UI จึงต้องเดาจาก **เนื้อหา** ของ payload ซึ่ง:

- เสี่ยงแสดง `0` ทั้งที่ค่าจริงคือ "ไม่ทราบ"
- แยกไม่ออกระหว่าง "สมาชิกมี 0 แต้มจริง" กับ "ยังหาค่าไม่ได้"
- ทำให้ลูกค้าค้างที่ `กำลังตรวจสอบ` ได้นาน

## สิ่งที่ขอ

ทุก response 2xx ของ `/api/member/app/*` แนบ flag ที่ระดับ envelope:

```jsonc
{
  "ok": true,
  "resolved": true,          // REQUIRED: boolean เท่านั้น ห้าม null / string
  "state": "ok",             // optional, informational
  "data": { /* ... */ }
}
```

กติกา:

1. `resolved: true` = ข้อมูลสมาชิกถูก resolve จากแหล่งจริงแล้ว ค่าที่ส่งมาคือคำตอบสุดท้าย
   ของช่วงเวลานั้น (รวมกรณีค่าว่างจริง เช่น 0 แต้ม, coupon 0 ใบ, history ว่าง)
2. `resolved: false` = session ใช้ได้ แต่ยัง map member record ไม่ได้ / upstream ยังไม่ตอบ
   ห้ามเติมค่า default (`0`, `"unknown"`, `"checking"`) ให้ดูเหมือนข้อมูลจริง
   ถ้าไม่ทราบค่า ให้ส่ง `null` หรือไม่ส่ง field นั้นเลย
3. ห้ามใช้ `resolved: true` คู่กับ placeholder ที่ไม่ใช่ค่าจริง
4. `resolved` ที่ระดับ envelope มีอำนาจเหนือค่าใน `data` เสมอ
5. ครอบคลุมทุก endpoint: `dashboard`, `profile`, `membership`, `points`, `coupons`,
   `history`, `care`, และ `session/*`

## ค่าตัวเลข / เงิน / แต้ม

- ไม่ทราบ → `null` (ห้าม `0`)
- ทราบและเป็นศูนย์จริง → `0` พร้อม `resolved: true`
- `approved_discount_percent` ยังคงเป็น backend-only ตามเดิม

## กรณี error

- ต้อง verify LINE session ใหม่ → `401` (ไม่มี code หรือ `LIFF_SESSION_REQUIRED`)
- ไม่มีสิทธิ์ → `403`
- ระบบล่ม / upstream ล้ม → `5xx`

ห้ามใช้ `200 { ok: false }` แทน error state เหล่านี้

## พฤติกรรมฝั่ง UI ปัจจุบัน (เพื่อให้ทีม Worker เห็นภาพ)

- อ่าน `resolved` ก่อนเสมอ ถ้าไม่มีจึงถอยไปเดาจากเนื้อหา (fallback ที่เราอยากเลิกใช้)
- `resolved: false` → re-read แบบมีขอบเขต (~10–12 วินาที) แล้วหยุด แสดงหน้าจอเดียวว่า
  "ยังยืนยันข้อมูลสมาชิกไม่ได้" พร้อมปุ่มยืนยันผ่าน LINE และลองใหม่
- ทุก request มี client timeout ไม่ค้างไม่มีที่สิ้นสุด
- Browser ไม่คำนวณ/ไม่อนุมาน entitlement, points, level, access ใด ๆ

เมื่อ Worker ส่ง `resolved` ครบทุก endpoint แล้ว ฝั่ง UI จะปิด content-based fallback ทิ้ง
