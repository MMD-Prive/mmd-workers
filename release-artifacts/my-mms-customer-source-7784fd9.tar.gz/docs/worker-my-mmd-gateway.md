# MMD Worker — front gate สำหรับ `/my-mmd` (คู่มือตั้งค่าเอง)

สถานะ: คู่มือฝั่ง presentation (Lovable) — โค้ดจริงต้อง commit ใน `MMD-Prive/mmd-workers`
วันที่: 2026-09-06

เป้าหมาย: เมื่อ Worker พร้อม ให้ `https://www.mmdbkk.com/my-mmd/` เสิร์ฟ React app นี้ได้ทันที
โดย **ไม่ต้องแก้ฝั่ง Lovable อีก**

---

## 1. สัญญาที่ฝั่ง UI ยึดอยู่แล้ว (อย่าเปลี่ยน)

| หัวข้อ | ค่า |
| --- | --- |
| Canonical path | `/my-mmd` และ `/my-mmd/*` |
| Legacy path | `/member/my-mmd*` → `308` ไป `/my-mmd/...` |
| Upstream origin | `https://my-mmd-member-profile.lovable.app` |
| Path ที่ส่งขึ้น upstream | **ตัด prefix `/my-mmd` ออก** (SSR ของแอป mount ที่ `/`) |
| Static asset prefix | `/my-mmd-assets/*` → upstream `/assets/*` |
| Member API | `/api/member/app/*` = Worker เสิร์ฟเอง **ห้าม** proxy ไป Lovable |
| Credentials | same-origin cookie เท่านั้น ไม่มี token ใน browser |
| หลัง LINE verify | Worker redirect กลับ `/my-mmd/` |

ข้อสำคัญ: แอปตรวจ prefix จาก `window.location.pathname` เอง แล้วเติม `/my-mmd`
ให้ลิงก์และ asset ทั้งหมด ดังนั้น Worker **ต้อง** ส่ง path แบบตัด prefix ขึ้น upstream
และ **ต้อง** map `/my-mmd-assets/` กลับเป็น `/assets/` ทุกครั้ง

---

## 2. ตัวอย่าง Worker (Module syntax)

```js
const UPSTREAM = "https://my-mmd-member-profile.lovable.app";
const PREFIX = "/my-mmd";
const ASSET_PREFIX = "/my-mmd-assets";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const { pathname } = url;

    // 1) API ของสมาชิก = ของ Worker เอง (อย่าให้หลุดไป Lovable)
    if (pathname.startsWith("/api/member/app/")) {
      return handleMemberApi(request, env, ctx); // โค้ด BFF เดิมของ mmd-workers
    }

    // 2) legacy redirect
    if (pathname === "/member/my-mmd" || pathname.startsWith("/member/my-mmd/")) {
      const rest = pathname.slice("/member/my-mmd".length) || "/";
      return Response.redirect(`${url.origin}${PREFIX}${rest}${url.search}`, 308);
    }

    // 3) asset: /my-mmd-assets/x.js -> upstream /assets/x.js
    if (pathname.startsWith(`${ASSET_PREFIX}/`)) {
      const upstreamPath = `/assets${pathname.slice(ASSET_PREFIX.length)}`;
      return proxy(request, `${UPSTREAM}${upstreamPath}${url.search}`, { asset: true });
    }

    // 4) หน้าแอป
    if (pathname === PREFIX) {
      return Response.redirect(`${url.origin}${PREFIX}/`, 308);
    }
    if (pathname.startsWith(`${PREFIX}/`)) {
      const upstreamPath = pathname.slice(PREFIX.length) || "/";
      return proxy(request, `${UPSTREAM}${upstreamPath}${url.search}`);
    }

    return env.ASSETS ? env.ASSETS.fetch(request) : fetch(request);
  },
};

async function proxy(request, target, { asset = false } = {}) {
  const headers = new Headers(request.headers);
  headers.delete("cookie");            // upstream ไม่ต้องเห็น session cookie ของสมาชิก
  headers.set("x-forwarded-host", new URL(request.url).host);

  const upstream = await fetch(target, {
    method: request.method,
    headers,
    body: ["GET", "HEAD"].includes(request.method) ? undefined : request.body,
    redirect: "manual",
  });

  if (asset) {
    const out = new Response(upstream.body, upstream);
    out.headers.set("cache-control", "public, max-age=31536000, immutable");
    return out;
  }

  const type = upstream.headers.get("content-type") ?? "";
  if (!type.includes("text/html")) return upstream;

  // เขียน path ใน HTML ให้อยู่ใต้ /my-mmd
  let html = await upstream.text();
  html = html
    .replaceAll('="/assets/', `="${ASSET_PREFIX}/`)
    .replaceAll('"/assets/', `"${ASSET_PREFIX}/`)
    .replaceAll('="/hype-loader.png', `="${PREFIX}/hype-loader.png`)
    .replaceAll('="/favicon.ico', `="${PREFIX}/favicon.ico`);

  const out = new Response(html, upstream);
  out.headers.set("content-type", "text/html; charset=utf-8");
  out.headers.set("cache-control", "no-store");
  out.headers.set("x-mmd-ui-source", "lovable-full-app-proxy");
  out.headers.delete("content-length");
  return out;
}
```

`/my-mmd/hype-loader.png`, `/my-mmd/favicon.ico`, `/my-mmd/robots.txt` เข้าเงื่อนไขข้อ 4
อยู่แล้ว (ตัด prefix แล้ว proxy) จึงไม่ต้องมี rule แยก

---

## 3. Route / config

`wrangler.toml`

```toml
routes = [
  { pattern = "www.mmdbkk.com/my-mmd*",        zone_name = "mmdbkk.com" },
  { pattern = "www.mmdbkk.com/my-mmd-assets/*", zone_name = "mmdbkk.com" },
  { pattern = "www.mmdbkk.com/member/my-mmd*",  zone_name = "mmdbkk.com" },
  { pattern = "www.mmdbkk.com/api/member/app/*", zone_name = "mmdbkk.com" },
]
```

ถ้าใช้ `mmdbkk.com` (ไม่มี www) ให้เพิ่ม pattern ชุดเดียวกันของโดเมนนั้น หรือ redirect
apex → www ก่อน

---

## 4. LINE verification return

หลังยืนยัน LINE MINI App สำเร็จ ให้ Worker set session cookie แล้ว
`302` กลับไป `https://www.mmdbkk.com/my-mmd/` เท่านั้น
(ปุ่มยืนยันในแอปเปิด `https://miniapp.line.me/2010862595-yT4DCEMc/?intent=status`
เมื่อผู้ใช้กดเองเท่านั้น)

---

## 5. เช็คลิสต์ก่อนเปิดใช้จริง

- [ ] `GET /my-mmd/` → `200 text/html`, มี `<div id="root">` และ script ชี้ `/my-mmd-assets/...`
- [ ] `GET /my-mmd-assets/<chunk>.js` → `200 application/javascript`
- [ ] `GET /my-mmd/membership|points|coupons|history|profile` → `200` (ไม่ใช่ 404 ของ origin)
- [ ] `GET /member/my-mmd/points` → `308` → `/my-mmd/points`
- [ ] `GET /api/member/app/dashboard` ไม่มี session → `401` (ไม่ใช่ `200 {ok:false}`)
- [ ] `GET /api/member/app/dashboard` มี session → `200` พร้อม `resolved: true|false`
      ตาม `docs/worker-resolved-flag-request.md`
- [ ] เปิดจริงบน LINE Android แล้วเห็น HYPE loader → หน้า Home ภายในไม่กี่วินาที

เมื่อครบทั้งหมด `/my-mmd/` จะทำงานทันทีโดยไม่ต้องแก้ฝั่ง Lovable

---

## 6. อ้างอิงฝั่ง Worker (canonical handoff 2026-09-06)

Repo: `MMD-Prive/mmd-workers`

- `member-dashboard-chat-worker/src/my-mmd-lovable-app-front-gate.js` — front gate จริง
- `member-pages-worker/src/member-app-api.js` — member reads
- `member-dashboard-chat-worker/wrangler.toml` — routes/bindings
- `docs/architecture/MY_MMD_MEMBER_APP_API_V1.md`
- `docs/architecture/MY_MMD_LOVABLE_APP_CANON_20260905.md`
- `docs/ops/MMD-MY-MMD-ENDPOINT-MEMORY-2026-09-06.md`

Chain: `LINE session → mmdbkk.com/my-mmd/ → /api/member/app/* →
member-dashboard-chat-worker → MEMBER_PAGES_WORKER → member-pages-worker →
my_mmd_entitlement_resolver_v1`

เส้นทาง identity/session ต่อไปนี้เป็นของ Worker ฝั่ง Lovable ไม่แตะและไม่แทนที่:
`POST /member/api/liff/start|intent|hall-token`, `GET /member/api/liff/status|profile`

ห้ามสร้าง `/my-mmd/api/*` — namespace เดียวคือ `/api/member/app/*`
"My MMD ยังเปิดไม่สำเร็จครับ" = Worker recovery UI (ไม่ได้แปลว่าข้อมูลสมาชิกหาย)
