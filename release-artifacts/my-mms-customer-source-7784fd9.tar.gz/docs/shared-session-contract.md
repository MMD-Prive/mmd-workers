# Shared Session — customer-safe read model (MY MMD)

MY MMD and MMD MODEL are separate presentation/identity lanes reading and
writing through ONE canonical Session owned by the existing MMD Cloudflare
Workers. Lovable owns pixels and interaction only.

## Boundaries

- Same-origin `/api/member/app/session/*` with `credentials: "same-origin"`.
- No Supabase, no new auth, no new database, no localStorage authority.
- The browser never infers lifecycle, ETA, acknowledgement, eligibility or risk.
- Missing / unverified / erroring => fail closed (surface hidden or "checking").
- A deep-link `t` query value is an OPAQUE credential. It is never parsed in the
  browser and never used to render job facts; it is forwarded untouched to the
  same-origin endpoints, which are responsible for role-binding it to the
  signed-in customer.
- Membership / points / coupons architecture is untouched; this is additive.

## Required endpoints (NOT YET AVAILABLE — current gap)

### `GET /api/member/app/session/current`
Returns the customer-safe current/upcoming session, or `204` when none.

```jsonc
{
  "sessionId": "opaque-support-ref",      // never parsed by the browser
  "lifecycle": "confirmed",                // normalized by backend, see below
  "jobDate": "2026-09-12",
  "jobTimeLabel": "21:00 – 22:30",
  "locationDisplay": "Hotel name / area approved for the customer",
  "model": { "displayName": "Working name", "displayAllowed": true },
  "acknowledgement": {
    "customerAckAt": null,
    "modelAcknowledged": false,
    "modelAckAt": null,
    "customerAckAllowed": true
  },
  "etaLabel": null,                        // verified ETA copy only
  "nextMessage": null                      // next customer-safe message
}
```

### `GET /api/member/app/session/context?t=<opaque>`
Exchanges the signed deep-link credential for the same customer-safe session.

```jsonc
{ "valid": true, "session": { /* CurrentSession */ } }
```
`valid:false` must render nothing — no fake success.

### `POST /api/member/app/session/ack`
Body `{ "session_id": "...", "t": "<opaque|omitted>" }`.
Writes ONLY the customer acknowledgement (`customerAckAt`) and returns the
refreshed customer-safe session. It must never move lifecycle or model state,
and must reject when `customerAckAllowed` is false.

## Normalized lifecycle

`checking | pending_confirmation | confirmed | preparing | en_route | nearby |
arrived | met_customer | in_progress | completed | cancelled | unavailable`

Only the backend produces these values.

## Copy rules

- Before model acknowledgement: "กำลังรอ Model รับทราบงาน".
- After backend says acknowledged: "Model รับทราบงานแล้ว ✓".
- `en_route`: "กำลังเดินทางมาหาคุณ", plus the backend ETA when supplied.
- Never promise attendance ("รับประกันว่าจะมา") and never surface internal
  risk / follow-up / dispatch / payout fields.

## Preview fixture

`createMockSessionProvider()` runs only on Lovable/local preview hosts and is
clearly non-authoritative (คุณหนุ่ย / Mek · V Top / 12 Sep 2026 / Mida Hotel
Ngamwongwan). It is never used on mmdbkk.com.
