import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import { AppShell } from "../components/mms/app-shell";
import { MockRibbon, Section, StatePanel, Surface } from "../components/mms/primitives";
import { JobsPage } from "./jobs.index";
import {
  MMS_THERAPIST_LOGIN_URL,
  shouldUseLiveProvider,
} from "../lib/mms/config";
import { fetchTherapistSession, type TherapistSession } from "../lib/mms/therapist-auth";
import { mockTherapistSession, readAuthScenario } from "../lib/mms/therapist-auth-mock";

/**
 * CANONICAL POST-LINE-LOGIN ENTRY ROUTE.
 *
 * mms-worker returns next_route: '/male-massage/therapists/me' after a
 * successful LINE login. This route re-reads the real session with
 * same-origin credentials and, when the backend confirms role
 * 'mms_therapist', drops the therapist straight into the Jobs home — no
 * second login screen, no window.open, LIFF/webview safe.
 */
export const Route = createFileRoute("/male-massage/therapists/me")({
  head: () => ({
    meta: [
      { title: "MY MMS · Therapist" },
      {
        name: "description",
        content: "หน้าเข้าสู่ระบบ Therapist ของ Male Massage หลังเข้าสู่ระบบผ่าน LINE",
      },
      { property: "og:title", content: "MY MMS · Therapist" },
      { property: "og:description", content: "พื้นที่รับงานของ Therapist Male Massage" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: TherapistEntryPage,
});

function useTherapistSession() {
  const live = shouldUseLiveProvider();
  const scenario = readAuthScenario();
  const useMock = !live && scenario !== "off";
  return {
    useMock,
    query: useQuery<TherapistSession>({
      queryKey: ["mms", "therapist", "session", useMock ? scenario : "live"],
      queryFn: () => (useMock ? mockTherapistSession(scenario) : fetchTherapistSession()),
      retry: 0,
      staleTime: 10_000,
      refetchOnWindowFocus: true,
    }),
  };
}

function LoginLink() {
  return (
    <a
      href={MMS_THERAPIST_LOGIN_URL}
      className="mt-3 inline-flex min-h-12 items-center justify-center rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground"
    >
      เข้าสู่ระบบผ่าน LINE
    </a>
  );
}

function TherapistEntryPage() {
  const { useMock, query } = useTherapistSession();
  const session = query.data;

  const body = () => {
    if (query.isPending) {
      return <StatePanel state="loading" title="กำลังตรวจสอบสิทธิ์ Therapist" />;
    }
    if (query.isError || session?.status === "error") {
      return (
        <StatePanel
          state="error"
          title="ยังตรวจสอบสิทธิ์ไม่ได้"
          hint="ระบบ Male Massage ยังตอบกลับไม่ครบ กรุณาลองใหม่อีกครั้ง"
          onRetry={() => query.refetch()}
        />
      );
    }
    if (session?.status === "forbidden") {
      return (
        <Surface className="text-center">
          <p className="text-sm font-semibold">บัญชีนี้ยังใช้งาน Therapist ไม่ได้</p>
          <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
            สิทธิ์การรับงานถูกระงับหรือยังไม่เปิดใช้งาน ระบบจะไม่แสดงข้อมูลงานใด ๆ
          </p>

        </Surface>
      );
    }
    return (
      <Surface className="text-center">
        <p className="text-sm font-semibold">กรุณาเข้าสู่ระบบผ่าน LINE</p>
        <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
          เซสชัน Therapist หมดอายุหรือยังไม่ได้เข้าสู่ระบบ
        </p>
        <LoginLink />
      </Surface>
    );
  };

  // Backend-confirmed therapist: render the Jobs home directly.
  if (session?.status === "authenticated") return <JobsPage />;

  return (
    <AppShell>
      {useMock && <MockRibbon />}
      <Section title="MY MMS · Therapist">{body()}</Section>
    </AppShell>
  );
}
