import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { MmsProvider } from "../lib/mms/provider-context";
import { MmsDispatchProviderRoot } from "../lib/mms/dispatch-context";
import { JobOfferHost } from "../components/mms/job-offer-sheet";
import { Toaster } from "../components/ui/sonner";
import mmsSymbol from "../assets/mms-logo-symbol.svg.asset.json";

/** Minimal MMS bar for surfaces rendered outside the provider tree. */
function BareShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-[100dvh] bg-background text-foreground">
      <header className="sticky top-0 z-20 border-b border-border/70 bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-md items-center justify-between px-5 py-4 md:max-w-2xl">
          <Link to="/" className="flex items-center gap-2.5">
            <img src={mmsSymbol.url} alt="" aria-hidden className="h-8 w-8" />
            <span className="leading-tight">
              <span className="font-display text-[1rem] font-semibold tracking-[0.2em] text-[color:var(--leaf)]">
                MY MMS
              </span>
              <span className="block text-[0.6rem] uppercase tracking-[0.24em] text-muted-foreground">
                Male Massage
              </span>
            </span>
          </Link>
        </div>
      </header>
      <main className="mx-auto max-w-md px-5 py-6 md:max-w-2xl">{children}</main>
    </div>
  );
}

function NotFoundComponent() {
  return (
    <BareShell>
      <section className="surface-card p-6 text-center">
        <p className="eyebrow text-[color:var(--leaf)]">MY MMS</p>
        <h1 className="mt-2 text-lg font-semibold tracking-tight">ไม่พบหน้านี้</h1>
        <p className="mt-1 text-sm text-muted-foreground">Page not found · 找不到此页面</p>
        <Link
          to="/"
          className="mt-5 inline-flex min-h-12 w-full items-center justify-center rounded-full bg-primary px-6 text-sm font-medium text-primary-foreground"
        >
          กลับหน้าแรก
        </Link>
      </section>
    </BareShell>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <BareShell>
      <section role="alert" className="surface-card p-6 text-center">
        <p className="eyebrow text-[color:var(--leaf)]">MY MMS</p>
        <h1 className="mt-2 text-lg font-semibold tracking-tight">เปิดหน้านี้ไม่สำเร็จ</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          ข้อมูลการจองของคุณยังอยู่ครบในระบบ ลองเปิดอีกครั้งได้เลยครับ
        </p>
        <div className="mt-5 flex flex-col gap-2">
          <button
            type="button"
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex min-h-12 items-center justify-center rounded-full bg-primary px-6 text-sm font-medium text-primary-foreground"
          >
            ลองอีกครั้ง
          </button>
          <Link
            to="/"
            className="inline-flex min-h-12 items-center justify-center rounded-full border border-border bg-surface px-6 text-sm font-medium"
          >
            กลับหน้าแรก
          </Link>
        </div>
      </section>
    </BareShell>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1, viewport-fit=cover",
      },
      { name: "theme-color", content: "#f7f6f1" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@400;500;600;700&family=Noto+Sans:wght@400;500;600&display=swap",
      },
      { rel: "icon", href: "/favicon.svg", type: "image/svg+xml" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="th">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <MmsProvider>
        <MmsDispatchProviderRoot>
          <Outlet />
          <JobOfferHost />
        </MmsDispatchProviderRoot>
        <Toaster position="top-center" richColors />
      </MmsProvider>
    </QueryClientProvider>
  );
}
