import { createFileRoute } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { AppShell } from "../components/mms/app-shell";
import { MockRibbon, Section, StatePanel } from "../components/mms/primitives";
import { useBookings, useMms, useSubmitAfterService } from "../lib/mms/provider-context";
import type { AfterServiceIssue } from "../lib/mms/types";
import { cn } from "../lib/utils";

export const Route = createFileRoute("/after-service")({
  head: () => ({
    meta: [
      { title: "หลังใช้บริการ — MY MMS" },
      {
        name: "description",
        content: "ให้คะแนน ส่งความคิดเห็น ทิป และแจ้งปัญหาหลังใช้บริการ Male Massage",
      },
      { property: "og:title", content: "หลังใช้บริการ — MY MMS" },
      { property: "og:description", content: "ให้คะแนนและแจ้งปัญหาหลังใช้บริการ Male Massage" },
    ],
  }),
  component: AfterServicePage,
});

const ISSUES: { value: AfterServiceIssue; label: string }[] = [
  { value: "service", label: "เรื่องบริการ" },
  { value: "payment", label: "เรื่องการชำระเงิน" },
  { value: "therapist", label: "เรื่อง Therapist" },
  { value: "safety", label: "เรื่องความปลอดภัย" },
];

const TIPS = [
  { value: "none", label: "ยังไม่ทิป" },
  { value: "direct", label: "ทิปกับ Therapist โดยตรง" },
  { value: "via_mms", label: "ทิปผ่าน MMS" },
] as const;

function AfterServicePage() {
  const { isMock } = useMms();
  const bookings = useBookings();
  const submit = useSubmitAfterService();

  const completed = (bookings.data ?? []).filter((b) => b.status === "completed");
  const [bookingId, setBookingId] = useState<string | null>(null);
  const [rating, setRating] = useState<number | null>(null);
  const [feedback, setFeedback] = useState("");
  const [tipIntent, setTipIntent] = useState<(typeof TIPS)[number]["value"]>("none");
  const [issue, setIssue] = useState<AfterServiceIssue | null>(null);
  const [issueNote, setIssueNote] = useState("");

  const selected = bookingId ?? completed[0]?.id ?? null;

  const onSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!selected) return;
    submit.mutate(
      {
        bookingId: selected,
        rating,
        feedback: feedback.trim() || null,
        tipIntent,
        issue,
        issueNote: issueNote.trim() || null,
      },
      {
        onSuccess: (result) =>
          toast.success(result.message ?? "ส่งข้อมูลถึงทีมงานแล้ว ทีมงานจะยืนยันสถานะให้อีกครั้ง"),
        onError: () => toast.error("ส่งข้อมูลไม่สำเร็จ ลองอีกครั้งได้ครับ"),
      },
    );
  };

  return (
    <AppShell>
      {isMock && <MockRibbon />}
      <h1 className="mt-4 px-1 text-xl font-semibold tracking-tight">หลังใช้บริการ</h1>
      <p className="mt-1 px-1 text-xs leading-relaxed text-muted-foreground">
        ความคิดเห็นของคุณส่งตรงถึงทีมงาน สถานะการบริการและการชำระเงินยืนยันโดยระบบเท่านั้น
      </p>

      {bookings.isPending ? (
        <div className="mt-5">
          <StatePanel state="loading" />
        </div>
      ) : bookings.isError ? (
        <div className="mt-5">
          <StatePanel state="error" onRetry={() => bookings.refetch()} />
        </div>
      ) : completed.length === 0 ? (
        <div className="mt-5">
          <StatePanel state="empty" title="ยังไม่มีการใช้บริการที่เสร็จสิ้น" />
        </div>
      ) : (
        <form onSubmit={onSubmit}>
          <Section title="เลือกการจอง" className="mt-5">
            <ul className="space-y-2">
              {completed.map((b) => (
                <li key={b.id}>
                  <button
                    type="button"
                    onClick={() => setBookingId(b.id)}
                    aria-pressed={selected === b.id}
                    className={cn(
                      "surface-card flex w-full flex-col items-start gap-0.5 p-4 text-left",
                      selected === b.id && "surface-card-leaf",
                    )}
                  >
                    <span className="text-sm font-medium">{b.serviceLabel}</span>
                    <span className="text-xs text-muted-foreground">
                      {[b.refDisplay, b.scheduledLabel].filter(Boolean).join(" · ")}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </Section>

          <Section title="ให้คะแนน">
            <div className="surface-card flex items-center justify-between gap-2 p-4">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setRating(n)}
                  aria-label={`${n} ดาว`}
                  aria-pressed={rating === n}
                  className="flex h-12 w-12 items-center justify-center rounded-full transition-transform active:scale-95"
                >
                  <Star
                    className={cn(
                      "h-7 w-7",
                      rating && n <= rating
                        ? "fill-[color:var(--leaf)] text-[color:var(--leaf)]"
                        : "text-border",
                    )}
                    aria-hidden
                  />
                </button>
              ))}
            </div>
          </Section>

          <Section title="ความคิดเห็นสั้น ๆ">
            <textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              rows={3}
              placeholder="เล่าให้ทีมงานฟังได้เลยครับ"
              className="w-full rounded-2xl border border-border bg-surface p-4 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
            />
          </Section>

          <Section title="ทิป">
            <p className="mb-2 px-1 text-xs text-muted-foreground">
              Therapist ได้รับทิปเต็มจำนวน 100%
            </p>
            <div className="flex flex-wrap gap-2">
              {TIPS.map((tip) => (
                <button
                  key={tip.value}
                  type="button"
                  onClick={() => setTipIntent(tip.value)}
                  aria-pressed={tipIntent === tip.value}
                  className={cn(
                    "min-h-11 rounded-full border px-4 text-sm font-medium",
                    tipIntent === tip.value
                      ? "border-transparent bg-primary text-primary-foreground"
                      : "border-border bg-surface text-muted-foreground",
                  )}
                >
                  {tip.label}
                </button>
              ))}
            </div>
          </Section>

          <Section title="แจ้งปัญหา (ถ้ามี)">
            <div className="flex flex-wrap gap-2">
              {ISSUES.map((i) => (
                <button
                  key={i.value}
                  type="button"
                  onClick={() => setIssue(issue === i.value ? null : i.value)}
                  aria-pressed={issue === i.value}
                  className={cn(
                    "min-h-11 rounded-full border px-4 text-sm font-medium",
                    issue === i.value
                      ? "border-transparent bg-[color:var(--warn)] text-primary-foreground"
                      : "border-border bg-surface text-muted-foreground",
                  )}
                >
                  {i.label}
                </button>
              ))}
            </div>
            {issue && (
              <textarea
                value={issueNote}
                onChange={(e) => setIssueNote(e.target.value)}
                rows={3}
                placeholder="อธิบายเหตุการณ์ให้ทีมงานทราบ"
                className="mt-3 w-full rounded-2xl border border-border bg-surface p-4 text-sm outline-none focus:ring-2 focus:ring-[color:var(--ring)]"
              />
            )}
          </Section>

          <button
            type="submit"
            disabled={submit.isPending || !selected}
            className="mt-6 flex min-h-14 w-full items-center justify-center rounded-full bg-[image:var(--gradient-leaf)] px-6 text-[0.95rem] font-semibold text-primary-foreground disabled:opacity-60"
          >
            {submit.isPending ? "กำลังส่ง…" : "ส่งให้ทีมงาน"}
          </button>
        </form>
      )}
    </AppShell>
  );
}
