import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "../components/mms/app-shell";
import { StatePanel } from "../components/mms/primitives";
import { MMS_CHAT_ROUTE } from "../lib/mms/config";
export const Route = createFileRoute("/support")({
  head: () => ({ meta: [{ title: "ช่วยเหลือ — MY MMS" }, { name: "description", content: "ตรวจสิทธิ์การใช้งานและการสนทนาใน MY MMS" }] }),
  component: SupportPage,
});
function SupportPage() {
  return <AppShell><h1 className="mt-4 text-xl font-semibold">ช่วยเหลือ</h1><StatePanel state="checking" title="ช่องทางส่งเรื่องยังอยู่ระหว่างตรวจสอบครับ" hint="ยังไม่สามารถยืนยันการรับเรื่องผ่านหน้านี้ได้ครับ" /><a className="mms-primary" href={MMS_CHAT_ROUTE}>เปิดแชตในระบบ <span aria-hidden>→</span></a><p className="mms-copy">เปิดได้เฉพาะคู่สนทนาที่ระบบอนุญาต และต้องรับทราบกติกาก่อนเริ่มสนทนาครับ</p><Link to="/profile">ตรวจข้อมูลบัญชีของฉัน</Link></AppShell>;
}
