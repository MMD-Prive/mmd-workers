import { createFileRoute } from "@tanstack/react-router";
import { ExternalLink, ReceiptText } from "lucide-react";

import { AppShell } from "../components/mms/app-shell";
import {
  Field,
  MockRibbon,
  Pill,
  Section,
  StatePanel,
  paymentStateLabel,
  paymentTone,
} from "../components/mms/primitives";
import { useMms, usePayments } from "../lib/mms/provider-context";

export const Route = createFileRoute("/payment")({
  head: () => ({
    meta: [
      { title: "การชำระเงิน — MY MMS" },
      {
        name: "description",
        content: "ดูสถานะมัดจำและยอดคงเหลือของการจอง Male Massage ตามข้อมูลที่ระบบยืนยันแล้ว",
      },
      { property: "og:title", content: "การชำระเงิน — MY MMS" },
      { property: "og:description", content: "สถานะมัดจำและยอดคงเหลือของการจอง Male Massage" },
    ],
  }),
  component: PaymentPage,
});

function PaymentPage() {
  const { isMock } = useMms();
  const query = usePayments();
  const items = query.data ?? [];

  return (
    <AppShell>
      {isMock && <MockRibbon />}
      <h1 className="mt-4 px-1 text-xl font-semibold tracking-tight">การชำระเงิน</h1>
      <p className="mt-1 px-1 text-xs leading-relaxed text-muted-foreground">
        ยอดทั้งหมดมาจากระบบ Male Massage โดยตรง ระบบหน้าเว็บไม่คำนวณยอดเอง
      </p>

      <Section className="mt-5">
        {query.isPending ? (
          <StatePanel state="loading" />
        ) : query.isError ? (
          <StatePanel state="error" onRetry={() => query.refetch()} />
        ) : items.length === 0 ? (
          <StatePanel state="empty" title="ยังไม่มีรายการชำระเงิน" />
        ) : (
          <ul className="space-y-3">
            {items.map((p) => (
              <li key={p.bookingId} className="surface-card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-[0.95rem] font-semibold tracking-tight">
                      {p.serviceLabel ?? "การจอง Male Massage"}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {[p.bookingRefDisplay, p.scheduledLabel].filter(Boolean).join(" · ")}
                    </p>
                  </div>
                  <Pill tone={paymentTone(p.state)}>{paymentStateLabel(p.state)}</Pill>
                </div>

                {p.policyLabel && (
                  <p className="mt-3 rounded-xl bg-secondary px-3 py-2 text-[0.72rem] text-secondary-foreground">
                    {p.policyLabel}
                  </p>
                )}

                <div className="mt-2">
                  <Field label="ยอดรวม" value={p.totalLabel ?? "รอข้อมูลจากระบบ"} />
                  <Field label="มัดจำ" value={p.depositLabel ?? "รอข้อมูลจากระบบ"} />
                  <Field label="ส่วนที่เหลือ" value={p.balanceLabel ?? "รอข้อมูลจากระบบ"} />
                </div>

                {p.instructionsLabel && (
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                    {p.instructionsLabel}
                  </p>
                )}

                <div className="mt-3 flex flex-wrap items-center gap-2">
                  {p.proofUrl && (
                    <a
                      href={p.proofUrl}
                      className="inline-flex min-h-11 items-center gap-1.5 rounded-full border border-border bg-surface px-4 text-xs font-medium"
                    >
                      <ExternalLink className="h-4 w-4" aria-hidden />
                      สลิปที่ส่งไว้
                    </a>
                  )}
                  {p.receiptUrl && (
                    <a
                      href={p.receiptUrl}
                      className="inline-flex min-h-11 items-center gap-1.5 rounded-full border border-border bg-surface px-4 text-xs font-medium"
                    >
                      <ReceiptText className="h-4 w-4" aria-hidden />
                      ใบเสร็จ
                    </a>
                  )}
                  {!p.proofUrl && !p.receiptUrl && (
                    <span className="text-[0.7rem] text-muted-foreground">
                      ยังไม่มีลิงก์สลิป/ใบเสร็จจากระบบ
                    </span>
                  )}
                </div>

                {p.updatedLabel && (
                  <p className="mt-2 text-[0.68rem] text-muted-foreground">{p.updatedLabel}</p>
                )}
              </li>
            ))}
          </ul>
        )}
      </Section>
    </AppShell>
  );
}
