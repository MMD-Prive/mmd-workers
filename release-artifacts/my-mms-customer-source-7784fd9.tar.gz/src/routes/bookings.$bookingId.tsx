import { Link, createFileRoute } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";

import { AppShell } from "../components/mms/app-shell";
import { TherapistAvatar } from "../components/mms/booking-card";
import {
  Field,
  MockRibbon,
  Pill,
  Section,
  StatePanel,
  bookingStatusLabel,
  bookingTone,
  paymentStateLabel,
  paymentTone,
} from "../components/mms/primitives";
import { MMS_ROUTES } from "../lib/mms/config";
import { useBooking, useMms } from "../lib/mms/provider-context";
import { cn } from "../lib/utils";

export const Route = createFileRoute("/bookings/$bookingId")({
  component: BookingDetailPage,
});

function BookingDetailPage() {
  const { bookingId } = Route.useParams();
  const { isMock } = useMms();
  const query = useBooking(bookingId);
  const booking = query.data;

  return (
    <AppShell>
      {isMock && <MockRibbon />}
      <Link
        to={MMS_ROUTES.bookings}
        className="mt-4 inline-flex min-h-11 items-center gap-1 text-sm font-medium text-muted-foreground"
      >
        <ChevronLeft className="h-4 w-4" aria-hidden />
        การจองของฉัน
      </Link>

      {query.isPending ? (
        <StatePanel state="loading" />
      ) : query.isError || !booking ? (
        <StatePanel state="error" onRetry={() => query.refetch()} />
      ) : (
        <>
          <section className="surface-card surface-card-leaf mt-3 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h1 className="text-lg font-semibold tracking-tight">{booking.serviceLabel}</h1>
                {booking.refDisplay && (
                  <p className="mt-0.5 text-xs text-muted-foreground">{booking.refDisplay}</p>
                )}
              </div>
              <Pill tone={bookingTone(booking.status)}>{bookingStatusLabel(booking.status)}</Pill>
            </div>
            <div className="mt-3">
              <Field label="วัน–เวลา" value={booking.scheduledLabel ?? "รอยืนยัน"} />
              <Field label="ระยะเวลา" value={booking.durationLabel ?? "—"} />
              <Field label="พื้นที่" value={booking.areaLabel ?? "รอยืนยัน"} />
              <Field
                label="Therapist"
                value={
                  booking.therapist ? (
                    <span className="inline-flex items-center gap-2">
                      <TherapistAvatar
                        name={booking.therapist.publicName}
                        photoUrl={booking.therapist.photoUrl}
                        size="sm"
                      />
                      {booking.therapist.publicName}
                    </span>
                  ) : (
                    "กำลังจัด Therapist"
                  )
                }
              />
              <Field
                label="การชำระเงิน"
                value={
                  <Pill tone={paymentTone(booking.paymentState)}>
                    {paymentStateLabel(booking.paymentState)}
                  </Pill>
                }
              />
              {booking.amountSummary && <Field label="ยอดรวม" value={booking.amountSummary} />}
            </div>
          </section>

          <Section title="ไทม์ไลน์">
            <ol className="surface-card space-y-0 p-4">
              {booking.timeline.map((entry, i) => (
                <li key={`${entry.label}-${i}`} className="flex gap-3 pb-4 last:pb-0">
                  <div className="flex flex-col items-center">
                    <span
                      className={cn(
                        "mt-1 h-2.5 w-2.5 rounded-full",
                        entry.state === "done" && "bg-[color:var(--ok)]",
                        entry.state === "current" && "bg-[color:var(--warn)]",
                        entry.state === "upcoming" && "bg-border",
                      )}
                    />
                    {i < booking.timeline.length - 1 && (
                      <span className="mt-1 w-px flex-1 bg-border" />
                    )}
                  </div>
                  <div className="pb-1">
                    <p className="text-sm font-medium text-foreground">{entry.label}</p>
                    {entry.atLabel && (
                      <p className="text-xs text-muted-foreground">{entry.atLabel}</p>
                    )}
                    {entry.note && (
                      <p className="mt-0.5 text-xs text-[color:var(--warn)]">{entry.note}</p>
                    )}
                  </div>
                </li>
              ))}
            </ol>
          </Section>

          {booking.operatorNote && (
            <p className="mt-3 rounded-2xl bg-secondary px-4 py-3 text-xs leading-relaxed text-secondary-foreground">
              {booking.operatorNote}
            </p>
          )}

          <div className="mt-5 flex flex-col gap-2">
            <Link
              to={MMS_ROUTES.payment}
              className="inline-flex min-h-13 items-center justify-center rounded-full bg-primary px-6 py-4 text-sm font-semibold text-primary-foreground"
            >
              ดูสถานะการชำระเงิน
            </Link>
            <Link
              to={MMS_ROUTES.support}
              className="inline-flex min-h-13 items-center justify-center rounded-full border border-border bg-surface px-6 py-4 text-sm font-medium"
            >
              แจ้งปัญหาการจองนี้
            </Link>
          </div>
        </>
      )}
    </AppShell>
  );
}
