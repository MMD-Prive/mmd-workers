import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BadgeCheck,
  CheckCircle2,
  LifeBuoy,
  MapPin,
  Navigation,
  PlayCircle,
} from "lucide-react";

import { AppShell } from "../components/mms/app-shell";
import { Field, MockRibbon, Pill, Section, StatePanel, Surface } from "../components/mms/primitives";
import { MMS_ROUTES } from "../lib/mms/config";
import {
  useDispatch,
  useIsTherapistMode,
  useJobDetail,
  useJobLifecycle,
  useRefreshJobsOnFocus,
} from "../lib/mms/dispatch-context";
import type { JobState } from "../lib/mms/dispatch-types";

export const Route = createFileRoute("/jobs/$jobId")({
  head: () => ({
    meta: [
      { title: "รายละเอียดงาน · MY MMS Therapist" },
      {
        name: "description",
        content: "รายละเอียดงานที่รับแล้วสำหรับ Therapist ของ Male Massage",
      },
      { property: "og:title", content: "รายละเอียดงาน · MY MMS Therapist" },
      { property: "og:description", content: "เวลา พื้นที่ และสถานะงานที่รับแล้ว" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: JobDetailPage,
});

const LIFECYCLE: Record<string, { title: string; hint: string }> = {
  ACCEPTED: { title: "JOB CONFIRMED ✓", hint: "เตรียมตัวและเดินทางก่อนเวลานัดหมาย" },
  IN_PROGRESS: { title: "กำลังให้บริการ", hint: "ระบบจะอัปเดตสถานะเมื่อจบงาน" },
  COMPLETED: { title: "งานเสร็จสิ้น", hint: "สรุปงานและยอดจากระบบ Male Massage" },
  CANCELLED: { title: "งานถูกยกเลิก", hint: "ทีมงานยกเลิกงานนี้ในระบบแล้ว" },
};

function JobDetailPage() {
  const { jobId } = Route.useParams();
  const { isMock } = useDispatch();
  const { confirmed, checking } = useIsTherapistMode();
  const job = useJobDetail(jobId);
  const { start, complete } = useJobLifecycle(jobId);
  useRefreshJobsOnFocus();

  const lifecyclePending = start.isPending || complete.isPending;
  const lifecycleMessage =
    start.data?.message ??
    complete.data?.message ??
    (start.isError || complete.isError
      ? "ยังยืนยันกับระบบไม่ได้ กรุณาลองใหม่อีกครั้ง"
      : null);

  if (checking || job.isPending) {
    return (
      <AppShell>
        <Section title="รายละเอียดงาน">
          <StatePanel state="loading" />
        </Section>
      </AppShell>
    );
  }

  if (!confirmed) {
    return (
      <AppShell>
        <Section title="รายละเอียดงาน">
          <StatePanel
            state="empty"
            title="หน้านี้สำหรับ Therapist เท่านั้น"
            hint="ระบบยังไม่ได้ยืนยันว่าบัญชีนี้เป็น Therapist ของ Male Massage"
          />
        </Section>
      </AppShell>
    );
  }

  if (job.isError || !job.data) {
    return (
      <AppShell>
        <Section title="รายละเอียดงาน">
          <StatePanel state="error" onRetry={() => job.refetch()} />
        </Section>
      </AppShell>
    );
  }

  const data = job.data;
  const state: JobState = data.state;
  const lifecycle = LIFECYCLE[state];
  const d = data.disclosure;

  return (
    <AppShell>
      {isMock && <MockRibbon />}

      <Section>
        <Surface>
          <div className="flex items-center gap-2">
            {state === "ACCEPTED" && (
              <BadgeCheck className="h-5 w-5 text-[color:var(--ok)]" aria-hidden />
            )}
            <h1 className="text-lg font-semibold tracking-tight">
              {lifecycle?.title ?? "สถานะงาน"}
            </h1>
          </div>
          {lifecycle?.hint && (
            <p className="mt-1 text-sm text-muted-foreground">{lifecycle.hint}</p>
          )}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Pill tone={state === "CANCELLED" ? "bad" : state === "COMPLETED" ? "neutral" : "ok"}>
              {data.serviceLabel}
            </Pill>
            {data.refDisplay && (
              <span className="text-[0.7rem] text-muted-foreground">{data.refDisplay}</span>
            )}
          </div>
        </Surface>
      </Section>

      <Section title="ข้อมูลงาน">
        <Surface>
          {data.scheduledLabel && <Field label="วันและเวลา" value={data.scheduledLabel} />}
          {data.durationLabel && <Field label="ระยะเวลา" value={data.durationLabel} />}
          {data.areaLabel && <Field label="พื้นที่" value={data.areaLabel} />}
          {d.locationUnlocked && d.addressLabel && (
            <Field label="สถานที่" value={d.addressLabel} />
          )}
          {d.customerDisplayLabel && <Field label="ลูกค้า" value={d.customerDisplayLabel} />}
          {data.payoutLabel && <Field label="รายได้" value={data.payoutLabel} />}
          {data.payoutSummaryLabel && <Field label="การรับเงิน" value={data.payoutSummaryLabel} />}
          {data.paymentStateLabel && (
            <Field label="สถานะการชำระเงิน" value={data.paymentStateLabel} />
          )}
          {!d.locationUnlocked && (
            <p className="pt-3 text-xs leading-relaxed text-muted-foreground">
              <MapPin className="mr-1 inline h-3.5 w-3.5" aria-hidden />
              ที่อยู่แบบละเอียดจะเปิดให้เมื่อระบบยืนยันการรับงานเรียบร้อยแล้ว
            </p>
          )}
        </Surface>
      </Section>

      {data.timeline.length > 0 && (
        <Section title="ไทม์ไลน์">
          <Surface>
            <ol className="space-y-3">
              {data.timeline.map((entry, i) => (
                <li key={`${entry.label}-${i}`} className="flex gap-3">
                  <span
                    aria-hidden
                    className={
                      entry.state === "done"
                        ? "mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-[color:var(--ok)]"
                        : entry.state === "current"
                          ? "mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-[color:var(--leaf)]"
                          : "mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-border"
                    }
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{entry.label}</p>
                    {entry.atLabel && (
                      <p className="text-xs text-muted-foreground">{entry.atLabel}</p>
                    )}
                    {entry.note && (
                      <p className="text-xs text-muted-foreground">{entry.note}</p>
                    )}
                  </div>
                </li>
              ))}
            </ol>
          </Surface>
        </Section>
      )}

      <Section>
        <div className="space-y-2">
          {state === "ACCEPTED" && (
            <button
              type="button"
              disabled={lifecyclePending}
              onClick={() => start.mutate(undefined, { onSettled: () => job.refetch() })}
              className="flex min-h-13 w-full items-center justify-center gap-2 rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground disabled:opacity-60"
            >
              <PlayCircle className="h-4 w-4" aria-hidden />
              {start.isPending ? "กำลังเริ่มงาน…" : "START SERVICE · เริ่มให้บริการ"}
            </button>
          )}
          {state === "IN_PROGRESS" && (
            <button
              type="button"
              disabled={lifecyclePending}
              onClick={() => complete.mutate(undefined, { onSettled: () => job.refetch() })}
              className="flex min-h-13 w-full items-center justify-center gap-2 rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground disabled:opacity-60"
            >
              <CheckCircle2 className="h-4 w-4" aria-hidden />
              {complete.isPending ? "กำลังจบงาน…" : "COMPLETE SERVICE · จบงาน"}
            </button>
          )}
          {lifecycleMessage && (
            <p className="px-2 text-center text-xs text-muted-foreground">{lifecycleMessage}</p>
          )}
          {d.locationUnlocked && d.mapUrl && (
            <a
              href={d.mapUrl}
              target="_blank"
              rel="noreferrer"
              className="flex min-h-13 w-full items-center justify-center gap-2 rounded-full border border-border bg-surface px-6 text-sm font-semibold"
            >
              <Navigation className="h-4 w-4" aria-hidden />
              นำทางไปยังจุดนัดหมาย
            </a>
          )}

          <Link
            to={MMS_ROUTES.jobs}
            className="flex min-h-12 w-full items-center justify-center rounded-full px-6 text-sm font-medium text-muted-foreground"
          >
            กลับไปหน้างานของฉัน
          </Link>
        </div>
      </Section>
    </AppShell>
  );
}
