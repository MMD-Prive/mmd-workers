import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect } from "react";

import { AppShell } from "../components/mms/app-shell";
import { MockRibbon, Section, StatePanel } from "../components/mms/primitives";
import { MMS_ROUTES } from "../lib/mms/config";
import {
  useDispatch,
  useIsTherapistMode,
  useJobOffer,
  useRefreshJobsOnFocus,
} from "../lib/mms/dispatch-context";

/**
 * Deep link: /accept/job?id=MMS-J-... (also accepts ?job=).
 *
 * The identifier is the ONLY thing taken from the URL. Service, payout,
 * expiry and state are always loaded canonically from the adapter.
 */
export const Route = createFileRoute("/accept/job")({
  validateSearch: (search: Record<string, unknown>) => ({
    id: typeof search["id"] === "string" ? search["id"] : undefined,
    job: typeof search["job"] === "string" ? search["job"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "งานใหม่ · MY MMS Therapist" },
      {
        name: "description",
        content: "หน้ารับงานสำหรับ Therapist ของ Male Massage — ตรวจสอบรายละเอียดงานและตอบรับงาน",
      },
      { property: "og:title", content: "งานใหม่ · MY MMS Therapist" },
      { property: "og:description", content: "รับงานจากระบบจับคู่ของ Male Massage" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AcceptJobPage,
});

function AcceptJobPage() {
  const { id, job } = Route.useSearch();
  const jobId = id ?? job ?? null;
  const { openOffer, isMock } = useDispatch();
  const { checking } = useIsTherapistMode();
  const offer = useJobOffer(jobId);
  useRefreshJobsOnFocus();

  useEffect(() => {
    if (jobId && offer.data) openOffer(jobId);
  }, [jobId, offer.data, openOffer]);

  return (
    <AppShell>
      {isMock && <MockRibbon />}
      <Section title="งานจากระบบจับคู่">
        {!jobId ? (
          <StatePanel
            state="empty"
            title="ไม่พบรหัสงานในลิงก์นี้"
            hint="เปิดลิงก์รับงานจากระบบ Male Massage อีกครั้ง หรือดูรายการงานทั้งหมดได้ที่หน้างาน"
            action={
              <Link
                to={MMS_ROUTES.jobs}
                className="mt-3 inline-flex min-h-11 items-center justify-center rounded-full border border-border bg-surface px-5 text-sm font-medium"
              >
                ไปหน้างานของฉัน
              </Link>
            }
          />
        ) : offer.isPending || checking ? (
          <StatePanel state="loading" title="กำลังเปิดงานจากระบบ" />
        ) : offer.isError ? (
          <StatePanel
            state="error"
            title="ยังเปิดงานนี้ไม่ได้"
            hint="สถานะงานจริงอยู่ที่ระบบ Male Massage ลองอีกครั้งได้ครับ"
            onRetry={() => offer.refetch()}
          />
        ) : (
          <StatePanel state="loading" title="กำลังแสดงรายละเอียดงาน" />
        )}
      </Section>
    </AppShell>
  );
}
