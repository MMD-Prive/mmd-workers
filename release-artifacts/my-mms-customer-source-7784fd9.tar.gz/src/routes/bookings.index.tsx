import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

import { AppShell } from "../components/mms/app-shell";
import { BookingCard } from "../components/mms/booking-card";
import { MockRibbon, Section, StatePanel } from "../components/mms/primitives";
import { useBookings, useMms } from "../lib/mms/provider-context";
import type { BookingStatus } from "../lib/mms/types";
import { cn } from "../lib/utils";

export const Route = createFileRoute("/bookings/")({
  component: BookingsPage,
});

const FILTERS: { value: BookingStatus | "all"; label: string }[] = [
  { value: "all", label: "ทั้งหมด" },
  { value: "pending", label: "รอยืนยัน" },
  { value: "confirmed", label: "ยืนยันแล้ว" },
  { value: "in_progress", label: "กำลังให้บริการ" },
  { value: "completed", label: "เสร็จสิ้น" },
  { value: "cancelled", label: "ยกเลิก" },
];

function BookingsPage() {
  const { isMock } = useMms();
  const [filter, setFilter] = useState<BookingStatus | "all">("all");
  const bookings = useBookings();

  const list = (bookings.data ?? []).filter((b) => filter === "all" || b.status === filter);

  return (
    <AppShell>
      {isMock && <MockRibbon />}
      <h1 className="mt-4 px-1 text-xl font-semibold tracking-tight">การจองของฉัน</h1>
      <p className="mt-1 px-1 text-xs text-muted-foreground">
        สถานะทั้งหมดมาจากระบบ Male Massage โดยตรง
      </p>

      <div className="hide-scrollbar -mx-5 mt-4 flex gap-2 overflow-x-auto px-5 pb-1">
        {FILTERS.map((f) => (
          <button
            key={f.value}
            type="button"
            onClick={() => setFilter(f.value)}
            aria-pressed={filter === f.value}
            className={cn(
              "min-h-10 shrink-0 rounded-full border px-4 text-sm font-medium transition-colors",
              filter === f.value
                ? "border-transparent bg-primary text-primary-foreground"
                : "border-border bg-surface text-muted-foreground",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <Section className="mt-4">
        {bookings.isPending ? (
          <StatePanel state="loading" />
        ) : bookings.isError ? (
          <StatePanel state="error" onRetry={() => bookings.refetch()} />
        ) : list.length === 0 ? (
          <StatePanel state="empty" title="ยังไม่มีการจองในสถานะนี้" />
        ) : (
          <ul className="space-y-3">
            {list.map((b) => (
              <li key={b.id}>
                <BookingCard booking={b} />
              </li>
            ))}
          </ul>
        )}
      </Section>
    </AppShell>
  );
}
