import { createFileRoute, Link } from "@tanstack/react-router";
import { BellRing, ChevronRight, Clock, MapPin, Wallet } from "lucide-react";

import { AppShell } from "../components/mms/app-shell";
import { MockRibbon, Pill, Section, StatePanel, Surface } from "../components/mms/primitives";
import {
  useDispatch,
  useIncomingOffers,
  useIsTherapistMode,
  useJobs,
  useRefreshJobsOnFocus,
  useTherapistContext,
} from "../lib/mms/dispatch-context";
import type { JobDetail, JobState } from "../lib/mms/dispatch-types";

export const Route = createFileRoute("/jobs/")({
  head: () => ({
    meta: [
      { title: "งานของฉัน · MY MMS Therapist" },
      {
        name: "description",
        content: "งานที่รับแล้ว งานที่กำลังจะถึง และประวัติงานของ Therapist Male Massage",
      },
      { property: "og:title", content: "งานของฉัน · MY MMS Therapist" },
      { property: "og:description", content: "งานที่รับแล้วและงานที่กำลังจะถึงของ Therapist" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: JobsPage,
});

const STATE_LABEL: Record<JobState, string> = {
  OFFERED: "งานใหม่",
  ACCEPTING: "กำลังรับงาน",
  ACCEPTED: "รับงานแล้ว",
  DECLINED: "ปฏิเสธแล้ว",
  EXPIRED: "หมดเวลา",
  TAKEN: "มีผู้รับแล้ว",
  CANCELLED: "ยกเลิก",
  IN_PROGRESS: "กำลังให้บริการ",
  COMPLETED: "เสร็จสิ้น",
  CHECKING: "กำลังตรวจสอบ",
  ERROR: "ยังตรวจสอบไม่ได้",
};

export function JobRow({ job }: { job: JobDetail }) {
  return (
    <Surface as="li" className="p-0">
      <Link
        to="/jobs/$jobId"
        params={{ jobId: job.jobId }}
        className="flex items-center gap-3 p-4"
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Pill
              tone={
                job.state === "COMPLETED"
                  ? "neutral"
                  : job.state === "CANCELLED"
                    ? "bad"
                    : job.state === "IN_PROGRESS"
                      ? "info"
                      : "ok"
              }
            >
              {STATE_LABEL[job.state]}
            </Pill>
            {job.refDisplay && (
              <span className="text-[0.7rem] text-muted-foreground">{job.refDisplay}</span>
            )}
          </div>
          <p className="mt-2 text-[0.95rem] font-semibold leading-snug">{job.serviceLabel}</p>
          <p className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
            {job.scheduledLabel && (
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" aria-hidden />
                {job.scheduledLabel}
              </span>
            )}
            {job.areaLabel && (
              <span className="inline-flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5" aria-hidden />
                {job.areaLabel}
              </span>
            )}
            {job.payoutLabel && (
              <span className="inline-flex items-center gap-1">
                <Wallet className="h-3.5 w-3.5" aria-hidden />
                {job.payoutLabel}
              </span>
            )}
          </p>
        </div>
        <ChevronRight className="h-5 w-5 shrink-0 text-muted-foreground" aria-hidden />
      </Link>
    </Surface>
  );
}

export function JobsPage() {
  const { isMock, openOffer } = useDispatch();
  const { confirmed, checking } = useIsTherapistMode();
  const ctx = useTherapistContext();
  const offers = useIncomingOffers();
  const jobs = useJobs();
  useRefreshJobsOnFocus();

  if (checking) {
    return (
      <AppShell>
        <Section title="งานของฉัน">
          <StatePanel state="loading" title="กำลังตรวจสอบสิทธิ์ Therapist" />
        </Section>
      </AppShell>
    );
  }

  if (!confirmed) {
    return (
      <AppShell>
        {isMock && <MockRibbon />}
        <Section title="งานของฉัน">
          <StatePanel
            state="empty"
            title="หน้านี้สำหรับ Therapist เท่านั้น"
            hint="ระบบยังไม่ได้ยืนยันว่าบัญชีนี้เป็น Therapist ของ Male Massage"
          />
        </Section>
      </AppShell>
    );
  }

  const list = jobs.data ?? [];
  const active = list.filter((j) => j.state === "ACCEPTED" || j.state === "IN_PROGRESS");
  const past = list.filter((j) => j.state === "COMPLETED" || j.state === "CANCELLED");
  const incoming = offers.data ?? [];

  return (
    <AppShell>
      {isMock && <MockRibbon />}

      <Section>
        <Surface className="flex items-center justify-between gap-3">
          <div>
            <p className="eyebrow text-[color:var(--leaf)]">Therapist</p>
            <p className="text-[1.05rem] font-semibold">
              {ctx.data?.therapistPublicName ?? "กำลังตรวจสอบ"}
            </p>
            {ctx.data?.availabilityLabel && (
              <p className="text-xs text-muted-foreground">{ctx.data.availabilityLabel}</p>
            )}
          </div>
          {incoming.length > 0 && (
            <button
              type="button"
              onClick={() => openOffer(incoming[0]!.jobId)}
              className="inline-flex min-h-12 items-center gap-2 rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground"
            >
              <BellRing className="h-4 w-4" aria-hidden />
              งานใหม่ {incoming.length}
            </button>
          )}
        </Surface>
      </Section>

      <Section title="งานปัจจุบัน">
        {jobs.isPending ? (
          <StatePanel state="loading" />
        ) : jobs.isError ? (
          <StatePanel state="error" onRetry={() => jobs.refetch()} />
        ) : active.length === 0 ? (
          <StatePanel state="empty" title="ยังไม่มีงานที่รับไว้" />
        ) : (
          <ul className="space-y-3">
            {active.map((job) => (
              <JobRow key={job.jobId} job={job} />
            ))}
          </ul>
        )}
      </Section>

      {past.length > 0 && (
        <Section title="ประวัติงาน">
          <ul className="space-y-3">
            {past.map((job) => (
              <JobRow key={job.jobId} job={job} />
            ))}
          </ul>
        </Section>
      )}
    </AppShell>
  );
}
