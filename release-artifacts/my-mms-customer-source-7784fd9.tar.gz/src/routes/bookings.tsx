import { Outlet, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/bookings")({
  head: () => ({
    meta: [
      { title: "การจองของฉัน — MY MMS" },
      {
        name: "description",
        content: "ดูสถานะการจอง Male Massage ทั้งหมด รอยืนยัน ยืนยันแล้ว กำลังให้บริการ เสร็จสิ้น และยกเลิก",
      },
      { property: "og:title", content: "การจองของฉัน — MY MMS" },
      { property: "og:description", content: "สถานะการจอง Male Massage ทั้งหมดของคุณ" },
    ],
  }),
  component: () => <Outlet />,
});
