import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";

import { mmsRouterBasepath } from "./lib/mms/config";
import { routeTree } from "./routeTree.gen";

export const getRouter = () => {
  const queryClient = new QueryClient();

  return createRouter({
    routeTree,
    basepath: mmsRouterBasepath(),
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
  });
};
