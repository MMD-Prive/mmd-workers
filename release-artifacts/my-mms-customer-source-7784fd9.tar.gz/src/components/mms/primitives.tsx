import type { ReactNode } from "react";

import { cn } from "../../lib/utils";
import type { BookingStatus, PaymentState } from "../../lib/mms/types";
import { t } from "../../lib/mms/i18n";
import { GraphicProgress } from "./graphic-progress";

export function Section({
  title,
  action,
  children,
  className,
}: {
  title?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("mt-6 first:mt-0", className)}>
      {(title || action) && (
        <div className="mb-3 flex items-end justify-between gap-3 px-1">
          {title && (
            <h2 className="text-[0.95rem] font-semibold tracking-tight text-foreground">{title}</h2>
          )}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function Surface({
  children,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  as?: "div" | "article" | "li";
}) {
  return <Tag className={cn("surface-card p-4", className)}>{children}</Tag>;
}

const TONES = {
  neutral: "bg-secondary text-secondary-foreground",
  ok: "bg-[color:var(--ok-soft)] text-[color:var(--ok)]",
  warn: "bg-[color:var(--warn-soft)] text-[color:var(--warn)]",
  bad: "bg-[color:var(--bad-soft)] text-destructive",
  info: "bg-[color:var(--leaf-soft)] text-[color:var(--leaf)]",
} as const;

export type Tone = keyof typeof TONES;

export function Pill({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: Tone;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.72rem] font-medium leading-none",
        TONES[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function bookingTone(status: BookingStatus): Tone {
  switch (status) {
    case "confirmed":
      return "ok";
    case "in_progress":
      return "info";
    case "pending":
      return "warn";
    case "cancelled":
      return "bad";
    case "completed":
      return "neutral";
    default:
      return "neutral";
  }
}

export function paymentTone(state: PaymentState): Tone {
  switch (state) {
    case "deposit_verified":
    case "completed":
      return "ok";
    case "deposit_required":
    case "balance_due":
      return "warn";
    case "deposit_submitted":
      return "info";
    case "unavailable":
      return "bad";
    default:
      return "neutral";
  }
}

export const bookingStatusLabel = (s: BookingStatus) => t(`booking.status.${s}`);
export const paymentStateLabel = (s: PaymentState) => t(`payment.state.${s}`);

/** Bounded loading / empty / error surface. Never invents data. */
export function StatePanel({
  state,
  title,
  hint,
  onRetry,
  action,
}: {
  state: "loading" | "checking" | "denied" | "empty" | "error";
  title?: string;
  hint?: string;
  onRetry?: (() => void) | undefined;
  action?: ReactNode;
}) {
  const defaults = {
    loading: { title: t("state.checking"), hint: "กำลังดึงข้อมูลจากระบบ Male Massage" },
    checking: { title: "กำลังตรวจสอบความพร้อม", hint: "ระบบยังไม่ได้ยืนยันผลครับ" },
    denied: { title: "กรุณาตรวจสอบสิทธิ์ผ่าน LINE", hint: "ข้อมูลส่วนตัวจะเปิดเมื่อยืนยันสิทธิ์แล้วครับ" },
    empty: { title: t("state.empty"), hint: "" },
    error: { title: t("state.error"), hint: t("state.errorHint") },
  }[state];

  return (
    <div
      className="surface-card flex flex-col items-center gap-2 px-5 py-8 text-center"
      role={state === "error" ? "alert" : undefined}
      data-state={state}
      aria-busy={state === "loading" || state === "checking"}
    >
      {state === "loading" && <GraphicProgress />}
      <p className="text-sm font-semibold text-foreground">{title ?? defaults.title}</p>
      {(hint ?? defaults.hint) && (
        <p className="max-w-[34ch] text-xs leading-relaxed text-muted-foreground">
          {hint ?? defaults.hint}
        </p>
      )}
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-3 inline-flex min-h-11 items-center justify-center rounded-full border border-border bg-surface px-5 text-sm font-medium text-foreground"
        >
          {t("state.retry")}
        </button>
      )}
      {action}
    </div>
  );
}

export function Field({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-border/70 py-2.5 last:border-0">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-right text-sm font-medium text-foreground">{value}</span>
    </div>
  );
}

export function MockRibbon() {
  return (
    <p className="rounded-xl bg-[color:var(--warn-soft)] px-3 py-2 text-center text-[0.7rem] leading-relaxed text-[color:var(--warn)]">
      โหมดตัวอย่างสำหรับออกแบบ — ข้อมูลทั้งหมดเป็นเดโม ไม่ใช่ข้อมูลจริงจากระบบ
    </p>
  );
}
