import React from "react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MmsProvider } from "../../lib/mms/provider-context";
import { MatchingAvailability } from "./matching-search";
import { createLiveProvider } from "../../lib/mms/live-provider";
vi.mock("../../lib/mms/config", async (importOriginal) => ({
  ...(await importOriginal<typeof import("../../lib/mms/config")>()),
  shouldUseLiveProvider: () => true,
}));

const catalog = {
  services: [{ code: "aroma_therapy_oil", label: "นวดผ่อนคลาย" }],
  zones: [{ code: "BKK-SUKHUMVIT", label: "สุขุมวิท", province: "กรุงเทพมหานคร" }],
  availability: [
    { code: "Available", label: "Online · รับงาน" },
    { code: "Unavailable", label: "Offline" },
    { code: "Paused", label: "พักรับงาน" },
  ],
};
const criteria = {
  service: "aroma_therapy_oil",
  zone: "BKK-SUKHUMVIT",
  availability: "Available" as const,
  recipient: "ผู้ชาย",
};
function result(availability = "Available") {
  return {
    criteria: { ...criteria, availability },
    checkedAt: "2026-10-22T03:00:00Z",
    results: [
      {
        id: "mms_fixture",
        publicName: "ชื่อสาธารณะสำหรับทดสอบ",
        serviceTags: ["นวดผ่อนคลาย"],
        areaTags: ["สุขุมวิท"],
        availability,
        canReceiveWork: availability === "Available",
      },
    ],
  };
}
const clients: QueryClient[] = [];
afterEach(() => {
  cleanup();
  clients.forEach((client) => client.clear());
  clients.length = 0;
  vi.unstubAllGlobals();
});
beforeEach(() => {
  vi.stubGlobal(
    "fetch",
    vi.fn(async (path: string) =>
      Response.json({ ok: true, data: path.endsWith("/catalog") ? catalog : result() }),
    ),
  );
});
function mount() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  clients.push(client);
  render(
    <QueryClientProvider client={client}>
      <MmsProvider>
        <MatchingAvailability />
      </MmsProvider>
    </QueryClientProvider>,
  );
}
async function fill(availability = "Available") {
  await screen.findByLabelText("บริการ");
  fireEvent.change(screen.getByLabelText("บริการ"), { target: { value: criteria.service } });
  fireEvent.change(screen.getByLabelText("เขตบริการ"), { target: { value: criteria.zone } });
  fireEvent.change(screen.getByLabelText("ผู้รับบริการ"), {
    target: { value: criteria.recipient },
  });
  fireEvent.change(screen.getByLabelText("สถานะรับงาน"), { target: { value: availability } });
}
it("waits for confirmed catalog and requires service, zone and recipient before search", async () => {
  mount();
  expect(screen.getByRole("progressbar").getAttribute("aria-valuenow")).toBe("0");
  await screen.findByLabelText("บริการ");
  expect(
    (screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" }) as HTMLButtonElement).disabled,
  ).toBe(true);
  expect(screen.queryByText("ชื่อสาธารณะสำหรับทดสอบ")).toBeNull();
  await fill();
  fireEvent.click(screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" }));
  await screen.findByText("ชื่อสาธารณะสำหรับทดสอบ");
  const calls = vi.mocked(fetch).mock.calls;
  expect(String(calls[1]?.[0])).toContain("zone=BKK-SUKHUMVIT");
  expect(calls.every((call) => call[1]?.method === "GET")).toBe(true);
  expect(screen.queryByRole("progressbar")).toBeNull();
});
it.each(["Unavailable", "Paused"])(
  "keeps %s results visibly unavailable for work",
  async (availability) => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async (path: string) =>
        Response.json({
          ok: true,
          data: path.endsWith("/catalog") ? catalog : result(availability),
        }),
      ),
    );
    mount();
    await fill(availability);
    fireEvent.click(screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" }));
    await screen.findByText("ชื่อสาธารณะสำหรับทดสอบ");
    expect(screen.getByText("ยังไม่พร้อมรับงานตามสถานะปัจจุบันครับ")).toBeTruthy();
    expect(screen.queryByText("Online", { exact: true })).toBeNull();
  },
);
it("only a complete successful zero result becomes empty", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn(async (path: string) =>
      Response.json({
        ok: true,
        data: path.endsWith("/catalog") ? catalog : { ...result(), results: [] },
      }),
    ),
  );
  mount();
  await fill();
  fireEvent.click(screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" }));
  await screen.findByText("ไม่พบผู้ให้บริการตามเงื่อนไขนี้ครับ");
});
it("uses real completed steps while waiting and blocks duplicate requests", async () => {
  let complete: (() => void) | undefined;
  vi.stubGlobal(
    "fetch",
    vi.fn(async (path: string) =>
      path.endsWith("/catalog")
        ? Response.json({ ok: true, data: catalog })
        : await new Promise<Response>((resolve) => {
            complete = () => resolve(Response.json({ ok: true, data: result() }));
          }),
    ),
  );
  mount();
  await fill();
  const button = screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" });
  fireEvent.click(button);
  fireEvent.click(button);
  await waitFor(() => expect(vi.mocked(fetch)).toHaveBeenCalledTimes(2));
  expect(screen.getByRole("progressbar").getAttribute("aria-valuenow")).toBe("50");
  expect((button as HTMLButtonElement).disabled).toBe(true);
  complete?.();
  await screen.findByText("ชื่อสาธารณะสำหรับทดสอบ");
});
it("503 stays checking and retry can recover without creating a fake empty result", async () => {
  let broken = true;
  vi.stubGlobal(
    "fetch",
    vi.fn(async (path: string) =>
      path.endsWith("/catalog")
        ? Response.json({ ok: true, data: catalog })
        : broken
          ? Response.json({ ok: false, error: { code: "MMS_SEARCH_UNAVAILABLE" } }, { status: 503 })
          : Response.json({ ok: true, data: result() }),
    ),
  );
  mount();
  await fill();
  fireEvent.click(screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" }));
  await screen.findByText("ยังตรวจสอบระบบจับคู่ไม่ได้ครับ", {}, { timeout: 3000 });
  expect(screen.queryByText("ไม่พบผู้ให้บริการตามเงื่อนไขนี้ครับ")).toBeNull();
  broken = false;
  fireEvent.click(screen.getByRole("button", { name: /ลอง/ }));
  await screen.findByText("ชื่อสาธารณะสำหรับทดสอบ");
});
it("account switch removes previous results before the next account read", async () => {
  mount();
  await fill();
  fireEvent.click(screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" }));
  await screen.findByText("ชื่อสาธารณะสำหรับทดสอบ");
  window.dispatchEvent(new Event("mms:account-switch"));
  await waitFor(() => expect(screen.queryByText("ชื่อสาธารณะสำหรับทดสอบ")).toBeNull());
  await screen.findByLabelText("บริการ");
  expect((screen.getByLabelText("บริการ") as HTMLSelectElement).value).toBe("");
});
it("rejects malformed success and mismatched criteria / readiness at the live boundary", async () => {
  for (const payload of [
    {},
    { ...result(), criteria: { ...criteria, zone: "wrong" } },
    { ...result(), results: [{ ...result().results[0], canReceiveWork: false }] },
  ]) {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => Response.json({ ok: true, data: payload })),
    );
    await expect(createLiveProvider().searchTherapists(criteria)).rejects.toMatchObject({
      kind: "malformed",
    });
  }
});
it("401 denies access without showing previous data or claiming zero results", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn(async (path: string) =>
      path.endsWith("/catalog")
        ? Response.json({ ok: true, data: catalog })
        : Response.json({ ok: false, error: { code: "MMS_SESSION_REQUIRED" } }, { status: 401 }),
    ),
  );
  mount();
  await fill();
  fireEvent.click(screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" }));
  await screen.findByText("ยืนยันบัญชีและสิทธิ์ผ่าน LINE ก่อนครับ");
  expect(screen.getByRole("link", { name: "ยืนยันบัญชีผ่าน LINE" })).toBeTruthy();
  expect(screen.queryByText("ไม่พบผู้ให้บริการตามเงื่อนไขนี้ครับ")).toBeNull();
});
it("account switch aborts an in-flight search and cannot show the previous account result", async () => {
  let aborted = false;
  vi.stubGlobal(
    "fetch",
    vi.fn(async (path: string, init?: RequestInit) =>
      path.endsWith("/catalog")
        ? Response.json({ ok: true, data: catalog })
        : await new Promise<Response>((_resolve, reject) =>
            init?.signal?.addEventListener(
              "abort",
              () => {
                aborted = true;
                reject(new DOMException("Cancelled", "AbortError"));
              },
              { once: true },
            ),
          ),
    ),
  );
  mount();
  await fill();
  fireEvent.click(screen.getByRole("button", { name: "ค้นหาผู้ให้บริการ" }));
  await waitFor(() => expect(vi.mocked(fetch)).toHaveBeenCalledTimes(2));
  window.dispatchEvent(new Event("mms:account-switch"));
  await waitFor(() => expect(aborted).toBe(true));
  await screen.findByLabelText("บริการ");
  expect(screen.queryByText("ชื่อสาธารณะสำหรับทดสอบ")).toBeNull();
});
