import React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import { GraphicProgress } from "./graphic-progress";
import { MmsApiError } from "../../lib/mms/mms-fetch";
const queries = vi.hoisted(() => ({ customer: {} as Record<string, unknown>, booking: {} as Record<string, unknown> }));
vi.mock("@tanstack/react-router", () => ({ createFileRoute: () => () => ({}), Link: ({ children, to }: { children: React.ReactNode; to: string }) => <a href={to}>{children}</a> }));
vi.mock("./app-shell", () => ({ AppShell: ({ children }: { children: React.ReactNode }) => <div data-mms-graphics>{children}</div> }));
vi.mock("../../lib/mms/provider-context", () => ({ useMms: () => ({ isMock: false }), useCustomer: () => queries.customer, useCurrentBooking: () => queries.booking, useSearchCatalog: () => ({ isPending: false, isError: true, error: new MmsApiError(503, "MMS_CUSTOMER_CONTRACT_CHECKING"), refetch: vi.fn() }), useTherapistSearch: () => ({ isFetching: false }) }));
import { HomePage } from "../../routes/index";
afterEach(() => { cleanup(); vi.useRealTimers(); });
function booking(overrides: Record<string, unknown>) { queries.customer = { isSuccess: true, data: { identityState: "verified" } }; queries.booking = { isPending: false, isError: false, isFetching: false, refetch: vi.fn(), ...overrides }; }
describe("actual request progress", () => {
  it("holds a truthful percentage while waiting and removes the completed loader", () => {
    vi.useFakeTimers(); const ui = render(<GraphicProgress completed={1} total={3} />);
    expect(screen.getByRole("progressbar").getAttribute("aria-valuenow")).toBe("33");
    vi.advanceTimersByTime(60000);
    expect(screen.getByRole("progressbar").getAttribute("aria-valuenow")).toBe("33");
    ui.rerender(<GraphicProgress completed={3} total={3} />);
    expect(screen.queryByRole("progressbar")).toBeNull();
  });
});
describe("customer booking truth", () => {
  it("shows the real appointment and detail action first without a personal contact link", () => {
    booking({ data: { id: "fixture-request", serviceLabel: "คอร์สจาก API", scheduledLabel: "วันเวลาจาก API", areaLabel: "เขตจาก API", status: "pending" } });
    render(<HomePage />); expect(screen.getByText("คอร์สจาก API")).toBeTruthy();
    expect(screen.getAllByRole("link")[0]?.textContent).toContain("ดูรายละเอียด");
    expect(screen.queryByText(/คุยกับเปอร์|Per/)).toBeNull();
    expect(screen.queryByText("ค้นหาตามบริการและพื้นที่")).toBeNull();
  });
  it("keeps loading separate from confirmed empty", () => {
    booking({ isPending: true }); render(<HomePage />);
    expect(screen.getByRole("progressbar").getAttribute("aria-valuenow")).toBe("50");
    expect(screen.queryByText(/ระบบยืนยันแล้วว่าไม่มี/)).toBeNull();
  });
  it("never turns a 503 into no appointments or a matching result", () => {
    booking({ isError: true, error: new MmsApiError(503, "CHECKING") }); render(<HomePage />);
    expect(screen.getByText("ยังตรวจสอบรายการนัดไม่ได้ครับ")).toBeTruthy();
    expect(screen.queryByText(/ระบบยืนยันแล้วว่าไม่มี/)).toBeNull();
    expect(screen.queryByText("ค้นหาตามบริการและพื้นที่")).toBeNull();
  });
  it("shows MMS AI only for API-confirmed null and exposes its unavailable backend honestly", () => {
    booking({ data: null }); render(<HomePage />);
    expect(screen.getByText("ค้นหาตามบริการและพื้นที่")).toBeTruthy();
    expect(screen.getByText("ยังตรวจสอบระบบจับคู่ไม่ได้ครับ")).toBeTruthy();
    expect(screen.queryByLabelText("บริการ")).toBeNull();
  });
  it("requires LINE again without exposing a previous appointment", () => {
    booking({ isError: true, error: new MmsApiError(401, "MMS_SESSION_REQUIRED"), data: { serviceLabel: "stale account" } }); render(<HomePage />);
    expect(screen.getByRole("link", { name: "ยืนยันบัญชีผ่าน LINE" })).toBeTruthy();
    expect(screen.queryByText("stale account")).toBeNull();
  });
});
