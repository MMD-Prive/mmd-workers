import { useIsFetching, useIsMutating } from "@tanstack/react-query";

/** Pack V2 adapter: only completed operations move the bar. No elapsed-time estimates. */
export function GraphicProgress({ completed = 0, total = 1, label = "กำลังตรวจข้อมูลจากระบบครับ" }: {
  completed?: number; total?: number; label?: string;
}) {
  const percent = Math.floor(Math.min(completed, total) / Math.max(1, total) * 100);
  if (percent === 100) return null;
  return <div className="mms-progress" data-state="loading" role="status">
    <div className="mms-progress-label"><span>{label}</span><span>{percent}%</span></div>
    <div className="mms-track" role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent}>
      <div className="mms-fill" style={{ width: `${percent}%`, minWidth: percent === 0 ? "100%" : undefined, background: percent === 0 ? "transparent" : undefined }} />
    </div>
    <p className="text-xs text-muted-foreground">ขั้นตอนที่สำเร็จ {completed}/{total} · ระหว่างรอความคืบหน้าจะคงเดิมครับ</p>
  </div>;
}

export function PendingOperations() {
  const reads = useIsFetching({ queryKey: ["mms"] });
  const writes = useIsMutating();
  return reads || writes ? <GraphicProgress label={writes ? "กำลังบันทึกและรอผลยืนยันครับ" : "กำลังโหลดข้อมูลล่าสุดครับ"} /> : null;
}
