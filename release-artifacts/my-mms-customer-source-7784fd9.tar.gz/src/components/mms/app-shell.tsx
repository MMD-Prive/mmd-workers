import { Link, useRouterState } from "@tanstack/react-router";
import {
  BriefcaseBusiness,
  CalendarDays,
  CreditCard,
  Home,
  LifeBuoy,
  LogOut,
  MessageCircle,
  Sparkles,
  UserRound,
} from "lucide-react";
import { useState, useEffect, useRef, type ReactNode } from "react";

import { cn } from "../../lib/utils";
import { MMS_CHAT_ROUTE, MMS_ROUTES, MMS_THERAPIST_LOGIN_URL } from "../../lib/mms/config";
import { useMms } from "../../lib/mms/provider-context";
import { useIsTherapistMode, useTherapistContext } from "../../lib/mms/dispatch-context";
import { therapistLogout } from "../../lib/mms/therapist-auth";
import type { LanguageCode } from "../../lib/mms/types";
import mmsLogo from "../../assets/graphics-v2/brand/mms-horizontal-light.svg?url";
import { PendingOperations } from "./graphic-progress";

const NAV = [
  { to: MMS_ROUTES.home, icon: Home, key: "nav.home" },
  { to: MMS_ROUTES.bookings, icon: CalendarDays, key: "nav.bookings" },
  { to: MMS_ROUTES.therapists, icon: Sparkles, key: "nav.therapists" },
  { to: MMS_ROUTES.payment, icon: CreditCard, key: "nav.payment" },
  { to: MMS_ROUTES.profile, icon: UserRound, key: "nav.profile" },
] as const;

const LANGS: LanguageCode[] = ["th", "en", "zh"];

const CUSTOMER_NAV = [
  NAV[0],
  NAV[1],
  { to: MMS_CHAT_ROUTE, icon: MessageCircle, key: "nav.chat" },
  NAV[4],
  { to: MMS_ROUTES.support, icon: LifeBuoy, key: "nav.support" },
] as const;

/** LINE Mini App-like shell: compact header, scroll body, bottom tab bar. */
export function AppShell({ children }: { children: ReactNode }) {
  const navRef = useRef<HTMLElement>(null);
  const [navHeight, setNavHeight] = useState(88);
  useEffect(() => {
    if (!navRef.current) return;
    const observer = new ResizeObserver(entries => { const entry = entries[0]; if (entry) setNavHeight(entry.target.getBoundingClientRect().height); });
    observer.observe(navRef.current); return () => observer.disconnect();
  }, []);
  const [logoUnavailable, setLogoUnavailable] = useState(false);
  const { tr, lang, setLang } = useMms();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  // Therapist tab appears only when the backend confirms the audience.
  const { confirmed: isTherapist } = useIsTherapistMode();
  const therapist = useTherapistContext();
  // Therapist mode leads with Jobs; the customer IA is never removed globally.
  const nav = isTherapist
    ? ([
        { to: MMS_ROUTES.jobs, icon: BriefcaseBusiness, key: "nav.jobs" } as const,
        ...NAV.filter((item) => item.to !== MMS_ROUTES.payment),
        { to: MMS_ROUTES.support, icon: LifeBuoy, key: "nav.support" } as const,
      ] as const)
    : CUSTOMER_NAV;

  const onLogout = async () => {
    await therapistLogout();
    window.location.assign(MMS_THERAPIST_LOGIN_URL);
  };

  return (
    <div data-mms-graphics="customer-v2" className="min-h-[100dvh] bg-background text-foreground">
      <header className="sticky top-0 z-30 border-b border-border/70 bg-background/85 pt-[env(safe-area-inset-top)] backdrop-blur-xl">
        <div className="mx-auto flex max-w-md items-center justify-between gap-3 px-5 py-3 md:max-w-2xl">
          <Link
            to={MMS_ROUTES.home}
            aria-label={isTherapist ? "MY MMS · Therapist" : "MY MMS · Male Massage"}
            className="flex min-w-0 items-center gap-2"
          >
            {logoUnavailable ? (
              <span className="leading-tight text-[color:var(--leaf)]">
                <span className="block text-lg font-semibold tracking-widest">MY MMS</span>
                <span className="block text-[0.6rem] tracking-[0.12em]">MALE MASSAGE</span>
              </span>
            ) : (
              <img
                ref={(image) => {
                  if (image?.complete && image.naturalWidth === 0) setLogoUnavailable(true);
                }}
                src={mmsLogo}
                alt="MY MMS · Male Massage"
                className="max-h-9 w-[108px] object-contain"
                width={430}
                height={100}
                onError={() => setLogoUnavailable(true)}
              />
            )}
            {isTherapist && (
              <span className="rounded-full bg-[color:var(--leaf-soft)] px-2 py-0.5 text-[0.65rem] font-semibold text-[color:var(--leaf)]">
                Therapist
              </span>
            )}
          </Link>
          <div role="group" aria-label="ภาษา / Language" className="mms-languages flex shrink-0 items-center rounded-full border border-border bg-surface p-0.5">
            {LANGS.map((code) => (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                aria-pressed={lang === code}
                className={cn(
                  "min-h-11 min-w-11 rounded-full px-2.5 text-[0.68rem] font-medium uppercase tracking-wide transition-colors",
                  lang === code ? "bg-primary text-primary-foreground" : "text-muted-foreground",
                )}
              >
                {code}
              </button>
            ))}
          </div>
        </div>

        {/* Compact session chip — backend-safe fields only. */}
        {isTherapist && (
          <div className="mx-auto flex max-w-md items-center justify-between gap-3 px-5 pb-2 md:max-w-2xl">
            <p className="min-w-0 truncate text-[0.72rem] text-muted-foreground">
              <span className="font-semibold text-foreground">
                {therapist.data?.therapistPublicName ?? "กำลังตรวจสอบ"}
              </span>
              {therapist.data?.therapistRefDisplay && ` · ${therapist.data.therapistRefDisplay}`}
              {therapist.data?.availabilityLabel && ` · ${therapist.data.availabilityLabel}`}
            </p>
            <button
              type="button"
              onClick={onLogout}
              className="inline-flex min-h-8 shrink-0 items-center gap-1 rounded-full border border-border px-3 text-[0.7rem] font-medium text-muted-foreground"
            >
              <LogOut className="h-3.5 w-3.5" aria-hidden />
              ออกจากระบบ
            </button>
          </div>
        )}
      </header>

      <main style={{ paddingBottom: `calc(${navHeight + 24}px + env(safe-area-inset-bottom))` }} className="mx-auto max-w-md px-5 pb-[calc(88px+env(safe-area-inset-bottom))] pt-4 md:max-w-2xl">
        <PendingOperations />
        {children}
      </main>

      <nav ref={navRef}
        aria-label={tr("nav.home")}
        className="fixed inset-x-0 bottom-0 z-30 border-t border-border/70 bg-background/92 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl"
      >
        <ul className="mx-auto flex max-w-md items-stretch justify-between px-2 md:max-w-2xl">
          {nav.map(({ to, icon: Icon, key }) => {
            const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
            const className = cn(
              "flex min-h-[60px] flex-col items-center justify-center gap-1 rounded-2xl px-1 py-2 text-[0.65rem] font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary",
              active ? "text-[color:var(--leaf)]" : "text-muted-foreground",
            );
            const content = (
              <>
                <Icon className="h-5 w-5" strokeWidth={active ? 2.2 : 1.7} aria-hidden />
                <span>{tr(key)}</span>
              </>
            );
            return (
              <li key={to} className="flex-1">
                {to === MMS_CHAT_ROUTE ? (
                  <a href={to} className={className}>
                    {content}
                  </a>
                ) : (
                  <Link to={to} aria-current={active ? "page" : undefined} className={className}>
                    {content}
                  </Link>
                )}
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
