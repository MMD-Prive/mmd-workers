import { useNavigate } from "@tanstack/react-router";
import {
  AlertTriangle,
  BadgeCheck,
  Clock,
  Loader2,
  MapPin,
  Navigation,
  Timer,
  Wallet,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

import { cn } from "../../lib/utils";
import { useDispatch, useJobAction, useJobOffer } from "../../lib/mms/dispatch-context";
import type { JobOffer, JobState } from "../../lib/mms/dispatch-types";

/**
 * INCOMING JOB OFFER — priority full-screen sheet.
 *
 * Shows only pre-accept safe fields. Customer name, phone, exact address,
 * LINE identity, notes and payment internals are never rendered here; they
 * only exist on the job detail page after the backend confirms ACCEPTED and
 * marks them disclose-safe.
 */

/** Visual timer only. The backend remains authoritative on expiry. */
function useCountdown(expiresAt: string | null): { label: string | null; expired: boolean } {
  const target = useMemo(() => (expiresAt ? Date.parse(expiresAt) : NaN), [expiresAt]);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!Number.isFinite(target)) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [target]);

  if (!Number.isFinite(target)) return { label: null, expired: false };
  const left = Math.max(0, Math.floor((target - now) / 1000));
  const mm = String(Math.floor(left / 60)).padStart(2, "0");
  const ss = String(left % 60).padStart(2, "0");
  return { label: `${mm}:${ss}`, expired: left <= 0 };
}

const STATE_COPY: Record<string, { title: string; hint: string }> = {
  TAKEN: { title: "งานนี้มี Therapist รับแล้ว", hint: "ระบบจับคู่ให้ผู้ที่ตอบรับก่อนแล้วครับ" },
  EXPIRED: { title: "งานนี้หมดเวลาตอบรับแล้ว", hint: "รอรับงานใหม่จากระบบได้เลยครับ" },
  DECLINED: { title: "ปฏิเสธงานนี้แล้ว", hint: "ระบบจะส่งงานถัดไปให้เมื่อมีการจับคู่ใหม่" },
  CANCELLED: { title: "งานนี้ถูกยกเลิก", hint: "ทีมงานยกเลิกงานนี้ในระบบแล้ว" },
  CHECKING: { title: "กำลังตรวจสอบสถานะงาน", hint: "ยังยืนยันผลกับระบบไม่ได้ กรุณาลองอีกครั้ง" },
  ERROR: { title: "ยังเชื่อมต่อระบบไม่ได้", hint: "สถานะงานจริงอยู่ที่ระบบ ลองใหม่อีกครั้งครับ" },
};

function KeyFact({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Clock;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3 rounded-2xl bg-[color:var(--surface,#ffffff)]/10 px-3.5 py-3">
      <Icon className="mt-0.5 h-4.5 w-4.5 shrink-0 text-[color:var(--offer-accent,#cfe3c9)]" aria-hidden />
      <div className="min-w-0">
        <p className="text-[0.68rem] font-medium uppercase tracking-wide text-[color:var(--offer-muted,#d6e0d2)]">
          {label}
        </p>
        <p className="text-[0.95rem] font-semibold leading-snug text-white">{value}</p>
      </div>
    </div>
  );
}

export function JobOfferSheet({ jobId, onClose }: { jobId: string; onClose: () => void }) {
  const navigate = useNavigate();
  const { data: offer, isPending, isError, refetch } = useJobOffer(jobId);
  const { accept, decline } = useJobAction(jobId);
  const requestKey = useRef(`${jobId}:${Date.now()}`).current;

  const serverState: JobState | null = accept.data?.state ?? decline.data?.state ?? null;
  const busy = accept.isPending || decline.isPending;
  const state: JobState = busy
    ? "ACCEPTING"
    : (serverState ?? (isError ? "ERROR" : isPending ? "CHECKING" : (offer?.state ?? "CHECKING")));

  const countdown = useCountdown(offer?.expiresAt ?? null);
  const failedWrite =
    (accept.isError || decline.isError) && !busy ? "CHECKING" : null;
  const resolved = failedWrite ?? state;

  useEffect(() => {
    if (serverState === "ACCEPTED") {
      const id = window.setTimeout(() => {
        onClose();
        navigate({ to: "/jobs/$jobId", params: { jobId } });
      }, 900);
      return () => window.clearTimeout(id);
    }
    return undefined;
  }, [serverState, jobId, navigate, onClose]);

  const closed =
    resolved === "TAKEN" ||
    resolved === "EXPIRED" ||
    resolved === "DECLINED" ||
    resolved === "CANCELLED";

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="งานใหม่จากระบบ Male Massage"
      className="fixed inset-0 z-50 flex flex-col bg-[#12251b] text-white motion-safe:animate-[offerSheetIn_320ms_cubic-bezier(0.32,0.72,0,1)]"
      style={{
        paddingTop: "env(safe-area-inset-top)",
        paddingBottom: "env(safe-area-inset-bottom)",
      }}
    >
      <div className="flex items-center justify-between px-5 pt-4">
        <p className="text-[0.7rem] font-semibold uppercase tracking-[0.24em] text-[#cfe3c9]">
          Incoming request · งานใหม่
        </p>
        <button
          type="button"
          onClick={onClose}
          aria-label="ปิด"
          className="flex h-11 w-11 items-center justify-center rounded-full bg-white/10"
        >
          <X className="h-5 w-5" aria-hidden />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-4 pt-3">
        {resolved === "ACCEPTED" ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
            <BadgeCheck className="h-14 w-14 text-[#9fd68c]" aria-hidden />
            <h1 className="text-2xl font-semibold">JOB CONFIRMED ✓</h1>
            <p className="text-sm text-[#d6e0d2]">กำลังเปิดรายละเอียดงานให้ครับ</p>
          </div>
        ) : closed ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
            <AlertTriangle className="h-12 w-12 text-[#e8c46a]" aria-hidden />
            <h1 className="text-xl font-semibold">{STATE_COPY[resolved]?.title}</h1>
            <p className="max-w-[30ch] text-sm text-[#d6e0d2]">{STATE_COPY[resolved]?.hint}</p>
          </div>
        ) : resolved === "CHECKING" || resolved === "ERROR" ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
            <Loader2
              className={cn("h-10 w-10", resolved === "CHECKING" && "motion-safe:animate-spin")}
              aria-hidden
            />
            <h1 className="text-lg font-semibold">{STATE_COPY[resolved]?.title}</h1>
            <p className="max-w-[30ch] text-sm text-[#d6e0d2]">{STATE_COPY[resolved]?.hint}</p>
            <button
              type="button"
              onClick={() => refetch()}
              className="mt-3 min-h-12 rounded-full bg-white/12 px-6 text-sm font-medium"
            >
              ลองอีกครั้ง
            </button>
          </div>
        ) : (
          <OfferBody offer={offer as JobOffer} countdownLabel={countdown.label} />
        )}
      </div>

      {!closed && resolved !== "ACCEPTED" && offer && (
        <div className="space-y-2.5 border-t border-white/10 px-5 pb-3 pt-3">
          <button
            type="button"
            disabled={busy || resolved === "CHECKING" || resolved === "ERROR"}
            onClick={() => accept.mutate({ requestKey })}
            className="flex min-h-[60px] w-full items-center justify-center gap-2 rounded-2xl bg-[#9fd68c] text-base font-semibold text-[#12251b] disabled:opacity-60"
          >
            {busy && <Loader2 className="h-5 w-5 motion-safe:animate-spin" aria-hidden />}
            {accept.isPending ? "กำลังรับงาน…" : "ACCEPT JOB · รับงานนี้"}
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() => decline.mutate({})}
            className="min-h-12 w-full rounded-2xl border border-white/25 text-sm font-medium text-white disabled:opacity-60"
          >
            NOT AVAILABLE · ยังรับงานนี้ไม่ได้
          </button>
        </div>
      )}
    </div>
  );
}

function OfferBody({
  offer,
  countdownLabel,
}: {
  offer: JobOffer;
  countdownLabel: string | null;
}) {
  return (
    <div className="space-y-3">
      <div className="flex items-end justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-[1.6rem] font-semibold leading-tight">{offer.serviceLabel}</h1>
          {offer.durationLabel && (
            <p className="text-sm text-[#d6e0d2]">{offer.durationLabel}</p>
          )}
        </div>
        {countdownLabel && (
          <div className="shrink-0 rounded-2xl bg-white/12 px-3 py-2 text-center">
            <Timer className="mx-auto h-4 w-4 text-[#e8c46a]" aria-hidden />
            <p className="mt-0.5 font-mono text-lg font-semibold tabular-nums leading-none">
              {countdownLabel}
            </p>
          </div>
        )}
      </div>

      <div className="grid gap-2">
        {offer.scheduledLabel && (
          <KeyFact icon={Clock} label="วันและเวลา" value={offer.scheduledLabel} />
        )}
        {offer.areaLabel && <KeyFact icon={MapPin} label="โซนพื้นที่" value={offer.areaLabel} />}
        {(offer.travelLabel || offer.etaLabel) && (
          <KeyFact
            icon={Navigation}
            label="การเดินทาง"
            value={[offer.travelLabel, offer.etaLabel].filter(Boolean).join(" · ")}
          />
        )}
        {offer.payoutLabel && (
          <KeyFact icon={Wallet} label="รายได้โดยประมาณ" value={offer.payoutLabel} />
        )}
      </div>

      {offer.payoutNote && <p className="px-1 text-xs text-[#d6e0d2]">{offer.payoutNote}</p>}
      {offer.noteLabel && (
        <p className="rounded-2xl bg-white/8 px-3.5 py-3 text-sm leading-relaxed text-[#e6ece2]">
          {offer.noteLabel}
        </p>
      )}
      <p className="px-1 text-[0.7rem] leading-relaxed text-[#b9c9b4]">
        ที่อยู่แบบละเอียดและข้อมูลติดต่อลูกค้าจะเปิดให้หลังระบบยืนยันการรับงานเท่านั้น
      </p>
      {offer.refDisplay && (
        <p className="px-1 text-[0.7rem] text-[#b9c9b4]">รหัสงาน {offer.refDisplay}</p>
      )}
    </div>
  );
}

/**
 * Host: renders the sheet above any MY MMS screen. Opens only for an offer
 * the adapter confirmed — never from a query string field.
 */
export function JobOfferHost() {
  const { activeOfferId, closeOffer } = useDispatch();
  if (!activeOfferId) return null;
  return <JobOfferSheet jobId={activeOfferId} onClose={closeOffer} />;
}
