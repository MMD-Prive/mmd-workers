import { Heart } from "lucide-react";

import { cn } from "../../lib/utils";
import type { TherapistPublicSummary } from "../../lib/mms/types";
import { TherapistAvatar } from "./booking-card";

/**
 * Customer-safe therapist card. Public working name, photo, service/area tags
 * only. Never internal review status, matching score, contact or payout data.
 */
export function TherapistCard({
  therapist,
  onToggleFavorite,
  pending = false,
}: {
  therapist: TherapistPublicSummary;
  onToggleFavorite?: (next: boolean) => void;
  pending?: boolean;
}) {
  return (
    <article className="surface-card flex items-start gap-3 p-4">
      <TherapistAvatar name={therapist.publicName} photoUrl={therapist.photoUrl} />
      <div className="min-w-0 flex-1">
        <p className="text-[0.95rem] font-semibold tracking-tight text-foreground">
          Therapist {therapist.publicName}
        </p>
        {therapist.headline && (
          <p className="mt-0.5 truncate text-xs text-muted-foreground">{therapist.headline}</p>
        )}
        <div className="mt-2 flex flex-wrap gap-1.5">
          {[...therapist.serviceTags, ...therapist.areaTags].map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-secondary px-2 py-0.5 text-[0.68rem] text-secondary-foreground"
            >
              {tag}
            </span>
          ))}
        </div>
        <p className="mt-2 text-[0.7rem] text-muted-foreground">
          {therapist.lastUsedLabel ?? "ยังไม่มีประวัติการใช้บริการ"}
          {typeof therapist.timesBooked === "number" && ` · ใช้บริการ ${therapist.timesBooked} ครั้ง`}
        </p>
      </div>
      {onToggleFavorite && (
        <button
          type="button"
          disabled={pending}
          onClick={() => onToggleFavorite(!therapist.isFavorite)}
          aria-pressed={therapist.isFavorite}
          aria-label={therapist.isFavorite ? "นำออกจากรายการโปรด" : "เพิ่มในรายการโปรด"}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-border bg-surface transition-transform active:scale-95 disabled:opacity-50"
        >
          <Heart
            className={cn(
              "h-5 w-5",
              therapist.isFavorite
                ? "fill-[color:var(--leaf)] text-[color:var(--leaf)]"
                : "text-muted-foreground",
            )}
            aria-hidden
          />
        </button>
      )}
    </article>
  );
}
