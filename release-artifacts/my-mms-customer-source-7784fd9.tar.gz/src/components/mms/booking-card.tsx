import { Link } from "@tanstack/react-router";
import { CalendarDays, ChevronRight, MapPin, UserRound } from "lucide-react";

import { cn } from "../../lib/utils";
import type { BookingSummary } from "../../lib/mms/types";
import {
  Pill,
  bookingStatusLabel,
  bookingTone,
  paymentStateLabel,
  paymentTone,
} from "./primitives";

export function TherapistAvatar({
  name,
  photoUrl,
  size = "md",
}: {
  name: string;
  photoUrl: string | null;
  size?: "sm" | "md";
}) {
  const dim = size === "sm" ? "h-9 w-9 text-xs" : "h-12 w-12 text-sm";
  if (photoUrl) {
    return (
      <img
        src={photoUrl}
        alt={`Therapist ${name}`}
        loading="lazy"
        className={cn("rounded-full object-cover", dim)}
      />
    );
  }
  return (
    <span
      aria-hidden
      className={cn(
        "flex items-center justify-center rounded-full bg-[color:var(--leaf-soft)] font-semibold text-[color:var(--leaf)]",
        dim,
      )}
    >
      {name.slice(0, 2).toUpperCase()}
    </span>
  );
}

export function BookingCard({
  booking,
  emphasis = false,
}: {
  booking: BookingSummary;
  emphasis?: boolean;
}) {
  return (
    <Link
      to="/bookings/$bookingId"
      params={{ bookingId: booking.id }}
      className={cn(
        "surface-card block p-4 transition-transform duration-200 active:scale-[0.99]",
        emphasis && "surface-card-leaf",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[0.95rem] font-semibold tracking-tight text-foreground">
            {booking.serviceLabel}
          </p>
          {booking.refDisplay && (
            <p className="mt-0.5 text-[0.7rem] text-muted-foreground">{booking.refDisplay}</p>
          )}
        </div>
        <Pill tone={bookingTone(booking.status)}>{bookingStatusLabel(booking.status)}</Pill>
      </div>

      <dl className="mt-3 space-y-1.5 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <CalendarDays className="h-4 w-4 shrink-0" aria-hidden />
          <dd className="text-foreground">{booking.scheduledLabel ?? "รอยืนยันเวลา"}</dd>
        </div>
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4 shrink-0" aria-hidden />
          <dd>{booking.areaLabel ?? "รอยืนยันพื้นที่"}</dd>
        </div>
        <div className="flex items-center gap-2">
          <UserRound className="h-4 w-4 shrink-0" aria-hidden />
          <dd className="flex items-center gap-2">
            {booking.therapist ? (
              <>
                <TherapistAvatar
                  name={booking.therapist.publicName}
                  photoUrl={booking.therapist.photoUrl}
                  size="sm"
                />
                <span className="text-foreground">Therapist {booking.therapist.publicName}</span>
              </>
            ) : (
              <span>กำลังจัด Therapist</span>
            )}
          </dd>
        </div>
      </dl>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-border/70 pt-3">
        <div className="flex flex-wrap items-center gap-2">
          <Pill tone={paymentTone(booking.paymentState)}>
            {paymentStateLabel(booking.paymentState)}
          </Pill>
          {booking.amountSummary && (
            <span className="text-xs text-muted-foreground">{booking.amountSummary}</span>
          )}
        </div>
        <span className="inline-flex items-center gap-1 text-xs font-medium text-[color:var(--leaf)]">
          {booking.nextAction?.label ?? "ดูรายละเอียด"}
          <ChevronRight className="h-4 w-4" aria-hidden />
        </span>
      </div>
    </Link>
  );
}
