/**
 * MY MMS — therapist dispatch (MMS AI → Matching → Therapist → Accept → Service).
 *
 * CANON
 * - The Cloudflare Worker owns audience/role, matching, job state, payout and
 *   every disclosure decision. The browser never infers any of it.
 * - Customer PII is only present in a payload after the backend has confirmed
 *   ACCEPTED and marked the fields disclose-safe.
 * - Missing / unconfirmed data fails closed to "checking".
 */

/** Who the backend says is using this session. Never inferred in the browser. */
export type MmsAudience = "customer" | "therapist" | "checking" | "unknown";

export interface TherapistContext {
  audience: MmsAudience;
  /** Public working name only. Never real identity. */
  therapistPublicName: string | null;
  therapistRefDisplay: string | null;
  /** Backend-provided availability label, e.g. "พร้อมรับงาน". */
  availabilityLabel: string | null;
  /** Backend-provided count of live offers, when it exposes one. */
  incomingOfferCount: number | null;
}

export type JobState =
  | "OFFERED"
  | "ACCEPTING"
  | "ACCEPTED"
  | "DECLINED"
  | "EXPIRED"
  | "TAKEN"
  | "CANCELLED"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "CHECKING"
  | "ERROR";

/** Fields visible BEFORE accept. Nothing here may identify the customer. */
export interface JobOffer {
  jobId: string;
  /** Display-safe reference, e.g. "MMS-J-260909-04". */
  refDisplay: string | null;
  state: JobState;
  serviceLabel: string;
  durationLabel: string | null;
  scheduledLabel: string | null;
  /** Zone-level only before accept. */
  areaLabel: string | null;
  /** Backend-computed only. */
  travelLabel: string | null;
  etaLabel: string | null;
  /** Backend-safe pre-formatted payout string. Never computed here. */
  payoutLabel: string | null;
  payoutNote: string | null;
  /** ISO timestamp from backend; the timer is visual only. */
  expiresAt: string | null;
  noteLabel: string | null;
}

/** Fields the backend may unlock AFTER it confirms ACCEPTED. */
export interface JobDisclosure {
  locationUnlocked: boolean;
  addressLabel: string | null;
  /** Backend-supplied safe map URL. Never constructed in the browser. */
  mapUrl: string | null;
  /** Display label only, if backend marks it safe. */
  customerDisplayLabel: string | null;
  contactLabel: string | null;
  contactUrl: string | null;
}

export interface JobTimelineEntry {
  label: string;
  atLabel: string | null;
  note: string | null;
  state: "done" | "current" | "upcoming";
}

export interface JobDetail extends JobOffer {
  disclosure: JobDisclosure;
  payoutSummaryLabel: string | null;
  paymentStateLabel: string | null;
  timeline: JobTimelineEntry[];
  supportUrl: string | null;
}

export interface JobActionResult {
  /** Canonical state returned by the backend after the write. */
  state: JobState;
  message: string | null;
  jobId: string;
}

export interface MmsDispatchProvider {
  readonly kind: "mock" | "live";
  getTherapistContext(): Promise<TherapistContext>;
  getIncomingJobOffers(): Promise<JobOffer[]>;
  getJobOffer(jobId: string): Promise<JobOffer>;
  acceptJob(jobId: string, requestKey?: string): Promise<JobActionResult>;
  declineJob(jobId: string, reason?: string): Promise<JobActionResult>;
  /** Service lifecycle writes. Backend remains authoritative for the state. */
  startJob(jobId: string, requestKey?: string): Promise<JobActionResult>;
  completeJob(jobId: string, requestKey?: string): Promise<JobActionResult>;
  getJobDetail(jobId: string): Promise<JobDetail>;
  getJobs(): Promise<JobDetail[]>;
  /**
   * Optional push abstraction. No production websocket endpoint is invented:
   * when the backend has none, the app falls back to the documented refresh
   * strategy (route load, visibility/focus return, after every write).
   */
  subscribeToJobUpdates?(callback: () => void): () => void;
}
