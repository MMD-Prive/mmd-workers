/**
 * MOCK therapist session — visual preview only, never a production fallback.
 * Isolated from the live auth module: only used when the app is NOT on a
 * canonical live host and an explicit ?mms_auth= scenario is present.
 *
 * ?mms_auth=ok | session | forbidden | error
 */

import type { TherapistSession } from "./therapist-auth";

export type AuthScenario = "ok" | "session" | "forbidden" | "error" | "off";

const SCENARIOS: AuthScenario[] = ["ok", "session", "forbidden", "error"];

export function readAuthScenario(search?: string): AuthScenario {
  if (typeof window === "undefined") return "off";
  const raw = new URLSearchParams(search ?? window.location.search).get("mms_auth");
  return raw && (SCENARIOS as string[]).includes(raw) ? (raw as AuthScenario) : "off";
}

export async function mockTherapistSession(scenario: AuthScenario): Promise<TherapistSession> {
  await new Promise((r) => setTimeout(r, 250));
  switch (scenario) {
    case "ok":
      return {
        status: "authenticated",
        profile: {
          therapistId: "MMS-T-118",
          displayName: "Ohm",
          availabilityStatus: "พร้อมรับงาน",
          role: "mms_therapist",
          nextRoute: "/male-massage/therapists/me",
        },
      };
    case "forbidden":
      return { status: "forbidden" };
    case "error":
      return { status: "error", kind: "error" };
    default:
      return { status: "session_required" };
  }
}
