/**
 * MY MMS — REAL therapist session bootstrap.
 *
 * This is the one part of the therapist layer backed by an implemented
 * mms-worker contract (GitHub/main):
 *   POST /male-massage/therapists/api/auth/line
 *   GET  /male-massage/therapists/api/auth/me
 *   POST /male-massage/therapists/api/auth/logout
 *
 * The session lives in the HttpOnly cookie __Secure-mms_therapist_session
 * (Path=/male-massage/therapists). The browser never reads the cookie, never
 * stores an ID token, and never infers the therapist role from route, query
 * or local state — only a valid auth/me profile with role 'mms_therapist'
 * confirms therapist mode.
 */

import { MMS_THERAPIST_ROLE, THERAPIST_AUTH_LOGOUT, THERAPIST_AUTH_ME } from "./config";
import { MmsApiError, fetchMmsJson, isRecord } from "./mms-fetch";
import type { TherapistContext } from "./dispatch-types";

/** Backend profile shape returned by auth/me on success. */
export interface TherapistAuthProfile {
  therapistId: string | null;
  displayName: string | null;
  availabilityStatus: string | null;
  role: string | null;
  nextRoute: string | null;
}

export type TherapistSession =
  | { status: "authenticated"; profile: TherapistAuthProfile }
  /** 401 or no session cookie — the therapist must log in through LINE. */
  | { status: "session_required" }
  /** 403 — suspended / revoked / not allowed. Show no therapist data. */
  | { status: "forbidden" }
  /** Network, timeout, 5xx, malformed — Checking / retry. */
  | { status: "error"; kind: "checking" | "error" };

const str = (v: unknown): string | null => (typeof v === "string" && v ? v : null);

export function mapAuthProfile(raw: unknown): TherapistAuthProfile | null {
  if (!isRecord(raw)) return null;
  const body = isRecord(raw["profile"])
    ? (raw["profile"] as Record<string, unknown>)
    : isRecord(raw["data"])
      ? (raw["data"] as Record<string, unknown>)
      : raw;
  return {
    therapistId: str(body["therapist_id"]),
    displayName: str(body["display_name"]),
    availabilityStatus: str(body["availability_status"]),
    role: str(body["role"]),
    nextRoute: str(body["next_route"]),
  };
}

/** Read the canonical therapist session. Fails closed on anything unclear. */
export async function fetchTherapistSession(): Promise<TherapistSession> {
  try {
    const { body } = await fetchMmsJson(THERAPIST_AUTH_ME, { method: "GET" });
    const profile = mapAuthProfile(body);
    if (!profile || profile.role !== MMS_THERAPIST_ROLE) return { status: "session_required" };
    return { status: "authenticated", profile };
  } catch (error) {
    if (error instanceof MmsApiError) {
      if (error.status === 401) return { status: "session_required" };
      if (error.status === 403) return { status: "forbidden" };
      if (error.kind === "timeout" || error.kind === "network")
        return { status: "error", kind: "checking" };
    }
    return { status: "error", kind: "error" };
  }
}

/** Real logout. The backend clears the HttpOnly cookie; JS never touches it. */
export async function therapistLogout(): Promise<void> {
  try {
    await fetchMmsJson(THERAPIST_AUTH_LOGOUT, { method: "POST" });
  } catch {
    // Ignore: the caller navigates back to the Worker login page either way.
  }
}

/** Map a confirmed session onto the dispatch audience contract. */
export function contextFromSession(session: TherapistSession): TherapistContext {
  if (session.status === "authenticated") {
    return {
      audience: "therapist",
      therapistPublicName: session.profile.displayName,
      therapistRefDisplay: session.profile.therapistId,
      availabilityLabel: session.profile.availabilityStatus,
      // Only a jobs/offers endpoint may provide this.
      incomingOfferCount: null,
    };
  }
  const audience = session.status === "error" && session.kind === "checking" ? "checking" : "unknown";
  return {
    audience,
    therapistPublicName: null,
    therapistRefDisplay: null,
    availabilityLabel: null,
    incomingOfferCount: null,
  };
}
