import type { LanguageCode } from "./types";

/**
 * MY MMS copy. Thai is the polished primary; EN/ZH are structured so the
 * Worker or a later pass can complete them without touching components.
 */

type Dict = Record<string, string>;

const th: Dict = {
  "app.name": "MY MMS",
  "app.product": "Male Massage",
  "app.tagline": "พื้นที่ส่วนตัวของลูกค้า Male Massage",
  "nav.home": "หน้าแรก",
  "nav.bookings": "การจอง",
  "nav.chat": "แชต",
  "nav.therapists": "Therapist",
  "nav.payment": "ชำระเงิน",
  "nav.profile": "โปรไฟล์",
  "nav.jobs": "งาน",
  "nav.support": "ช่วยเหลือ",
  "home.greeting": "สวัสดีครับ",
  "home.currentBooking": "การจองปัจจุบัน",
  "home.noBooking": "ยังไม่มีการจองที่กำลังจะถึง",
  "home.noBookingHint": "เลือกบริการและ Therapist ที่ต้องการได้เลยครับ",
  "home.book": "จอง Therapist",
  "home.shortcuts": "ทางลัด",
  "identity.verified": "ยืนยันตัวตนกับ LINE แล้ว",
  "identity.checking": "กำลังตรวจสอบตัวตน",
  "identity.unverified": "ยังไม่ได้ยืนยันตัวตน",
  "identity.unavailable": "ยังตรวจสอบตัวตนไม่ได้",
  "state.checking": "กำลังตรวจสอบ",
  "state.error": "ยังโหลดข้อมูลไม่ได้",
  "state.errorHint": "ข้อมูลของคุณยังอยู่ครบในระบบ ลองใหม่อีกครั้งได้ครับ",
  "state.empty": "ยังไม่มีข้อมูลในส่วนนี้",
  "state.retry": "ลองอีกครั้ง",
  "booking.status.pending": "รอยืนยัน",
  "booking.status.confirmed": "ยืนยันแล้ว",
  "booking.status.in_progress": "กำลังให้บริการ",
  "booking.status.completed": "เสร็จสิ้น",
  "booking.status.cancelled": "ยกเลิก",
  "booking.status.checking": "กำลังตรวจสอบ",
  "payment.state.deposit_required": "รอชำระมัดจำ",
  "payment.state.deposit_submitted": "รอตรวจสอบสลิป",
  "payment.state.deposit_verified": "ตรวจสอบมัดจำแล้ว",
  "payment.state.balance_due": "รอชำระส่วนที่เหลือ",
  "payment.state.completed": "ชำระครบแล้ว",
  "payment.state.unavailable": "ยังไม่มีข้อมูลการชำระเงิน",
  "payment.state.checking": "กำลังตรวจสอบ",
  "therapists.recent": "เคยใช้บริการ",
  "therapists.favorites": "รายการโปรด",
  "support.title": "ช่วยเหลือ",
  "support.line": "ติดต่อผ่าน LINE @malemassage",
};

const en: Dict = {
  "app.name": "MY MMS",
  "app.product": "Male Massage",
  "nav.home": "Home",
  "nav.bookings": "Bookings",
  "nav.chat": "Chat",
  "nav.therapists": "Therapists",
  "nav.payment": "Payment",
  "nav.profile": "Profile",
  "nav.jobs": "Jobs",
  "nav.support": "Support",
  "home.book": "Book a Therapist",
  "state.checking": "Checking",
  "state.error": "Couldn't load this yet",
};

const zh: Dict = {
  "app.name": "MY MMS",
  "app.product": "Male Massage",
  "nav.home": "首页",
  "nav.bookings": "预约",
  "nav.chat": "聊天",
  "nav.therapists": "理疗师",
  "nav.payment": "付款",
  "nav.profile": "个人",
  "nav.jobs": "工作",
  "nav.support": "支持",
  "home.book": "预约理疗师",
  "state.checking": "正在检查",
  "state.error": "暂时无法载入",
};

export const MMS_DICTIONARIES: Record<LanguageCode, Dict> = { th, en, zh };

/** TH-first lookup with graceful fallback to Thai, then the key itself. */
export function t(key: string, lang: LanguageCode = "th"): string {
  return MMS_DICTIONARIES[lang]?.[key] ?? th[key] ?? key;
}
