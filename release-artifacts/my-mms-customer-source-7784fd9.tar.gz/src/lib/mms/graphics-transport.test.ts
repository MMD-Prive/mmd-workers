import { afterEach, expect, it, vi } from "vitest";
import { fetchMmsJson, MMS_API_TIMEOUT_MS } from "./mms-fetch";
import { createLiveProvider } from "./live-provider";
afterEach(() => { vi.unstubAllGlobals(); vi.useRealTimers(); });
it("does not retry a cancelled account's read", async () => {
  const controller = new AbortController();
  const fetch = vi.fn((_path, init) => new Promise((_resolve, reject) => init.signal.addEventListener("abort", () => reject(new DOMException("cancel", "AbortError")))));
  vi.stubGlobal("fetch", fetch);
  const promise = fetchMmsJson("/api/mms/app/customer", { signal: controller.signal });
  controller.abort(); await expect(promise).rejects.toMatchObject({ name: "AbortError" }); expect(fetch).toHaveBeenCalledTimes(1);
});
it("keeps the deadline active while the response body is stalled", async () => {
  vi.useFakeTimers();
  vi.stubGlobal("fetch", vi.fn((_path, init) => Promise.resolve({ ok: true, status: 200, text: () => new Promise((_resolve, reject) => init.signal.addEventListener("abort", () => reject(new DOMException("timeout", "AbortError")))) })));
  const request = fetchMmsJson("/api/mms/app/support", { method: "POST" });
  const assertion = expect(request).rejects.toMatchObject({ kind: "timeout" });
  await vi.advanceTimersByTimeAsync(MMS_API_TIMEOUT_MS); await assertion;
});
it("never treats a missing booking field as an explicit empty result", async () => {
  vi.stubGlobal("fetch", vi.fn(async () => Response.json({ ok: true })));
  await expect(createLiveProvider().getCurrentBooking()).rejects.toMatchObject({ kind: "malformed" });
});
it("does not automatically replay a write after a server failure", async () => {
  const fetch = vi.fn(async () => Response.json({ ok: false }, { status: 503 })); vi.stubGlobal("fetch", fetch);
  await expect(fetchMmsJson("/api/mms/app/support", { method: "POST", body: "{}" })).rejects.toMatchObject({ status: 503 });
  expect(fetch).toHaveBeenCalledTimes(1);
});
