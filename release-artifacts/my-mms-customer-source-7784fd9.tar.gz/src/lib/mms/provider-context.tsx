import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createContext, useContext, useMemo, useState, useEffect, Fragment, type ReactNode } from "react";

import { shouldUseLiveProvider } from "./config";
import { createLiveProvider } from "./live-provider";
import { createMockProvider, readScenario, type MockScenario } from "./mock-provider";
import { t } from "./i18n";
import type { LanguageCode, MmsDataProvider, SearchCriteria } from "./types";

interface MmsContextValue {
  provider: MmsDataProvider;
  isMock: boolean;
  scenario: MockScenario;
  lang: LanguageCode;
  setLang: (lang: LanguageCode) => void;
  tr: (key: string) => string;
}

const MmsContext = createContext<MmsContextValue | null>(null);

export function MmsProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient();
  const [sessionEpoch, setSessionEpoch] = useState(0);
  useEffect(() => {
    let leftPage = false;
    const reset = () => {
      void qc.cancelQueries({ queryKey: ["mms"] });
      qc.removeQueries({ queryKey: ["mms"] });
      setSessionEpoch(value => value + 1);
    };
    const visibility = () => {
      if (document.hidden) leftPage = true;
      else if (leftPage) { leftPage = false; reset(); }
    };
    const restored = (event: PageTransitionEvent) => { if (event.persisted) reset(); };
    window.addEventListener("mms:account-switch", reset);
    document.addEventListener("visibilitychange", visibility);
    window.addEventListener("pageshow", restored);
    return () => { window.removeEventListener("mms:account-switch", reset); document.removeEventListener("visibilitychange", visibility); window.removeEventListener("pageshow", restored); };
  }, [qc]);
  const [lang, setLang] = useState<LanguageCode>("th");
  const scenario = useMemo(() => readScenario(), []);
  const value = useMemo<MmsContextValue>(() => {
    const live = shouldUseLiveProvider();
    return {
      provider: live ? createLiveProvider() : createMockProvider(scenario),
      isMock: !live,
      scenario,
      lang,
      setLang,
      tr: (key: string) => t(key, lang),
    };
  }, [lang, scenario]);

  return <MmsContext.Provider value={value}><Fragment key={sessionEpoch}>{children}</Fragment></MmsContext.Provider>;
}

export function useMms(): MmsContextValue {
  const ctx = useContext(MmsContext);
  if (!ctx) throw new Error("useMms must be used inside <MmsProvider>");
  return ctx;
}

const baseQuery = {
  staleTime: 30_000,
  retry: 0,
  refetchOnWindowFocus: false,
} as const;

export function useCustomer() {
  const { provider } = useMms();
  return useQuery({ queryKey: ["mms", "customer"], queryFn: ({ signal }) => provider.getCustomer(signal), ...baseQuery });
}

export function useProfile() {
  const { provider } = useMms();
  return useQuery({ queryKey: ["mms", "profile"], queryFn: ({ signal }) => provider.getProfile(signal), ...baseQuery });
}

export function useCurrentBooking() {
  const { provider } = useMms();
  return useQuery({
    queryKey: ["mms", "booking", "current"],
    queryFn: ({ signal }) => provider.getCurrentBooking(signal),
    ...baseQuery,
  });
}

export function useBookings() {
  const { provider } = useMms();
  return useQuery({ queryKey: ["mms", "bookings"], queryFn: ({ signal }) => provider.getBookings(signal), ...baseQuery });
}

export function useBooking(id: string | null) {
  const { provider } = useMms();
  return useQuery({
    queryKey: ["mms", "booking", id],
    queryFn: ({ signal }) => provider.getBooking(id as string, signal),
    enabled: Boolean(id),
    ...baseQuery,
  });
}

export function useTherapists() {
  const { provider } = useMms();
  return useQuery({
    queryKey: ["mms", "therapists"],
    queryFn: ({ signal }) => provider.getTherapists(signal),
    ...baseQuery,
  });
}

export function usePayments() {
  const { provider } = useMms();
  return useQuery({ queryKey: ["mms", "payments"], queryFn: ({ signal }) => provider.getPayments(signal), ...baseQuery });
}

export function useToggleFavorite() {
  const { provider } = useMms();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, next }: { id: string; next: boolean }) => provider.toggleFavorite(id, next),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["mms", "therapists"] }),
  });
}

export function useSubmitAfterService() {
  const { provider } = useMms();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: provider.submitAfterService,
    onSuccess: () => qc.invalidateQueries({ queryKey: ["mms"] }),
  });
}

export function useSubmitSupport() {
  const { provider } = useMms();
  return useMutation({ mutationFn: provider.submitSupport });
}

export function useSearchCatalog() {
  const { provider } = useMms();
  return useQuery({ queryKey: ["mms", "search", "catalog"], queryFn: ({ signal }) => provider.getSearchCatalog(signal), ...baseQuery });
}

export function useTherapistSearch(criteria: SearchCriteria | null) {
  const { provider } = useMms();
  return useQuery({ queryKey: ["mms", "search", "results", criteria], queryFn: ({ signal }) => {
    if (!criteria) throw new Error("MMS_SEARCH_CRITERIA_REQUIRED");
    return provider.searchTherapists(criteria, signal);
  }, ...baseQuery, staleTime: 0, gcTime: 0, enabled: criteria !== null });
}
