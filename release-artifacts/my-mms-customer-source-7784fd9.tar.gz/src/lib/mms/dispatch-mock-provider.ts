import type {
  JobActionResult,
  JobDetail,
  JobOffer,
  JobState,
  MmsDispatchProvider,
  TherapistContext,
} from "./dispatch-types";

/**
 * MOCK / DEV DISPATCH PROVIDER — visual preview only.
 *
 * These fixtures exist so the Incoming Job Offer experience can be designed
 * and reviewed. They are NEVER a production fallback and must never be shown
 * to a real therapist as job truth.
 *
 * Scenario switch: ?mms_job=offered | accepted | taken | expired | checking
 * Therapist mode in preview: ?mms_mode=therapist (or any ?mms_job= value)
 */

export type JobScenario = "offered" | "accepted" | "taken" | "expired" | "checking" | "off";

const SCENARIOS: JobScenario[] = ["offered", "accepted", "taken", "expired", "checking"];

export function readJobScenario(search?: string): JobScenario {
  if (typeof window === "undefined") return "off";
  const params = new URLSearchParams(search ?? window.location.search);
  const raw = params.get("mms_job");
  if (raw && (SCENARIOS as string[]).includes(raw)) return raw as JobScenario;
  if (params.get("mms_mode") === "therapist") return "offered";
  return "off";
}

const delay = (ms = 300) => new Promise((resolve) => setTimeout(resolve, ms));
const neverSettles = () => new Promise<never>(() => {});

const inMinutes = (m: number) => new Date(Date.now() + m * 60_000).toISOString();

const baseOffer: JobOffer = {
  jobId: "MMS-J-260909-04",
  refDisplay: "MMS-J-260909-04",
  state: "OFFERED",
  serviceLabel: "Aroma Oil Massage",
  durationLabel: "90 นาที",
  scheduledLabel: "วันนี้ · 19:30 น.",
  areaLabel: "ทองหล่อ (โซนสุขุมวิทตอนกลาง)",
  travelLabel: "ประมาณ 5.2 กม.",
  etaLabel: "เดินทางราว 18 นาที",
  payoutLabel: "1,500 บาท",
  payoutNote: "ยอดที่ Therapist ได้รับตามที่ระบบคำนวณไว้",
  expiresAt: inMinutes(2),
  noteLabel: "ลูกค้าขอผู้ให้บริการที่ถนัดออฟฟิศซินโดรม",
};

const acceptedDetail: JobDetail = {
  ...baseOffer,
  jobId: "MMS-J-260908-11",
  refDisplay: "MMS-J-260908-11",
  state: "ACCEPTED",
  serviceLabel: "Thai Massage",
  durationLabel: "60 นาที",
  scheduledLabel: "พรุ่งนี้ · 14:00 น.",
  areaLabel: "สาทร",
  travelLabel: "ประมาณ 3.4 กม.",
  etaLabel: "เดินทางราว 12 นาที",
  payoutLabel: "1,000 บาท",
  expiresAt: null,
  noteLabel: null,
  disclosure: {
    locationUnlocked: true,
    addressLabel: "โรงแรมย่านสาทร · อาคาร B ชั้น 12 (แจ้งชื่อที่ล็อบบี้)",
    mapUrl: "https://maps.google.com/?q=13.7200,100.5300",
    customerDisplayLabel: "คุณต้น",
    contactLabel: "ติดต่อผ่านทีมงาน MMS",
    contactUrl: null,
  },
  payoutSummaryLabel: "รับเงินสดส่วนที่เหลือหน้างาน · มัดจำผ่านระบบแล้ว",
  paymentStateLabel: "ตรวจสอบมัดจำแล้ว",
  timeline: [
    { label: "ระบบจับคู่งาน", atLabel: "8 ก.ย. · 09:12 น.", note: null, state: "done" },
    { label: "Therapist รับงาน", atLabel: "8 ก.ย. · 09:20 น.", note: null, state: "done" },
    { label: "เตรียมเดินทาง", atLabel: null, note: "ออกก่อนเวลาอย่างน้อย 30 นาที", state: "current" },
    { label: "เริ่มให้บริการ", atLabel: null, note: null, state: "upcoming" },
    { label: "จบงาน", atLabel: null, note: null, state: "upcoming" },
  ],
  supportUrl: null,
};

const completedDetail: JobDetail = {
  ...acceptedDetail,
  jobId: "MMS-J-260812-02",
  refDisplay: "MMS-J-260812-02",
  state: "COMPLETED",
  serviceLabel: "Aroma Oil Massage",
  scheduledLabel: "12 ส.ค. 2026 · 20:00 น.",
  areaLabel: "ทองหล่อ",
  payoutLabel: "1,500 บาท",
  payoutSummaryLabel: "โอนยอด Therapist เรียบร้อยแล้ว",
  paymentStateLabel: "ชำระครบแล้ว",
  disclosure: { ...acceptedDetail.disclosure, addressLabel: null, mapUrl: null },
  timeline: acceptedDetail.timeline.map((x) => ({ ...x, state: "done" as const })),
};

const context: TherapistContext = {
  audience: "therapist",
  therapistPublicName: "Ohm",
  therapistRefDisplay: "MMS-T-118",
  availabilityLabel: "พร้อมรับงาน",
  incomingOfferCount: 1,
};

function offerForScenario(scenario: JobScenario): JobOffer {
  const state: JobState =
    scenario === "taken" ? "TAKEN" : scenario === "expired" ? "EXPIRED" : "OFFERED";
  return {
    ...baseOffer,
    state,
    expiresAt: scenario === "expired" ? inMinutes(-1) : baseOffer.expiresAt,
  };
}

function detailFrom(offer: JobOffer): JobDetail {
  return {
    ...offer,
    disclosure: {
      locationUnlocked: false,
      addressLabel: null,
      mapUrl: null,
      customerDisplayLabel: null,
      contactLabel: null,
      contactUrl: null,
    },
    payoutSummaryLabel: null,
    paymentStateLabel: null,
    timeline: [],
    supportUrl: null,
  };
}

export function createMockDispatchProvider(scenario: JobScenario): MmsDispatchProvider {
  let acceptedJobId: string | null = scenario === "accepted" ? acceptedDetail.jobId : null;

  const guard = async () => {
    if (scenario === "checking") await neverSettles();
    await delay();
  };

  const jobs = (): JobDetail[] => {
    const list: JobDetail[] = [completedDetail];
    if (acceptedJobId) list.unshift(acceptedDetail);
    return list;
  };

  return {
    kind: "mock",
    async getTherapistContext() {
      if (scenario === "checking") await neverSettles();
      await delay(160);
      return {
        ...context,
        incomingOfferCount: scenario === "offered" ? 1 : 0,
      };
    },
    async getIncomingJobOffers() {
      await guard();
      return scenario === "offered" ? [offerForScenario(scenario)] : [];
    },
    async getJobOffer(jobId) {
      await guard();
      if (acceptedJobId === jobId) return { ...acceptedDetail };
      return { ...offerForScenario(scenario), jobId, refDisplay: jobId };
    },
    async acceptJob(jobId): Promise<JobActionResult> {
      await delay(700);
      if (scenario === "taken")
        return { jobId, state: "TAKEN", message: "งานนี้มี Therapist รับแล้ว" };
      if (scenario === "expired")
        return { jobId, state: "EXPIRED", message: "งานนี้หมดเวลาตอบรับแล้ว" };
      acceptedJobId = jobId;
      return { jobId, state: "ACCEPTED", message: "รับงานเรียบร้อยแล้ว (เดโม)" };
    },
    async declineJob(jobId): Promise<JobActionResult> {
      await delay(400);
      return { jobId, state: "DECLINED", message: "ปฏิเสธงานแล้ว (เดโม)" };
    },
    async startJob(jobId): Promise<JobActionResult> {
      await delay(500);
      return { jobId, state: "IN_PROGRESS", message: "เริ่มให้บริการแล้ว (เดโม)" };
    },
    async completeJob(jobId): Promise<JobActionResult> {
      await delay(500);
      return { jobId, state: "COMPLETED", message: "จบงานแล้ว (เดโม)" };
    },
    async getJobDetail(jobId) {
      await guard();
      if (jobId === completedDetail.jobId) return completedDetail;
      if (acceptedJobId === jobId) return { ...acceptedDetail, jobId, refDisplay: jobId };
      return detailFrom({ ...offerForScenario(scenario), jobId, refDisplay: jobId });
    },
    async getJobs() {
      await guard();
      return jobs();
    },
  };
}
