import { MMS_ENDPOINTS } from "./config";
import { MmsApiError, errorCodeFromBody, fetchMmsJson, isRecord } from "./mms-fetch";
import type {
  AfterServicePayload,
  BookingDetail,
  BookingSummary,
  CustomerSummary,
  MmsDataProvider,
  PaymentSummary,
  ProfileSummary,
  SubmitResult,
  SupportPayload,
  TherapistLists,
  SearchCatalog, SearchCriteria, SearchResults,
} from "./types";

/**
 * LIVE PROVIDER — same-origin only, credentials: "same-origin".
 *
 * Customer identity, bookings and therapist discovery use the same-origin
 * Worker contracts. Features whose backend remains unavailable keep their
 * Checking / Error state; this provider never invents successful results.
 */

async function get<T>(path: string, shape: (raw: unknown) => T, signal?: AbortSignal): Promise<T> {
  const { status, body } = await fetchMmsJson(path, { method: "GET", ...(signal ? { signal } : {}) });
  if (isRecord(body) && body["ok"] === false) {
    throw new MmsApiError(status, errorCodeFromBody(body) ?? "NOT_OK");
  }
  return shape(isRecord(body) && "data" in body ? body["data"] : body);
}

async function post(path: string, payload: unknown): Promise<SubmitResult> {
  const { status, body } = await fetchMmsJson(path, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (isRecord(body) && body["ok"] === false) {
    throw new MmsApiError(status, errorCodeFromBody(body) ?? "NOT_OK");
  }
  const message = isRecord(body) && typeof body["message"] === "string" ? body["message"] : null;
  return { accepted: true, message };
}

/** Fail-closed shaping: an unexpected body becomes a typed malformed error. */
function expectObject<T>(raw: unknown): T {
  if (!isRecord(raw)) throw new MmsApiError(200, "MALFORMED", "malformed");
  return raw as T;
}

function expectArray<T>(raw: unknown): T[] {
  if (!Array.isArray(raw)) throw new MmsApiError(200, "MALFORMED", "malformed");
  return raw as T[];
}

function expectBooking(raw: unknown): BookingSummary {
  if (!isRecord(raw) || typeof raw["id"] !== "string" || !raw["id"] || typeof raw["serviceLabel"] !== "string" || !["pending", "confirmed", "in_progress", "completed", "cancelled", "checking"].includes(String(raw["status"]))) throw new MmsApiError(200, "MALFORMED", "malformed");
  return expectObject<BookingSummary>(raw);
}

const statuses = ["Available", "Unavailable", "Paused"];
const option = (raw: unknown) => isRecord(raw) && typeof raw["code"] === "string" && Boolean(raw["code"]) && typeof raw["label"] === "string" && Boolean(raw["label"]);
const strings = (raw: unknown) => Array.isArray(raw) && raw.every(item => typeof item === "string");
function isSearchCatalog(raw: unknown): raw is SearchCatalog {
  return isRecord(raw) && Array.isArray(raw["services"]) && raw["services"].length > 0 && raw["services"].every(option)
    && Array.isArray(raw["zones"]) && raw["zones"].length > 0 && raw["zones"].every(item => option(item) && isRecord(item) && typeof item["province"] === "string")
    && Array.isArray(raw["availability"]) && raw["availability"].length > 0 && raw["availability"].every(item => option(item) && isRecord(item) && statuses.includes(String(item["code"])));
}
function expectCatalog(raw: unknown): SearchCatalog {
  if (!isSearchCatalog(raw)) throw new MmsApiError(200, "MALFORMED", "malformed");
  return raw;
}
function isSearchResults(raw: unknown, criteria: SearchCriteria): raw is SearchResults {
  if (!isRecord(raw) || !isRecord(raw["criteria"])) return false;
  const echoed = raw["criteria"];
  return Object.entries(criteria).every(([key, value]) => echoed[key] === value)
    && typeof raw["checkedAt"] === "string" && Number.isFinite(Date.parse(raw["checkedAt"]))
    && Array.isArray(raw["results"]) && raw["results"].every(item => isRecord(item)
      && typeof item["id"] === "string" && Boolean(item["id"])
      && typeof item["publicName"] === "string" && Boolean(item["publicName"])
      && strings(item["serviceTags"]) && Array.isArray(item["serviceTags"]) && item["serviceTags"].length > 0 && strings(item["areaTags"]) && Array.isArray(item["areaTags"]) && item["areaTags"].length > 0
      && item["availability"] === criteria.availability && item["canReceiveWork"] === (item["availability"] === "Available"))
    && new Set(raw["results"].map(item => item.id)).size === raw["results"].length;
}
function expectSearch(raw: unknown, criteria: SearchCriteria): SearchResults {
  if (!isSearchResults(raw, criteria)) throw new MmsApiError(200, "MALFORMED", "malformed");
  return raw;
}

export function createLiveProvider(): MmsDataProvider {
  return {
    kind: "live",
    getCustomer: (signal) => get(MMS_ENDPOINTS.customer, expectObject<CustomerSummary>, signal),
    getProfile: (signal) => get(MMS_ENDPOINTS.customer, expectObject<ProfileSummary>, signal),
    getCurrentBooking: (signal) =>
      get(MMS_ENDPOINTS.currentBooking, (raw) =>
        raw === null ? null : expectBooking(raw), signal,
      ),
    getBookings: (signal) => get(MMS_ENDPOINTS.bookings, expectArray<BookingSummary>, signal),
    getBooking: (id, signal) => get(MMS_ENDPOINTS.booking(id), expectObject<BookingDetail>, signal),
    getSearchCatalog: signal => get(`${MMS_ENDPOINTS.therapists}/search/catalog`, expectCatalog, signal),
    searchTherapists: (criteria, signal) => get(`${MMS_ENDPOINTS.therapists}/search?${new URLSearchParams({ ...criteria })}`, raw => expectSearch(raw, criteria), signal),
    getTherapists: (signal) => get(MMS_ENDPOINTS.therapists, expectObject<TherapistLists>, signal),
    getPayments: (signal) => get(MMS_ENDPOINTS.payments, expectArray<PaymentSummary>, signal),
    toggleFavorite: (therapistId, next) =>
      post(MMS_ENDPOINTS.favorite(therapistId), { favorite: next }),
    submitAfterService: (payload: AfterServicePayload) => post(MMS_ENDPOINTS.afterService, payload),
    submitSupport: (payload: SupportPayload) => post(MMS_ENDPOINTS.support, payload),
  };
}
