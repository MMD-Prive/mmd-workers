import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import { MMS_JOB_POLL_MS, shouldUseLiveProvider } from "./config";
import { createLiveDispatchProvider } from "./dispatch-live-provider";
import { createMockDispatchProvider, readJobScenario, type JobScenario } from "./dispatch-mock-provider";
import type { JobActionResult, MmsDispatchProvider } from "./dispatch-types";

/**
 * Therapist dispatch layer.
 *
 * The browser NEVER decides that the current session is a therapist. The
 * presentation layer only opens when the backend context says
 * audience === "therapist", or when a canonical job offer loads from the
 * adapter for a deep link. Anything else fails closed to Checking.
 */

interface DispatchContextValue {
  provider: MmsDispatchProvider;
  isMock: boolean;
  scenario: JobScenario;
  /** jobId of the offer currently presented full-screen, if any. */
  activeOfferId: string | null;
  openOffer: (jobId: string) => void;
  closeOffer: () => void;
}

const DispatchContext = createContext<DispatchContextValue | null>(null);

export function MmsDispatchProviderRoot({ children }: { children: ReactNode }) {
  const [activeOfferId, setActiveOfferId] = useState<string | null>(null);
  const scenario = useMemo(() => readJobScenario(), []);

  const value = useMemo<DispatchContextValue>(() => {
    const live = shouldUseLiveProvider();
    return {
      provider: live ? createLiveDispatchProvider() : createMockDispatchProvider(scenario),
      isMock: !live,
      scenario,
      activeOfferId,
      openOffer: (jobId: string) => setActiveOfferId(jobId),
      closeOffer: () => setActiveOfferId(null),
    };
  }, [activeOfferId, scenario]);

  return <DispatchContext.Provider value={value}>{children}</DispatchContext.Provider>;
}

export function useDispatch(): DispatchContextValue {
  const ctx = useContext(DispatchContext);
  if (!ctx) throw new Error("useDispatch must be used inside <MmsDispatchProviderRoot>");
  return ctx;
}

const baseQuery = { staleTime: 10_000, retry: 0, refetchOnWindowFocus: true } as const;

/** Backend-declared audience. In mock preview this is off unless requested. */
export function useTherapistContext() {
  const { provider, isMock, scenario } = useDispatch();
  return useQuery({
    queryKey: ["mms", "dispatch", "context", scenario],
    queryFn: () => provider.getTherapistContext(),
    enabled: !isMock || scenario !== "off",
    ...baseQuery,
  });
}

export function useIsTherapistMode(): { confirmed: boolean; checking: boolean } {
  const { isMock, scenario } = useDispatch();
  const { data, isPending, isError } = useTherapistContext();
  if (isMock && scenario === "off") return { confirmed: false, checking: false };
  if (isError) return { confirmed: false, checking: false };
  if (isPending) return { confirmed: false, checking: true };
  return { confirmed: data?.audience === "therapist", checking: data?.audience === "checking" };
}

export function useIncomingOffers() {
  const { provider, isMock, scenario } = useDispatch();
  return useQuery({
    queryKey: ["mms", "dispatch", "offers"],
    queryFn: () => provider.getIncomingJobOffers(),
    enabled: !isMock || scenario !== "off",
    refetchInterval: MMS_JOB_POLL_MS,
    ...baseQuery,
  });
}

export function useJobOffer(jobId: string | null) {
  const { provider } = useDispatch();
  return useQuery({
    queryKey: ["mms", "dispatch", "offer", jobId],
    queryFn: () => provider.getJobOffer(jobId as string),
    enabled: Boolean(jobId),
    refetchInterval: MMS_JOB_POLL_MS,
    ...baseQuery,
  });
}

export function useJobDetail(jobId: string | null) {
  const { provider } = useDispatch();
  return useQuery({
    queryKey: ["mms", "dispatch", "job", jobId],
    queryFn: () => provider.getJobDetail(jobId as string),
    enabled: Boolean(jobId),
    ...baseQuery,
  });
}

export function useJobs() {
  const { provider, isMock, scenario } = useDispatch();
  return useQuery({
    queryKey: ["mms", "dispatch", "jobs"],
    queryFn: () => provider.getJobs(),
    enabled: !isMock || scenario !== "off",
    ...baseQuery,
  });
}

/** Accept / decline go to the backend only. No local state is authoritative. */
export function useJobAction(jobId: string | null) {
  const { provider } = useDispatch();
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["mms", "dispatch"] });

  const accept = useMutation<JobActionResult, unknown, { requestKey: string }>({
    mutationFn: ({ requestKey }) => provider.acceptJob(jobId as string, requestKey),
    onSettled: invalidate,
  });

  const decline = useMutation<JobActionResult, unknown, { reason?: string }>({
    mutationFn: ({ reason }) => provider.declineJob(jobId as string, reason),
    onSettled: invalidate,
  });

  return { accept, decline };
}

/**
 * Service lifecycle writes (start / complete). The backend owns the state:
 * the UI shows a pending CTA, POSTs, then refetches the canonical job.
 */
export function useJobLifecycle(jobId: string | null) {
  const { provider } = useDispatch();
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["mms", "dispatch"] });

  const start = useMutation<JobActionResult, unknown, void>({
    mutationFn: () => provider.startJob(jobId as string, `${jobId}:start:${Date.now()}`),
    onSettled: invalidate,
  });

  const complete = useMutation<JobActionResult, unknown, void>({
    mutationFn: () => provider.completeJob(jobId as string, `${jobId}:complete:${Date.now()}`),
    onSettled: invalidate,
  });

  return { start, complete };
}

/**
 * Documented refresh strategy (no invented websocket endpoint):
 * re-read canonical job state on route load, on visibility/focus return, and
 * after every write. A bounded poll runs while an offer is on screen.
 */
export function useRefreshJobsOnFocus() {
  const qc = useQueryClient();
  const { provider } = useDispatch();

  const refresh = useCallback(() => {
    qc.invalidateQueries({ queryKey: ["mms", "dispatch"] });
  }, [qc]);

  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === "visible") refresh();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", refresh);
    const unsubscribe = provider.subscribeToJobUpdates?.(refresh);
    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", refresh);
      unsubscribe?.();
    };
  }, [provider, refresh]);

  return refresh;
}
