import type {
  AfterServicePayload,
  BookingDetail,
  BookingSummary,
  CustomerSummary,
  MmsDataProvider,
  PaymentSummary,
  ProfileSummary,
  SubmitResult,
  SupportPayload,
  TherapistLists,
  TherapistPublicSummary,
} from "./types";

/**
 * MOCK / DEV PROVIDER — visual preview only.
 *
 * Everything here is demo data for design review. It is NOT production truth
 * and must never be presented to a customer as a real booking or payment.
 * Scenario switch: ?mms_demo=upcoming | deposit | empty | checking | error
 */

export type MockScenario = "upcoming" | "deposit" | "empty" | "checking" | "error";

export function readScenario(search?: string): MockScenario {
  const raw =
    typeof window !== "undefined"
      ? new URLSearchParams(search ?? window.location.search).get("mms_demo")
      : null;
  const allowed: MockScenario[] = ["upcoming", "deposit", "empty", "checking", "error"];
  return (allowed as string[]).includes(raw ?? "") ? (raw as MockScenario) : "upcoming";
}

const delay = (ms = 320) => new Promise((resolve) => setTimeout(resolve, ms));

const therapists: TherapistPublicSummary[] = [
  {
    id: "thr_ohm",
    publicName: "Ohm",
    photoUrl: null,
    headline: "Aroma Oil · Office Syndrome",
    serviceTags: ["Aroma Oil", "Office Syndrome"],
    areaTags: ["สุขุมวิท", "ทองหล่อ"],
    lastUsedLabel: "ใช้บริการล่าสุด 12 ส.ค. 2026",
    timesBooked: 4,
    isFavorite: true,
  },
  {
    id: "thr_beam",
    publicName: "Beam",
    photoUrl: null,
    headline: "Thai · Sport",
    serviceTags: ["Thai", "Sport"],
    areaTags: ["สาทร", "พระราม 3"],
    lastUsedLabel: "ใช้บริการล่าสุด 2 ก.ค. 2026",
    timesBooked: 2,
    isFavorite: false,
  },
  {
    id: "thr_win",
    publicName: "Win",
    photoUrl: null,
    headline: "Herbal Compress · Health Advisor",
    serviceTags: ["Herbal Compress", "Health/Fitness Advisor"],
    areaTags: ["อารีย์"],
    lastUsedLabel: "ใช้บริการล่าสุด 18 พ.ค. 2026",
    timesBooked: 1,
    isFavorite: true,
  },
];

const upcoming: BookingSummary = {
  id: "bkg_20260910",
  refDisplay: "MMS-260910-04",
  serviceLabel: "Aroma Oil Massage · 90 นาที",
  scheduledLabel: "พฤ. 10 ก.ย. 2026 · 19:30 น.",
  durationLabel: "90 นาที",
  areaLabel: "ทองหล่อ · คอนโดของลูกค้า",
  therapist: therapists[0]!,
  status: "confirmed",
  paymentState: "deposit_verified",
  amountSummary: "รวม 2,400 บาท · มัดจำตรวจสอบแล้ว",
  nextAction: { kind: "view_booking", label: "ดูรายละเอียดการจอง", url: null },
  needsAttention: false,
};

const awaitingDeposit: BookingSummary = {
  ...upcoming,
  id: "bkg_20260908",
  refDisplay: "MMS-260908-11",
  serviceLabel: "Thai Massage · 60 นาที",
  scheduledLabel: "อ. 8 ก.ย. 2026 · 14:00 น.",
  durationLabel: "60 นาที",
  areaLabel: "สาทร · โรงแรม",
  therapist: therapists[1]!,
  status: "pending",
  paymentState: "deposit_submitted",
  amountSummary: "รวม 1,600 บาท · รอตรวจสอบสลิปมัดจำ",
  nextAction: { kind: "upload_proof", label: "ดูสถานะการชำระเงิน", url: null },
  needsAttention: true,
};

const history: BookingSummary[] = [
  {
    id: "bkg_20260812",
    refDisplay: "MMS-260812-02",
    serviceLabel: "Aroma Oil Massage · 90 นาที",
    scheduledLabel: "พ. 12 ส.ค. 2026 · 20:00 น.",
    durationLabel: "90 นาที",
    areaLabel: "ทองหล่อ",
    therapist: therapists[0]!,
    status: "completed",
    paymentState: "completed",
    amountSummary: "รวม 2,400 บาท · ชำระครบแล้ว",
    nextAction: { kind: "rate_service", label: "ให้คะแนนการใช้บริการ", url: null },
    needsAttention: false,
  },
  {
    id: "bkg_20260702",
    refDisplay: "MMS-260702-07",
    serviceLabel: "Sport Massage · 60 นาที",
    scheduledLabel: "พฤ. 2 ก.ค. 2026 · 11:00 น.",
    durationLabel: "60 นาที",
    areaLabel: "สาทร",
    therapist: therapists[1]!,
    status: "cancelled",
    paymentState: "unavailable",
    amountSummary: null,
    nextAction: null,
    needsAttention: false,
  },
  {
    id: "bkg_20260518",
    refDisplay: "MMS-260518-05",
    serviceLabel: "Herbal Compress · 90 นาที",
    scheduledLabel: "จ. 18 พ.ค. 2026 · 18:00 น.",
    durationLabel: "90 นาที",
    areaLabel: "อารีย์",
    therapist: therapists[2]!,
    status: "completed",
    paymentState: "completed",
    amountSummary: "รวม 2,200 บาท · ชำระครบแล้ว",
    nextAction: null,
    needsAttention: false,
  },
];

const payments: PaymentSummary[] = [
  {
    bookingId: awaitingDeposit.id,
    bookingRefDisplay: awaitingDeposit.refDisplay,
    serviceLabel: awaitingDeposit.serviceLabel,
    scheduledLabel: awaitingDeposit.scheduledLabel,
    policyLabel: "มัดจำ 50% · ส่วนที่เหลือ 50% เมื่อรับบริการ",
    totalLabel: "1,600 บาท",
    depositLabel: "800 บาท",
    balanceLabel: "800 บาท",
    state: "deposit_submitted",
    instructionsLabel: "ทีมงานกำลังตรวจสอบสลิป โดยปกติใช้เวลาไม่เกิน 15 นาที",
    proofUrl: null,
    receiptUrl: null,
    updatedLabel: "อัปเดต 8 ก.ย. 2026 · 13:12 น.",
  },
  {
    bookingId: upcoming.id,
    bookingRefDisplay: upcoming.refDisplay,
    serviceLabel: upcoming.serviceLabel,
    scheduledLabel: upcoming.scheduledLabel,
    policyLabel: "มัดจำ 50% · ส่วนที่เหลือ 50% เมื่อรับบริการ",
    totalLabel: "2,400 บาท",
    depositLabel: "1,200 บาท",
    balanceLabel: "1,200 บาท",
    state: "deposit_verified",
    instructionsLabel: "ชำระส่วนที่เหลือกับ Therapist เมื่อรับบริการ",
    proofUrl: null,
    receiptUrl: null,
    updatedLabel: "อัปเดต 6 ก.ย. 2026 · 09:40 น.",
  },
];

const customer: CustomerSummary = {
  displayName: "คุณต้น",
  lineDisplayName: "Ton",
  lineAccountSummary: "LINE · Ton (เชื่อมกับ @malemassage)",
  avatarUrl: null,
  identityState: "verified",
  customerRefDisplay: "MMS-C-2081",
  language: "th",
};

const profile: ProfileSummary = {
  ...customer,
  email: { value: "t•••@gmail.com", verified: true, safeToDisplay: true },
  phone: { value: "08x-xxx-4471", verified: true, safeToDisplay: true },
  preferredAreas: ["ทองหล่อ", "สุขุมวิท", "สาทร"],
  preferredServices: ["Aroma Oil", "Office Syndrome"],
  memberSinceLabel: "ใช้บริการกับ Male Massage ตั้งแต่ พ.ค. 2026",
};

const neverSettles = () => new Promise<never>(() => {});

function fail(): never {
  throw new Error("mms_mock_error_scenario");
}

export function createMockProvider(scenario: MockScenario = "upcoming"): MmsDataProvider {
  const favorites = new Set(therapists.filter((x) => x.isFavorite).map((x) => x.id));

  const guard = async () => {
    if (scenario === "checking") await neverSettles();
    if (scenario === "error") fail();
    await delay();
  };

  const withFavorites = (list: TherapistPublicSummary[]) =>
    list.map((x) => ({ ...x, isFavorite: favorites.has(x.id) }));

  const current = scenario === "deposit" ? awaitingDeposit : upcoming;

  return {
    kind: "mock",
    async getCustomer() {
      await guard();
      return scenario === "empty" ? { ...customer, displayName: "คุณลูกค้า" } : customer;
    },
    async getProfile() {
      await guard();
      return profile;
    },
    async getCurrentBooking() {
      await guard();
      return scenario === "empty" ? null : current;
    },
    async getBookings() {
      await guard();
      if (scenario === "empty") return [];
      return [current, ...history];
    },
    async getBooking(id) {
      await guard();
      const base = [current, ...history].find((b) => b.id === id) ?? current;
      const detail: BookingDetail = {
        ...base,
        payment: payments.find((p) => p.bookingId === base.id) ?? null,
        operatorNote: "ทีมงานจะยืนยันเวลาอีกครั้งก่อนถึงนัดหมาย 2 ชั่วโมง",
        timeline: [
          { label: "รับคำขอจอง", atLabel: "6 ก.ย. 2026 · 09:12 น.", note: null, state: "done" },
          {
            label: "ตรวจสอบการชำระมัดจำ",
            atLabel: "6 ก.ย. 2026 · 09:40 น.",
            note: base.paymentState === "deposit_submitted" ? "กำลังตรวจสอบสลิป" : null,
            state: base.paymentState === "deposit_submitted" ? "current" : "done",
          },
          {
            label: "ยืนยัน Therapist",
            atLabel: base.status === "confirmed" ? "6 ก.ย. 2026 · 10:05 น." : null,
            note: null,
            state: base.status === "confirmed" ? "done" : "upcoming",
          },
          { label: "วันให้บริการ", atLabel: base.scheduledLabel, note: null, state: "upcoming" },
          { label: "หลังใช้บริการ", atLabel: null, note: null, state: "upcoming" },
        ],
      };
      return detail;
    },
    async getSearchCatalog() { throw new Error("MMS_SEARCH_LIVE_ONLY"); },
    async searchTherapists() { throw new Error("MMS_SEARCH_LIVE_ONLY"); },
    async getTherapists() {
      await guard();
      if (scenario === "empty") return { recent: [], favorites: [] };
      const lists: TherapistLists = {
        recent: withFavorites(therapists),
        favorites: withFavorites(therapists).filter((x) => x.isFavorite),
      };
      return lists;
    },
    async getPayments() {
      await guard();
      return scenario === "empty" ? [] : payments;
    },
    async toggleFavorite(therapistId, next): Promise<SubmitResult> {
      await delay(180);
      if (next) favorites.add(therapistId);
      else favorites.delete(therapistId);
      return { accepted: true, message: "บันทึกรายการโปรดแล้ว (เดโม)" };
    },
    async submitAfterService(_payload: AfterServicePayload): Promise<SubmitResult> {
      await delay(400);
      return { accepted: true, message: "ส่งความคิดเห็นเรียบร้อยแล้ว (เดโม)" };
    },
    async submitSupport(_payload: SupportPayload): Promise<SubmitResult> {
      await delay(400);
      return { accepted: true, message: "ส่งเรื่องถึงทีมงานแล้ว (เดโม)" };
    },
  };
}
