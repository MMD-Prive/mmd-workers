import { describe, expect, it } from "vitest";

import {
  MMS_BOOKING_ROUTE,
  MMS_CUSTOMER_APP_BASEPATH,
  isMmsCustomerAppPath,
} from "./config";

describe("MY MMS production mount", () => {
  it("uses /male-massage as the canonical customer basepath", () => {
    expect(MMS_CUSTOMER_APP_BASEPATH).toBe("/male-massage");
  });

  it("recognizes only bounded customer app paths", () => {
    for (const path of [
      "/male-massage",
      "/male-massage/",
      "/male-massage/bookings",
      "/male-massage/bookings/mmspre_example",
      "/male-massage/therapists",
      "/male-massage/payment",
      "/male-massage/after-service",
      "/male-massage/profile",
      "/male-massage/support",
    ]) {
      expect(isMmsCustomerAppPath(path), path).toBe(true);
    }
  });

  it("keeps public and Therapist-private routes outside the customer router", () => {
    for (const path of [
      "/male-massage/home",
      "/male-massage/how-to-use",
      "/male-massage/member/mms-booking",
      "/male-massage/therapists/login",
      "/male-massage/therapists/me",
      "/male-massage/therapists/app",
      "/male-massage/therapists/relax-spa",
      "/male-massage/therapists/mms",
    ]) {
      expect(isMmsCustomerAppPath(path), path).toBe(false);
    }
  });

  it("uses the canonical published MMS pre-booking route", () => {
    expect(MMS_BOOKING_ROUTE).toBe("/male-massage/member/mms-booking");
  });
});
