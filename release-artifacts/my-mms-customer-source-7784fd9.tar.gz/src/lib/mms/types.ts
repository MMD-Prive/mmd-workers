/**
 * MY MMS — typed customer models.
 *
 * CANON
 * - Every state below is produced by the backend. The browser never infers
 *   booking status, payment verification, therapist availability or identity.
 * - Anything missing or unverified fails closed to "checking" / "unavailable".
 * - No MMD concepts here: no tier, points, coupons, entitlement, Kenji, SIGIL.
 */

export type LoadState = "loading" | "ready" | "empty" | "error";

/** Identity verification state, decided by the Worker only. */
export type IdentityState = "verified" | "checking" | "unverified" | "unavailable";

export type LanguageCode = "th" | "en" | "zh";

export interface SafeContactField {
  /** Already masked by the backend. Never mask client-side. */
  value: string | null;
  verified: boolean;
  /** Backend must explicitly mark a field safe to display. */
  safeToDisplay: boolean;
}

export interface CustomerSummary {
  displayName: string | null;
  lineDisplayName: string | null;
  lineAccountSummary: string | null;
  avatarUrl: string | null;
  identityState: IdentityState;
  /** Display-safe reference only. Never an internal customer id. */
  customerRefDisplay: string | null;
  language: LanguageCode | null;
}

export interface ProfileSummary extends CustomerSummary {
  email: SafeContactField;
  phone: SafeContactField;
  preferredAreas: string[];
  preferredServices: string[];
  memberSinceLabel: string | null;
}

export type BookingStatus =
  | "pending"
  | "confirmed"
  | "in_progress"
  | "completed"
  | "cancelled"
  | "checking";

export type PaymentState =
  | "deposit_required"
  | "deposit_submitted"
  | "deposit_verified"
  | "balance_due"
  | "completed"
  | "unavailable"
  | "checking";

export type BookingActionKind =
  | "pay_deposit"
  | "upload_proof"
  | "view_booking"
  | "rate_service"
  | "contact_support"
  | "none";

export interface BookingAction {
  kind: BookingActionKind;
  label: string | null;
  /** Backend-provided safe URL, or null when the action is in-app. */
  url: string | null;
}

export interface TherapistPublicSummary {
  id: string;
  /** Public working name only. Never real identity. */
  publicName: string;
  photoUrl: string | null;
  headline: string | null;
  serviceTags: string[];
  areaTags: string[];
  lastUsedLabel: string | null;
  timesBooked: number | null;
  isFavorite: boolean;
}

export interface BookingSummary {
  id: string;
  /** Display-safe booking reference from backend. */
  refDisplay: string | null;
  serviceLabel: string;
  scheduledLabel: string | null;
  durationLabel: string | null;
  areaLabel: string | null;
  therapist: TherapistPublicSummary | null;
  status: BookingStatus;
  paymentState: PaymentState;
  /** Pre-formatted by backend. Never computed here. */
  amountSummary: string | null;
  nextAction: BookingAction | null;
  /** Backend says this booking needs the customer to act now. */
  needsAttention: boolean;
}

export interface BookingTimelineEntry {
  label: string;
  atLabel: string | null;
  note: string | null;
  state: "done" | "current" | "upcoming";
}

export interface BookingDetail extends BookingSummary {
  timeline: BookingTimelineEntry[];
  payment: PaymentSummary | null;
  operatorNote: string | null;
}

export interface PaymentSummary {
  bookingId: string;
  bookingRefDisplay: string | null;
  serviceLabel: string | null;
  scheduledLabel: string | null;
  /** Backend-provided policy sentence, e.g. "มัดจำ 50% · ส่วนที่เหลือ 50%". */
  policyLabel: string | null;
  /** Pre-formatted strings from backend. No client arithmetic. */
  totalLabel: string | null;
  depositLabel: string | null;
  balanceLabel: string | null;
  state: PaymentState;
  instructionsLabel: string | null;
  /** Backend-safe URLs only. */
  proofUrl: string | null;
  receiptUrl: string | null;
  updatedLabel: string | null;
}

export interface TherapistLists {
  recent: TherapistPublicSummary[];
  favorites: TherapistPublicSummary[];
}

export type AfterServiceIssue = "service" | "payment" | "therapist" | "safety";

export interface AfterServicePayload {
  bookingId: string;
  rating: number | null;
  feedback: string | null;
  tipIntent: "none" | "direct" | "via_mms";
  issue: AfterServiceIssue | null;
  issueNote: string | null;
}

export interface SupportPayload {
  category: AfterServiceIssue;
  message: string;
  bookingRefDisplay: string | null;
}

/** Result of a write handed to the backend. The browser stores no authority. */
export interface SubmitResult {
  accepted: boolean;
  /** Backend-provided display-safe acknowledgement. */
  message: string | null;
}

export type WorkAvailability = "Available" | "Unavailable" | "Paused";
export interface SearchCriteria { service: string; zone: string; availability: WorkAvailability; recipient: string }
export interface SearchCatalog {
  services: { code: string; label: string }[];
  zones: { code: string; label: string; province: string }[];
  availability: { code: WorkAvailability; label: string }[];
}
export interface SearchTherapist {
  id: string; publicName: string; serviceTags: string[]; areaTags: string[];
  availability: WorkAvailability; canReceiveWork: boolean;
}
export interface SearchResults { results: SearchTherapist[]; criteria: SearchCriteria; checkedAt: string }

export interface MmsDataProvider {
  readonly kind: "mock" | "live";
  getCustomer(signal?: AbortSignal): Promise<CustomerSummary>;
  getProfile(signal?: AbortSignal): Promise<ProfileSummary>;
  /** null = backend explicitly says there is no upcoming booking. */
  getCurrentBooking(signal?: AbortSignal): Promise<BookingSummary | null>;
  getBookings(signal?: AbortSignal): Promise<BookingSummary[]>;
  getBooking(id: string, signal?: AbortSignal): Promise<BookingDetail>;
  getSearchCatalog(signal?: AbortSignal): Promise<SearchCatalog>;
  searchTherapists(criteria: SearchCriteria, signal?: AbortSignal): Promise<SearchResults>;
  getTherapists(signal?: AbortSignal): Promise<TherapistLists>;
  getPayments(signal?: AbortSignal): Promise<PaymentSummary[]>;
  toggleFavorite(therapistId: string, next: boolean): Promise<SubmitResult>;
  submitAfterService(payload: AfterServicePayload): Promise<SubmitResult>;
  submitSupport(payload: SupportPayload): Promise<SubmitResult>;
}
