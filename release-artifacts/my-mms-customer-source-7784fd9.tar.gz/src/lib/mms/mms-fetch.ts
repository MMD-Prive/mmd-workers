/**
 * Bounded same-origin fetch for the MY MMS customer workspace.
 *
 * - Same-origin only, credentials: "same-origin". No tokens in the browser.
 * - Hard client deadline so a hung upstream becomes a typed error instead of
 *   an endless "กำลังตรวจสอบ".
 * - Nothing here decides anything about the customer.
 */

export const MMS_API_TIMEOUT_MS = 10_000;
export const MMS_RETRY_DELAY_MS = 1_000;
export const MMS_MAX_RETRIES = 1;

export type MmsApiErrorKind = "http" | "timeout" | "network" | "malformed";

export class MmsApiError extends Error {
  readonly status: number;
  readonly code: string | null;
  readonly kind: MmsApiErrorKind;
  /** Raw parsed response body, when the server sent one. */
  readonly body: unknown;

  constructor(
    status: number,
    code: string | null,
    kind: MmsApiErrorKind = "http",
    body: unknown = null,
  ) {
    super(`mms_api_error_${status}${code ? `_${code}` : ""}`);
    this.name = "MmsApiError";
    this.status = status;
    this.code = code;
    this.kind = kind;
    this.body = body;
  }
}

export type MmsFailureKind =
  | "timeout"
  | "network"
  | "server"
  | "session"
  | "forbidden"
  | "unavailable"
  | "malformed"
  | "generic";

export function mmsFailureKind(error: unknown): MmsFailureKind {
  if (!(error instanceof MmsApiError)) return "generic";
  if (error.kind === "timeout") return "timeout";
  if (error.kind === "network") return "network";
  if (error.kind === "malformed") return "malformed";
  if (error.status === 401) return "session";
  if (error.status === 403) return "forbidden";
  if (error.status === 404) return "unavailable";
  if (error.status >= 500) return "server";
  return "generic";
}

export function isSessionRequiredError(error: unknown): boolean {
  return error instanceof MmsApiError && error.status === 401;
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function errorCodeFromBody(body: unknown): string | null {
  if (!isRecord(body)) return null;
  const error = body["error"];
  if (typeof error === "string") return error;
  if (isRecord(error) && typeof error["code"] === "string") return error["code"];
  if (typeof body["code"] === "string") return body["code"] as string;
  return null;
}

async function once(
  path: string,
  init: RequestInit,
): Promise<{ status: number; body: unknown }> {
  const controller = new AbortController();
  const abort = () => controller.abort();
  const external = init.signal;
  if (external?.aborted) controller.abort();
  else external?.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(abort, MMS_API_TIMEOUT_MS);
  try {
    const response = await fetch(path, { ...init, credentials: "same-origin", headers: { accept: "application/json", ...(init.headers ?? {}) }, signal: controller.signal });
    const text = await response.text();
    let body: unknown = null;
    if (text) {
      try { body = JSON.parse(text); }
      catch { if (response.ok) throw new MmsApiError(response.status, null, "malformed"); }
    }
    if (!response.ok) throw new MmsApiError(response.status, errorCodeFromBody(body), "http", body);
    return { status: response.status, body };
  } catch (error) {
    if (external?.aborted) throw new DOMException("Cancelled", "AbortError");
    if (error instanceof MmsApiError) throw error;
    throw new MmsApiError(0, null, controller.signal.aborted ? "timeout" : "network");
  } finally { clearTimeout(timer); external?.removeEventListener("abort", abort); }
}

const shouldRetry = (error: unknown) =>
  error instanceof MmsApiError &&
  (error.kind === "network" || error.kind === "timeout" || error.status >= 500);

export async function fetchMmsJson(
  path: string,
  init: RequestInit = {},
): Promise<{ status: number; body: unknown }> {
  let attempt = 0;
  for (;;) {
    try {
      return await once(path, init);
    } catch (error) {
      if (init.signal?.aborted || (init.method || "GET").toUpperCase() !== "GET" || attempt >= MMS_MAX_RETRIES || !shouldRetry(error)) throw error;
      attempt += 1;
      await new Promise((resolve) => setTimeout(resolve, MMS_RETRY_DELAY_MS));
    }
  }
}
