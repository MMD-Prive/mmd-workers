# Ad-day audit: make LIFF the one simple path into My MMD

Goal: after LINE verification, every person lands somewhere sensible — verified member sees tier/status/points/expiry, everyone else sees a clear next step, and nobody sees a blank or dead-end error.

## What the audit found (current behaviour)

- Only HTTP 401 is treated as "sign in" (`isSessionRequiredError`). Correct and should stay.
- Everything that is not 401 — including 404 "this LINE user has no member record yet" — falls into a single generic error/retry card. A brand-new customer arriving from the ad therefore hits an error screen. This is the main ad-day dead end.
- There is no notion of a *lifecycle state* (new / active / expired / checking) in the data types, so there is no way to show the right single CTA (signup vs renew vs nothing).
- Expiry date exists (`renewalDueAt` / `renewalState`) but is not surfaced on Home; Home shows level, status, points only.
- CARE BACK results (added points, extended expiry) have no dedicated "your result" surface — the CARE state is a stage only.
- The single-file production shell has the same 404 gap and the same missing lifecycle CTAs.
- Design system, navigation, language switching, 401 gate, LINE link, and the "browser never infers entitlement" rule all stay exactly as they are.

## What changes in Lovable

### 1. Data contract (`src/lib/mmd/types.ts`)
Add backend-supplied, never-inferred fields:
- `MembershipInfo.lifecycle: "new" | "active" | "expired" | "checking"` — backend only.
- `MembershipInfo.expiresAt: string | null` (display copy of the authoritative expiry).
- `DashboardSummary.nextAction: { kind: "none" | "signup" | "renew" | "checking"; label: string | null; url: string | null } | null` — backend decides which single CTA to show and where it goes. Browser renders it, never computes it.
- `CareState` gains `pointsAdded: number | null`, `expiryExtendedTo: string | null`, `resultState: "none" | "pending" | "applied" | "unavailable"`.

### 2. Provider behaviour (`live-provider.ts`, `provider-context.tsx`)
- Classify 404 (and `error.code` such as `MEMBER_NOT_FOUND`) as a distinct `noMemberRecord` state instead of a generic error.
- Expose it through context like `sessionRequired` is exposed, so every route benefits.
- Keep 403 / 5xx / network as fail-closed generic error. Keep 401 as the only sign-in invite.
- No retry behaviour change.

### 3. Screens
- **Home**: add expiry line to the membership card; render the backend `nextAction` as one primary button (signup / renew) and nothing when `kind` is `none`; when any authoritative value is missing show `กำลังตรวจสอบสถานะ` rather than an error.
- **New `NoMemberCard` component**: shown when the backend says no canonical member yet — friendly line plus the backend-provided signup CTA. Never an error card.
- **Membership page**: show tier, status, access, expiry, and the same single CTA.
- **Points page**: surface CARE BACK result (points added / new expiry) when `resultState === "applied"`; show neutral pending copy otherwise.
- **Global states**: `checking` becomes the default for any missing value, error card reserved for real failures.
- TH primary copy, EN and ZH added for every new string.

### 4. Single-file production shell (`public/my-mmd-shell.html`)
Mirror the same four states — verified / checking / no-member-signup / expired-renew — plus the CARE result block and expiry, keeping it fully self-contained, resilient, and free of any inferred values.

## What Lovable needs from the backend (GitHub / Workers)

On `GET /api/member/app/dashboard` and `/membership`:
- `lifecycle`, `expires_at`, and a `next_action` object (`kind`, `label`, `url`) — backend decides signup vs renew vs none.
- For a LINE-verified user with no member record: return **200** with `lifecycle: "new"` and a signup `next_action` (preferred), or a **404** with `error.code: "MEMBER_NOT_FOUND"`. Either is handled; 200 gives the nicer experience.
- After payment verification, the same endpoints must return the activated tier, expiry and welcome points — no client-side guessing.

On `GET /api/member/app/care`:
- `points_added`, `expiry_extended_to`, `result_state`, and `approved_discount_percent` (backend-only, as today).

## Unchanged
401-only sign-in gate, canonical LINE MINI App link, same-origin `/api/member/app/*` with credentials, `approved_discount_percent` never promoted from legacy fields, SIGIL warm-light design, mobile vertical layout, TH/EN/ZH, no mock or demo data in production surfaces.

Preview only; nothing is published.
