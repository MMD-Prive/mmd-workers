import React from "react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { cleanup, render, screen, within } from "@testing-library/react";
import { t } from "../../lib/mms/i18n";
const audience = vi.hoisted(() => ({ therapist: false, path: "/payment" }));
vi.mock("@tanstack/react-router", () => ({
  Link: ({ to, children, ...props }: { to: string; children: React.ReactNode }) => (
    <a href={to} {...props}>
      {children}
    </a>
  ),
  useRouterState: () => audience.path,
}));
vi.mock("../../lib/mms/provider-context", () => ({
  useMms: () => ({ tr: t, lang: "th", setLang: vi.fn() }),
}));
vi.mock("../../lib/mms/dispatch-context", () => ({
  useIsTherapistMode: () => ({ confirmed: audience.therapist }),
  useTherapistContext: () => ({ data: null }),
}));
vi.mock("./graphic-progress", () => ({ PendingOperations: () => null }));
import { AppShell } from "./app-shell";
beforeEach(() => {
  vi.stubGlobal(
    "ResizeObserver",
    class {
      observe() {}
      disconnect() {}
    },
  );
  audience.therapist = false;
  audience.path = "/payment";
});
afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});
it("keeps customer navigation to four destinations and payment within requests", () => {
  render(<AppShell>Payment</AppShell>);
  const nav = within(screen.getByRole("navigation"));
  expect(nav.getAllByRole("link")).toHaveLength(4);
  expect(nav.getByRole("link", { name: "คำขอ" }).getAttribute("aria-current")).toBe("page");
  expect(nav.getByRole("link", { name: "แชต" }).getAttribute("href")).toBe(
    "/male-massage/support/chat",
  );
  expect(nav.getByRole("link", { name: "บัญชี" }).getAttribute("href")).toBe("/profile");
});
it("retains therapist Jobs and support destinations without the customer skin", () => {
  audience.therapist = true;
  audience.path = "/jobs";
  const { container } = render(<AppShell>Jobs</AppShell>);
  const nav = within(screen.getByRole("navigation"));
  expect(nav.getByRole("link", { name: "งาน" }).getAttribute("aria-current")).toBe("page");
  expect(nav.getByRole("link", { name: "ช่วยเหลือ" })).toBeTruthy();
  expect(container.querySelector('[data-mms-graphics="customer-v3"]')).toBeNull();
});
