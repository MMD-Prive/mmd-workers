import { useState, type FormEvent } from "react";
import { useSearchCatalog, useTherapistSearch } from "../../lib/mms/provider-context";
import { MmsApiError } from "../../lib/mms/mms-fetch";
import type { SearchCriteria, WorkAvailability } from "../../lib/mms/types";
import { GraphicProgress } from "./graphic-progress";
import { MMS_BOOKING_ROUTE } from "../../lib/mms/config";
import { StatePanel, Pill } from "./primitives";

function SearchFailure({
  error,
  retry,
  busy,
}: {
  error: unknown;
  retry: () => void;
  busy: boolean;
}) {
  const status = error instanceof MmsApiError ? error.status : 0;
  const denied = status === 401 || status === 403;
  return (
    <StatePanel
      state={denied ? "denied" : status === 503 || status === 409 ? "checking" : "error"}
      title={denied ? "ยืนยันบัญชีและสิทธิ์ผ่าน LINE ก่อนครับ" : "ยังตรวจสอบระบบจับคู่ไม่ได้ครับ"}
      hint={
        status === 409
          ? "เงื่อนไขนี้ต้องให้ทีมงานตรวจสอบก่อนครับ ยังสรุปผลจับคู่ไม่ได้"
          : "ยังสรุปไม่ได้ว่ามีผู้ให้บริการตรงเงื่อนไขหรือไม่ กรุณาลองอีกครั้งครับ"
      }
      onRetry={busy ? undefined : retry}
      action={
        denied ? (
          <a href="/male-massage/member" className="mms-primary">
            ยืนยันบัญชีผ่าน LINE
          </a>
        ) : undefined
      }
    />
  );
}

export function MatchingAvailability() {
  const catalog = useSearchCatalog();
  const [form, setForm] = useState<SearchCriteria>({
    service: "",
    zone: "",
    availability: "Available",
    recipient: "",
  });
  const [submitted, setSubmitted] = useState<SearchCriteria | null>(null);
  const search = useTherapistSearch(submitted);
  const update = (key: keyof SearchCriteria, value: string) => {
    setSubmitted(null);
    setForm((previous) => ({ ...previous, [key]: value }));
  };
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (search.isFetching || !catalog.data || !form.service || !form.zone || !form.recipient)
      return;
    if (submitted) void search.refetch();
    else setSubmitted({ ...form });
  };
  return (
    <section className="mms-appointment" aria-labelledby="matching-title">
      <span className="mms-kicker">MMS AI</span>
      <h2 id="matching-title">ค้นหาตามบริการและพื้นที่</h2>
      <p className="mms-copy">ค้นจากคอร์สที่ยืนยัน เขตบริการ และสถานะล่าสุดใน MY THERAPIST ครับ</p>
      {catalog.isFetching && (
        <GraphicProgress completed={0} total={1} label="กำลังตรวจตัวเลือกบริการและเขตจากระบบครับ" />
      )}
      {catalog.isError ? (
        <SearchFailure
          error={catalog.error}
          retry={() => {
            void catalog.refetch();
          }}
          busy={catalog.isFetching}
        />
      ) : (
        catalog.data && (
          <>
            <form onSubmit={submit}>
              <div className="mms-search-fields">
                <label>
                  บริการ
                  <select
                    aria-label="บริการ"
                    required
                    value={form.service}
                    onChange={(event) => update("service", event.target.value)}
                  >
                    <option value="">เลือกบริการ</option>
                    {catalog.data.services.map((item) => (
                      <option key={item.code} value={item.code}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  เขตบริการ
                  <select
                    aria-label="เขตบริการ"
                    required
                    value={form.zone}
                    onChange={(event) => update("zone", event.target.value)}
                  >
                    <option value="">เลือกเขตบริการ</option>
                    {catalog.data.zones.map((item) => (
                      <option key={item.code} value={item.code}>
                        {item.province} · {item.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  สถานะรับงาน
                  <select
                    aria-label="สถานะรับงาน"
                    value={form.availability}
                    onChange={(event) =>
                      update("availability", event.target.value as WorkAvailability)
                    }
                  >
                    {catalog.data.availability.map((item) => (
                      <option key={item.code} value={item.code}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  ผู้รับบริการ
                  <select
                    aria-label="ผู้รับบริการ"
                    required
                    value={form.recipient}
                    onChange={(event) => update("recipient", event.target.value)}
                  >
                    <option value="">เลือกผู้รับบริการ</option>
                    <option value="ผู้ชาย">ผู้ชาย</option>
                    <option value="ผู้หญิง">ผู้หญิง</option>
                  </select>
                </label>
              </div>
              <p className="mms-copy">
                ใช้ข้อมูลผู้รับบริการเพื่อตรวจขอบเขตบริการที่ผู้ให้บริการยืนยันไว้
                เงื่อนไขอื่นต้องให้ทีมงานตรวจสอบครับ
              </p>
              <button
                className="mms-primary"
                type="submit"
                disabled={
                  search.isFetching ||
                  catalog.isFetching ||
                  !form.service ||
                  !form.zone ||
                  !form.recipient
                }
              >
                ค้นหาผู้ให้บริการ
              </button>
            </form>
            {submitted && (
              <div aria-live="polite" className="mms-search-results">
                {search.isFetching ? (
                  <GraphicProgress
                    completed={1}
                    total={2}
                    label="ตรวจตัวเลือกแล้ว กำลังอ่านสถานะผู้ให้บริการล่าสุดครับ"
                  />
                ) : search.isError ? (
                  <SearchFailure
                    error={search.error}
                    retry={() => {
                      void search.refetch();
                    }}
                    busy={search.isFetching}
                  />
                ) : (
                  search.data && (
                    <>
                      <p className="mms-copy">
                        ตรวจข้อมูลเมื่อ{" "}
                        {new Date(search.data.checkedAt).toLocaleTimeString("th-TH", {
                          hour: "2-digit",
                          minute: "2-digit",
                          timeZone: "Asia/Bangkok",
                        })}{" "}
                        น. · เขตบริการที่ระบุ ไม่ใช่ระยะทางจาก GPS
                      </p>
                      {search.data.results.length === 0 ? (
                        <StatePanel
                          state="empty"
                          title="ไม่พบผู้ให้บริการตามเงื่อนไขนี้ครับ"
                          hint="ระบบตรวจข้อมูลสำเร็จแล้ว ลองเปลี่ยนบริการ เขต หรือสถานะได้ครับ"
                        />
                      ) : (
                        <ul className="space-y-3">
                          {search.data.results.map((item) => (
                            <li className="surface-card p-4" key={item.id}>
                              <div className="mms-card-top">
                                <h3>{item.publicName}</h3>
                                <Pill tone={item.canReceiveWork ? "ok" : "neutral"}>
                                  {item.availability === "Available"
                                    ? "Online"
                                    : item.availability === "Paused"
                                      ? "พักรับงาน"
                                      : "Offline"}
                                </Pill>
                              </div>
                              <p>{item.serviceTags.join(" · ")}</p>
                              <p>{item.areaTags.join(" · ")}</p>
                              <details className="mms-therapist-profile">
                                <summary>ดูโปรไฟล์และขอบเขตบริการ</summary>
                                <dl>
                                  <dt>บริการที่ยืนยัน</dt>
                                  <dd>{item.serviceTags.join(" · ")}</dd>
                                  <dt>เขตบริการ</dt>
                                  <dd>{item.areaTags.join(" · ")}</dd>
                                </dl>
                                <a href={MMS_BOOKING_ROUTE} className="mms-primary">
                                  ตรวจรายละเอียดเพื่อส่งคำขอ <span aria-hidden>→</span>
                                </a>
                              </details>
                              <p className="mms-copy">
                                {item.canReceiveWork
                                  ? "พร้อมรับข้อเสนองานตามสถานะที่ตรวจล่าสุด ต้องตรวจรายละเอียดและรอตอบรับตามระบบครับ"
                                  : "ยังไม่พร้อมรับงานตามสถานะปัจจุบันครับ"}
                              </p>
                            </li>
                          ))}
                        </ul>
                      )}
                    </>
                  )
                )}
              </div>
            )}
          </>
        )
      )}
      <p className="mms-copy">
        Online ยังไม่ใช่นัดยืนยัน การค้นหานี้ไม่สร้างงานหรือส่งข้อเสนองานครับ
      </p>
    </section>
  );
}
