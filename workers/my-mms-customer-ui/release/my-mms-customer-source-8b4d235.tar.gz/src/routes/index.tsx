import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "../components/mms/app-shell";
import {
  Pill,
  StatePanel,
  bookingStatusLabel,
  bookingTone,
  MockRibbon,
} from "../components/mms/primitives";
import { GraphicProgress } from "../components/mms/graphic-progress";
import { useCurrentBooking, useCustomer, useMms } from "../lib/mms/provider-context";
import { MmsApiError, isSessionRequiredError } from "../lib/mms/mms-fetch";
import type { BookingSummary } from "../lib/mms/types";
import { formatEtaLabel } from "../lib/mms/eta";
import { MatchingAvailability } from "../components/mms/matching-search";
import service from "../assets/graphics-v2/assets/service.svg?raw";
import calendar from "../assets/graphics-v2/assets/booking.svg?raw";
import area from "../assets/graphics-v2/assets/area.svg?raw";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MY MMS — นัดของฉัน" },
      { name: "description", content: "นัดของฉันและ MMS AI ค้นหาตามบริการและเขตบริการ" },
    ],
  }),
  component: HomePage,
});

export function Appointment({ booking }: { booking: BookingSummary }) {
  const eta = booking.travelStatus === "en_route" ? formatEtaLabel(booking.etaMinutes) : null;
  const etaLabel = eta ? `ถึงในประมาณ ${eta}` : null;
  return (
    <section className="mms-appointment" aria-labelledby="appointment-title">
      <div className="mms-card-top">
        <h2 id="appointment-title">นัดของฉัน</h2>
        <Pill tone={bookingTone(booking.status)}>{bookingStatusLabel(booking.status)}</Pill>
      </div>
      <dl>
        {[
          [service, "บริการ", booking.serviceLabel],
          [calendar, "วันและเวลา", booking.scheduledLabel || "รอยืนยันวันและเวลา"],
          [area, "พื้นที่", booking.areaLabel || "รอยืนยันพื้นที่"],
          ...(etaLabel
            ? [[calendar, "เวลาเดินทางโดยประมาณ", etaLabel]]
            : booking.travelStatus === "checking"
              ? [[calendar, "เวลาเดินทางโดยประมาณ", "กำลังตรวจสอบครับ"]]
              : []),
        ].map(([icon, label, value]) => (
          <div className="mms-booking-field" key={label}>
            <span
              className="mms-icon-disc"
              aria-hidden
              dangerouslySetInnerHTML={{ __html: icon || "" }}
            />
            <div>
              <dt>{label}</dt>
              <dd>{value}</dd>
            </div>
          </div>
        ))}
      </dl>
      <Link to="/bookings/$bookingId" params={{ bookingId: booking.id }} className="mms-primary">
        ดูรายละเอียด <span aria-hidden>→</span>
      </Link>
    </section>
  );
}

export function HomePage() {
  const { isMock } = useMms();
  const customer = useCustomer();
  const booking = useCurrentBooking();
  const needsLogin =
    isSessionRequiredError(booking.error) || isSessionRequiredError(customer.error);
  return (
    <AppShell>
      {isMock && <MockRibbon />}
      <section className="mms-hero">
        <p className="mms-kicker">MY MMS</p>
        <h1>นัดของฉัน</h1>
        <p>ตรวจสอบข้อมูลนัดหมายของคุณได้ที่นี่ครับ</p>
      </section>
      {needsLogin ? (
        <StatePanel
          state="denied"
          title="ยืนยันบัญชีผ่าน LINE อีกครั้งครับ"
          hint="ยืนยันบัญชีก่อนเปิดข้อมูลนัดและข้อมูลส่วนตัวครับ"
          action={
            <a className="mms-primary" href="/male-massage/member">
              ยืนยันบัญชีผ่าน LINE
            </a>
          }
        />
      ) : booking.isPending ? (
        <section className="mms-appointment">
          <h2>กำลังตรวจสอบนัดของคุณครับ</h2>
          <GraphicProgress
            completed={customer.isSuccess ? 1 : 0}
            total={2}
            label="ตรวจบัญชีและรายการนัดจากระบบ"
          />
        </section>
      ) : booking.isError ? (
        <StatePanel
          state={
            booking.error instanceof MmsApiError && booking.error.status === 403
              ? "denied"
              : booking.error instanceof MmsApiError && booking.error.status === 503
                ? "checking"
                : "error"
          }
          title="ยังตรวจสอบรายการนัดไม่ได้ครับ"
          hint="ยังสรุปไม่ได้ว่ามีหรือไม่มีนัด กรุณาลองอีกครั้งครับ"
          onRetry={
            booking.isFetching
              ? undefined
              : () => {
                  void booking.refetch();
                }
          }
        />
      ) : booking.data ? (
        <Appointment booking={booking.data} />
      ) : (
        <>
          <p className="mms-empty-note">ระบบยืนยันแล้วว่าไม่มีรายการนัดปัจจุบันครับ</p>
          <MatchingAvailability />
        </>
      )}
      {!needsLogin && !booking.isPending && !booking.isError && booking.data && (
        <Link to="/therapists" className="mms-ai-entry">
          <span className="mms-ai-mark" aria-hidden="true">
            ✦
          </span>
          <span>
            <strong>MMS AI</strong>
            <small>เลือกบริการและพื้นที่ ให้เราช่วยค้นหา</small>
          </span>
          <span aria-hidden="true">→</span>
        </Link>
      )}
      <div className="mms-shortcuts">
        <Link to="/bookings">
          ประวัติคำขอและนัดหมาย <span aria-hidden>→</span>
        </Link>
        <Link to="/profile">
          ข้อมูลของฉัน <span aria-hidden>→</span>
        </Link>
      </div>
    </AppShell>
  );
}
