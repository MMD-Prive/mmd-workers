import { createFileRoute } from "@tanstack/react-router";

import { AppShell } from "../components/mms/app-shell";
import { MockRibbon, Section, StatePanel } from "../components/mms/primitives";
import { MatchingAvailability } from "../components/mms/matching-search";
import { TherapistCard } from "../components/mms/therapist-card";
import { MMS_BOOKING_ROUTE } from "../lib/mms/config";
import { useMms, useTherapists, useToggleFavorite } from "../lib/mms/provider-context";

export const Route = createFileRoute("/therapists")({
  head: () => ({
    meta: [
      { title: "Therapist ของฉัน — MY MMS" },
      {
        name: "description",
        content: "Therapist ที่คุณเคยใช้บริการและรายการโปรดของคุณกับ Male Massage",
      },
      { property: "og:title", content: "Therapist ของฉัน — MY MMS" },
      {
        property: "og:description",
        content: "Therapist ที่เคยใช้บริการและรายการโปรดใน MY MMS",
      },
    ],
  }),
  component: TherapistsPage,
});

function TherapistsPage() {
  const { isMock } = useMms();
  const query = useTherapists();
  const favorite = useToggleFavorite();

  const lists = query.data;

  return (
    <AppShell>
      {isMock && <MockRibbon />}
      <h1 className="mt-4 px-1 text-xl font-semibold tracking-tight">
        ค้นหา Therapist ที่เหมาะกับคุณ
      </h1>
      <MatchingAvailability />
      <p className="mt-1 px-1 text-xs text-muted-foreground">
        แสดงเฉพาะข้อมูลสาธารณะที่ระบบอนุญาตให้ลูกค้าเห็น
      </p>

      {query.isPending ? (
        <div className="mt-5">
          <StatePanel state="loading" />
        </div>
      ) : query.isError ? (
        <div className="mt-5">
          <StatePanel state="error" onRetry={() => query.refetch()} />
        </div>
      ) : (
        <>
          <Section title="เคยใช้บริการ" className="mt-5">
            {lists && lists.recent.length > 0 ? (
              <ul className="space-y-3">
                {lists.recent.map((th) => (
                  <li key={th.id}>
                    <TherapistCard
                      therapist={th}
                      pending={favorite.isPending}
                      onToggleFavorite={(next) => favorite.mutate({ id: th.id, next })}
                    />
                  </li>
                ))}
              </ul>
            ) : (
              <StatePanel
                state="empty"
                title="ยังไม่มีประวัติการใช้บริการ"
                hint="เมื่อคุณใช้บริการครั้งแรก Therapist จะแสดงที่นี่"
              />
            )}
          </Section>

          <Section title="รายการโปรด">
            {lists && lists.favorites.length > 0 ? (
              <ul className="space-y-3">
                {lists.favorites.map((th) => (
                  <li key={th.id}>
                    <TherapistCard
                      therapist={th}
                      pending={favorite.isPending}
                      onToggleFavorite={(next) => favorite.mutate({ id: th.id, next })}
                    />
                  </li>
                ))}
              </ul>
            ) : (
              <StatePanel state="empty" title="ยังไม่มีรายการโปรด" />
            )}
          </Section>
        </>
      )}

      <a
        href={MMS_BOOKING_ROUTE}
        className="mt-6 flex min-h-14 w-full items-center justify-center rounded-full bg-[image:var(--gradient-leaf)] px-6 text-[0.95rem] font-semibold text-primary-foreground"
      >
        จอง Therapist
      </a>
    </AppShell>
  );
}
