import { createFileRoute, Link } from "@tanstack/react-router";

import { AppShell } from "../components/mms/app-shell";
import { Field, MockRibbon, Pill, Section, StatePanel } from "../components/mms/primitives";

import { useMms, useProfile } from "../lib/mms/provider-context";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "โปรไฟล์ — MY MMS" },
      {
        name: "description",
        content:
          "ข้อมูลลูกค้า Male Massage ของคุณ ชื่อที่แสดง บัญชี LINE ภาษา และพื้นที่/บริการที่ชอบ",
      },
      { property: "og:title", content: "โปรไฟล์ — MY MMS" },
      { property: "og:description", content: "ข้อมูลลูกค้า Male Massage ของคุณใน MY MMS" },
    ],
  }),
  component: ProfilePage,
});

const LANG_LABEL: Record<string, string> = { th: "ไทย", en: "English", zh: "中文" };

function ProfilePage() {
  const { isMock, lang, setLang } = useMms();
  const query = useProfile();
  const profile = query.data;

  return (
    <AppShell>
      {isMock && <MockRibbon />}
      <h1 className="mt-4 px-1 text-xl font-semibold tracking-tight">บัญชีของฉัน</h1>
      <p className="mt-1 px-1 text-xs text-muted-foreground">
        ข้อมูลนี้เป็นของ Male Massage เท่านั้น แยกจากบริการอื่นทั้งหมด
      </p>

      {query.isPending ? (
        <div className="mt-5">
          <StatePanel state="loading" />
        </div>
      ) : query.isError || !profile ? (
        <div className="mt-5">
          <StatePanel state="error" onRetry={() => query.refetch()} />
        </div>
      ) : (
        <>
          <section className="surface-card surface-card-leaf mt-5 p-4">
            <p className="text-lg font-semibold tracking-tight">
              {profile.displayName ?? "คุณลูกค้า"}
            </p>
            {profile.customerRefDisplay && (
              <p className="mt-0.5 text-xs text-muted-foreground">{profile.customerRefDisplay}</p>
            )}
            <div className="mt-3">
              <Field label="บัญชี LINE" value={profile.lineAccountSummary ?? "ยังไม่มีข้อมูล"} />
              {profile.email.safeToDisplay && (
                <Field
                  label="อีเมล"
                  value={
                    <span className="inline-flex items-center gap-2">
                      {profile.email.value ?? "—"}
                      {profile.email.verified && <Pill tone="ok">ยืนยันแล้ว</Pill>}
                    </span>
                  }
                />
              )}
              {profile.phone.safeToDisplay && (
                <Field
                  label="เบอร์โทร"
                  value={
                    <span className="inline-flex items-center gap-2">
                      {profile.phone.value ?? "—"}
                      {profile.phone.verified && <Pill tone="ok">ยืนยันแล้ว</Pill>}
                    </span>
                  }
                />
              )}
              {profile.memberSinceLabel && (
                <Field label="เริ่มใช้บริการ" value={profile.memberSinceLabel} />
              )}
            </div>
          </section>

          {profile.preferredServices.length > 0 && (
            <Section title="บริการที่ชอบ">
              <div className="surface-card flex flex-wrap gap-2 p-4">
                {profile.preferredServices.map((s) => (
                  <span
                    key={s}
                    className="rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </Section>
          )}

          {profile.preferredAreas.length > 0 && (
            <Section title="พื้นที่ที่สะดวก">
              <div className="surface-card flex flex-wrap gap-2 p-4">
                {profile.preferredAreas.map((a) => (
                  <span
                    key={a}
                    className="rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground"
                  >
                    {a}
                  </span>
                ))}
              </div>
            </Section>
          )}

          <Section title="ภาษา">
            <div className="surface-card flex gap-2 p-4">
              {(["th", "en", "zh"] as const).map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => setLang(code)}
                  aria-pressed={lang === code}
                  className={
                    lang === code
                      ? "min-h-11 flex-1 rounded-full bg-primary px-4 text-sm font-medium text-primary-foreground"
                      : "min-h-11 flex-1 rounded-full border border-border px-4 text-sm font-medium text-muted-foreground"
                  }
                >
                  {LANG_LABEL[code]}
                </button>
              ))}
            </div>
            <p className="mt-2 px-1 text-[0.68rem] text-muted-foreground">
              การเปลี่ยนภาษามีผลกับหน้าจอนี้เท่านั้น ภาษาที่บันทึกไว้ในบัญชีจัดการโดยระบบ
            </p>
          </Section>

          <p className="mt-6 px-1 text-[0.68rem] leading-relaxed text-muted-foreground">
            ข้อมูลส่วนตัวแสดงตามสิทธิ์ที่ระบบยืนยันครับ
          </p>
        </>
      )}
      <div className="mms-shortcuts">
        <Link to="/therapists">
          Therapist และรายการโปรด <span aria-hidden>→</span>
        </Link>
        <Link to="/support">
          ศูนย์ช่วยเหลือ <span aria-hidden>→</span>
        </Link>
      </div>
    </AppShell>
  );
}
