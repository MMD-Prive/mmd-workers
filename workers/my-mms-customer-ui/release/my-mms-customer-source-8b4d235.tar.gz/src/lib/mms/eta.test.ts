import { describe, expect, it } from "vitest";
import { formatEtaLabel } from "./eta";

describe("formatEtaLabel", () => {
  it("formats a real minute value as hours and minutes without location data", () => {
    expect(formatEtaLabel(65)).toBe("1 ชม. 5 นาที");
    expect(formatEtaLabel(60)).toBe("1 ชม.");
    expect(formatEtaLabel(8)).toBe("8 นาที");
  });

  it("hides missing, fractional, zero, and unbounded values", () => {
    for (const value of [null, undefined, 0, -1, 1.5, 1441, "65"]) expect(formatEtaLabel(value)).toBeNull();
  });
});
