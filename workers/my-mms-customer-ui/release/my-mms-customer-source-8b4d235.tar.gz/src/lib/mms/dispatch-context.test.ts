import { describe, expect, it, vi } from "vitest";
import { resetDispatchDataForSessionRefresh } from "./dispatch-context";

describe("dispatch session refresh", () => {
  it("resets cached private dispatch data before the current account is rechecked", async () => {
    const resetQueries = vi.fn().mockResolvedValue(undefined);
    await resetDispatchDataForSessionRefresh({ resetQueries });
    expect(resetQueries).toHaveBeenCalledWith({ queryKey: ["mms", "dispatch"] });
  });
});
