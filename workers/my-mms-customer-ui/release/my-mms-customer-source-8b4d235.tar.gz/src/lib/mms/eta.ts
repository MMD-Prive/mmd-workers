export function formatEtaLabel(minutes: unknown): string | null {
  if (!Number.isInteger(minutes) || Number(minutes) < 1 || Number(minutes) > 1440) return null;
  const value = Number(minutes);
  const hours = Math.floor(value / 60);
  const rest = value % 60;
  return [hours ? `${hours} ชม.` : "", rest ? `${rest} นาที` : ""].filter(Boolean).join(" ");
}
