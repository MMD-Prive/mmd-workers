import { MMS_DISPATCH_ENDPOINTS } from "./config";
import { MmsApiError, errorCodeFromBody, fetchMmsJson, isRecord } from "./mms-fetch";
import { contextFromSession, fetchTherapistSession } from "./therapist-auth";
import type {
  JobActionResult,
  JobTravelResult,
  JobDetail,
  JobOffer,
  MmsDispatchProvider,
  TherapistContext,
} from "./dispatch-types";

/**
 * LIVE DISPATCH PROVIDER — same-origin only, credentials: "same-origin".
 *
 * All auth and dispatch paths are CONFIRMED Worker contracts under
 * /male-massage/therapists/api (session cookie path boundary).
 * The provider fails closed: no audience, no job state and no payout is ever
 * produced in the browser. Business-terminal results (TAKEN / EXPIRED) may
 * arrive as HTTP 409/410 with a canonical data.state — that state is preserved.
 */


function unwrap(body: unknown): unknown {
  return isRecord(body) && "data" in body ? body["data"] : body;
}

async function get<T>(path: string, shape: (raw: unknown) => T): Promise<T> {
  const { status, body } = await fetchMmsJson(path, { method: "GET" });
  if (isRecord(body) && body["ok"] === false) {
    throw new MmsApiError(status, errorCodeFromBody(body) ?? "NOT_OK");
  }
  return shape(unwrap(body));
}

async function post<T>(path: string, payload: unknown, shape: (raw: unknown) => T): Promise<T> {
  const { status, body } = await fetchMmsJson(path, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (isRecord(body) && body["ok"] === false) {
    throw new MmsApiError(status, errorCodeFromBody(body) ?? "NOT_OK");
  }
  return shape(unwrap(body));
}

function expectObject<T>(raw: unknown): T {
  if (!isRecord(raw)) throw new MmsApiError(200, "MALFORMED", "malformed");
  return raw as T;
}

function expectArray<T>(raw: unknown): T[] {
  if (!Array.isArray(raw)) throw new MmsApiError(200, "MALFORMED", "malformed");
  return raw as T[];
}

/** Only a backend-declared state is trusted; anything else is CHECKING. */
function expectActionResult(jobId: string, raw: unknown): JobActionResult {
  const obj = expectObject<Record<string, unknown>>(raw);
  const state = typeof obj["state"] === "string" ? (obj["state"] as string).toUpperCase() : null;
  const allowed = [
    "OFFERED",
    "ACCEPTED",
    "DECLINED",
    "EXPIRED",
    "TAKEN",
    "CANCELLED",
    "IN_PROGRESS",
    "COMPLETED",
  ];
  return {
    jobId: typeof obj["jobId"] === "string" ? (obj["jobId"] as string) : jobId,
    state: state && allowed.includes(state) ? (state as JobActionResult["state"]) : "CHECKING",
    message: typeof obj["message"] === "string" ? (obj["message"] as string) : null,
  };
}

/**
 * Business-terminal responses (TAKEN / EXPIRED / CANCELLED …) may arrive as
 * HTTP 409/410 carrying a canonical data.state. That state is authoritative and
 * must not be degraded to CHECKING. Network / malformed / stateless errors
 * still fail closed.
 */
async function action(
  jobId: string,
  path: string,
  payload: unknown,
): Promise<JobActionResult> {
  try {
    return await post(path, payload, (raw) => expectActionResult(jobId, raw));
  } catch (error) {
    if (error instanceof MmsApiError && (error.status === 409 || error.status === 410)) {
      const raw = unwrap(error.body);
      if (isRecord(raw) && typeof raw["state"] === "string") {
        const result = expectActionResult(jobId, raw);
        if (result.state !== "CHECKING") return result;
      }
    }
    throw error;
  }
}

export function createLiveDispatchProvider(): MmsDispatchProvider {
  return {
    kind: "live",
    // REAL endpoint: the backend's own auth/me profile decides the audience.
    getTherapistContext: async (): Promise<TherapistContext> =>
      contextFromSession(await fetchTherapistSession()),

    getIncomingJobOffers: () => get(MMS_DISPATCH_ENDPOINTS.offers, expectArray<JobOffer>),
    getJobOffer: (jobId) => get(MMS_DISPATCH_ENDPOINTS.offer(jobId), expectObject<JobOffer>),
    getJobDetail: (jobId) => get(MMS_DISPATCH_ENDPOINTS.job(jobId), expectObject<JobDetail>),
    getJobs: () => get(MMS_DISPATCH_ENDPOINTS.jobs, expectArray<JobDetail>),
    acceptJob: (jobId, requestKey) =>
      action(jobId, MMS_DISPATCH_ENDPOINTS.accept(jobId), {
        jobId,
        requestKey: requestKey ?? null,
      }),
    declineJob: (jobId, reason) =>
      action(jobId, MMS_DISPATCH_ENDPOINTS.decline(jobId), { jobId, reason: reason ?? null }),
    startJob: (jobId, requestKey) =>
      action(jobId, MMS_DISPATCH_ENDPOINTS.start(jobId), {
        jobId,
        requestKey: requestKey ?? null,
      }),
    completeJob: (jobId, requestKey) =>
      action(jobId, MMS_DISPATCH_ENDPOINTS.complete(jobId), {
        jobId,
        requestKey: requestKey ?? null,
      }),
    departJob: (jobId, latitude, longitude) => post(MMS_DISPATCH_ENDPOINTS.depart(jobId), { latitude, longitude }, (raw) => {
      const value = expectObject<Record<string, unknown>>(raw);
      const minutes = value["eta_minutes"];
      return { state: value["state"] === "EN_ROUTE" ? "EN_ROUTE" : "CHECKING", etaMinutes: Number.isInteger(minutes) && Number(minutes) > 0 ? Number(minutes) : null } satisfies JobTravelResult;
    }),
    // No subscribeToJobUpdates: the Worker has not published a push contract.
    // The app refreshes on route load, visibility/focus return, after writes,
    // and on a bounded poll while an offer sheet is open.
  };
}
