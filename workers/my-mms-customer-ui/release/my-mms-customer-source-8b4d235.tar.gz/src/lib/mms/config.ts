/**
 * MY MMS — centralized route + endpoint constants.
 *
 * OWNERSHIP
 * - Lovable owns pixels and interaction only.
 * - The existing Cloudflare Workers / GitHub backend owns auth, identity,
 *   booking truth, payment truth, therapist matching and every write.
 * - Nothing here decides anything. These are addresses only.
 *
 * Customer workspace endpoints are served same-origin by the MMD Worker stack.
 * Therapist auth and dispatch remain a separate role-scoped contract.
 */

/** Canonical production mount for the MY MMS customer application. */
export const MMS_CUSTOMER_APP_BASEPATH = "/male-massage";

/** In-app route map (TanStack routes owned by this app). */
export const MMS_ROUTES = {
  home: "/",
  bookings: "/bookings",
  therapists: "/therapists",
  payment: "/payment",
  afterService: "/after-service",
  profile: "/profile",
  support: "/support",
  acceptJob: "/accept/job",
  jobs: "/jobs",
  /**
   * EXTERNAL onboarding/profile landing after LINE login (owned by the
   * existing Male Massage site, not by this app).
   */
  therapistMe: "/male-massage/therapists/me",
  /** Canonical MY MMS Therapist work app route (served by the Worker). */
  therapistApp: "/male-massage/therapists/app",
} as const;

/** Worker-owned LINE login page (outside this app). */
export const MMS_THERAPIST_LOGIN_URL = "/male-massage/therapists/login";

/** Canonical therapist job detail route. */
export const jobDetailRoute = (jobId: string) => `/jobs/${jobId}`;

/**
 * External booking destination.
 * Current production booking experience already exists at this path; keep it
 * configurable so the Worker can remap it without touching components.
 */
export const MMS_BOOKING_ROUTE =
  (import.meta.env["VITE_MMS_BOOKING_ROUTE"] as string | undefined) ??
  "/male-massage/member/mms-booking";

/** Worker-owned chat: use a document navigation, outside the React router. */
export const MMS_CHAT_ROUTE = "/male-massage/support/chat";

/** Male Massage LINE Official Account. */
export const MMS_LINE_OA_ID = "@malemassage";
export const MMS_LINE_OA_URL = "https://line.me/R/ti/p/%40malemassage";

/** Same-origin API namespace for the MY MMS customer workspace. */
export const MMS_API_BASE = "/api/mms/app";

/** All same-origin, credentials: "same-origin". */
export const MMS_ENDPOINTS = {
  customer: `${MMS_API_BASE}/customer`,
  currentBooking: `${MMS_API_BASE}/bookings/current`,
  bookings: `${MMS_API_BASE}/bookings`,
  booking: (id: string) => `${MMS_API_BASE}/bookings/${encodeURIComponent(id)}`,
  therapists: `${MMS_API_BASE}/therapists`,
  favorite: (id: string) => `${MMS_API_BASE}/therapists/${encodeURIComponent(id)}/favorite`,
  payments: `${MMS_API_BASE}/payments`,
  afterService: `${MMS_API_BASE}/after-service`,
  support: `${MMS_API_BASE}/support`,
} as const;

/**
 * REAL therapist auth contract (implemented in mms-worker, GitHub/main).
 * The session cookie __Secure-mms_therapist_session is HttpOnly/Secure/
 * SameSite=Lax with Path=/male-massage/therapists — every therapist call must
 * stay inside that path boundary or the cookie is not sent.
 */
export const MMS_THERAPIST_API_BASE = "/male-massage/therapists/api";

export const THERAPIST_AUTH_LINE = `${MMS_THERAPIST_API_BASE}/auth/line`;
export const THERAPIST_AUTH_ME = `${MMS_THERAPIST_API_BASE}/auth/me`;
export const THERAPIST_AUTH_LOGOUT = `${MMS_THERAPIST_API_BASE}/auth/logout`;

/** Role string the backend returns for a therapist session. */
export const MMS_THERAPIST_ROLE = "mms_therapist";

/**
 * REAL / CONFIRMED same-origin API namespace for the therapist dispatch layer
 * (MMS AI -> Matching -> Therapist -> Accept -> Service). Implemented by the
 * Worker and placed INSIDE the therapist session cookie path boundary.
 */
export const MMS_DISPATCH_API_BASE = `${MMS_THERAPIST_API_BASE}/app`;

/**
 * Canonical self access gate for the MY MMS work app.
 * Authenticated `mms_therapist` is necessary but NOT sufficient: only
 * access === 'approved' && can_open === true may open work/job data.
 */
export const THERAPIST_APP_ACCESS = `${MMS_DISPATCH_API_BASE}/access`;

/** Confirmed Worker contract. */
export const MMS_DISPATCH_ENDPOINTS = {
  access: THERAPIST_APP_ACCESS,
  offers: `${MMS_DISPATCH_API_BASE}/offers`,
  offer: (id: string) => `${MMS_DISPATCH_API_BASE}/offers/${encodeURIComponent(id)}`,
  accept: (id: string) => `${MMS_DISPATCH_API_BASE}/offers/${encodeURIComponent(id)}/accept`,
  decline: (id: string) => `${MMS_DISPATCH_API_BASE}/offers/${encodeURIComponent(id)}/decline`,
  jobs: `${MMS_DISPATCH_API_BASE}/jobs`,
  job: (id: string) => `${MMS_DISPATCH_API_BASE}/jobs/${encodeURIComponent(id)}`,
  start: (id: string) => `${MMS_DISPATCH_API_BASE}/jobs/${encodeURIComponent(id)}/start`,
  depart: (id: string) => `${MMS_DISPATCH_API_BASE}/jobs/${encodeURIComponent(id)}/depart`,
  complete: (id: string) => `${MMS_DISPATCH_API_BASE}/jobs/${encodeURIComponent(id)}/complete`,
} as const;

/** How often the app re-reads canonical job state while an offer is live. */
export const MMS_JOB_POLL_MS = 15_000;

/**
 * Hosts where the real Worker serves this app same-origin.
 * mmdbkk.com is the current production origin; malemassage.co is kept only as
 * a future alias and must never replace it.
 */
export const MMS_CANONICAL_HOSTS = [
  "mmdbkk.com",
  "www.mmdbkk.com",
  "malemassage.co",
  "www.malemassage.co",
] as const;

export function isCanonicalMmsHost(hostname?: string | null): boolean {
  if (!hostname) return false;
  return (MMS_CANONICAL_HOSTS as readonly string[]).includes(hostname.toLowerCase());
}

function normalizeCustomerPath(pathname?: string | null): string {
  const clean = String(pathname || "/").replace(/\/{2,}/g, "/");
  return clean.length > 1 ? clean.replace(/\/+$/g, "") : clean;
}

/**
 * The public Webflow pages remain outside the app mount. Only these bounded
 * customer-app routes hydrate with /male-massage as the TanStack basepath.
 * In particular, /male-massage/home and the private Therapist namespace remain
 * separate products and are never swallowed by the customer router.
 */
export function isMmsCustomerAppPath(pathname?: string | null): boolean {
  const path = normalizeCustomerPath(pathname);
  if (path === MMS_CUSTOMER_APP_BASEPATH) return true;
  if (path === `${MMS_CUSTOMER_APP_BASEPATH}/therapists`) return true;
  return ["bookings", "payment", "after-service", "profile", "support"].some(
    (segment) =>
      path === `${MMS_CUSTOMER_APP_BASEPATH}/${segment}` ||
      path.startsWith(`${MMS_CUSTOMER_APP_BASEPATH}/${segment}/`),
  );
}

/**
 * Lovable preview/SSR keeps the app rooted at /. On the canonical custom
 * domain, the same bundle hydrates under /male-massage.
 */
export function mmsRouterBasepath(): string {
  if (typeof window === "undefined") return "/";
  if (!isCanonicalMmsHost(window.location.hostname)) return "/";
  return isMmsCustomerAppPath(window.location.pathname) ? MMS_CUSTOMER_APP_BASEPATH : "/";
}

/**
 * Live provider only on the canonical host (or explicit local opt-in).
 * Everywhere else (Lovable preview) uses the clearly-labelled mock provider.
 */
export function shouldUseLiveProvider(): boolean {
  if (typeof window !== "undefined" && isCanonicalMmsHost(window.location.hostname)) return true;
  return import.meta.env["VITE_MMS_LIVE"] === "true";
}
